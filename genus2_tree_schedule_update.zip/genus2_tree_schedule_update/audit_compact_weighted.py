"""A degree-48 generic weighted-coordinate map and its lowspace evaluator."""
import ast
import json
import random
import sys
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE/'phase_terminal'))
sys.path.insert(0, str(BASE/'resource_audit'))
sys.path.insert(0, str(BASE/'addition_audit'))
import audit_phase_terminal as terminal
import audit_generic_schedule as dag
import audit as addition
import audit_recursive_expression as rec

PROGRAM = {f's{i}': s for i,s in enumerate(terminal.SMALL_PROGRAM[:24])}
PROGRAM.update(K='z1*z2', KE='K*s12',
               KL='s4*s13', KLE='KL*s12', SE2='s6*s15',
               K4='s4**2', K4R2='K4*s16', A='2*KLE+SE2-K4R2',
               LE='s13*s12', K2R2='s4*s16', T='LE-K2R2',
               ab='u11*u12', bz='u01*s1', ab_bz='ab+bz',
               b1term='ab_bz*s12', B1='s21-s18-b1term',
               dz='v01*s3', dzR='dz*s11', bzL='bz*s13',
               ba='u01*u12', baE='ba*s12', B0='dzR-bzL-baE',
               B1E='B1*s12', B1E_N='B1E+s23',
               VV1='s15*B1E_N', AT='A*T', V1='AT-VV1',
               NT='s23*T', B0E='B0*s12', B0E3='B0E*s15', V0='NT-B0E3')
OUTPUTS = dict(U1='A*s16', U0='s23*s16', V1='V1*s16', V0='V0*s16', Z='KE*s11')

def evaluate(coords, modulus=None):
    env=dict(zip(dag.INPUTS, coords))
    for name,expr in PROGRAM.items():
        x=eval(expr, {'__builtins__':{}}, env)
        env[name]=x if modulus is None else x%modulus
    ans=tuple(eval(expr, {'__builtins__':{}}, env) for expr in OUTPUTS.values())
    if modulus:
        ans=tuple(x%modulus for x in ans)
    return ans,env

def decode(coords,q):
    z=pow(coords[4],-1,q)
    return tuple(coords[i]*pow(z,2 if i<2 else 3,q)%q for i in range(4))

def resource():
    bound={s: dag.Bound(1,1) for s in dag.INPUTS}
    forward=Counter()
    for name,expr in PROGRAM.items():
        t=ast.parse(expr,mode='eval').body
        bound[name]=dag.bound(t,bound)
        forward.update(dag.primitives(t))
    outbounds={name: vars(dag.bound(ast.parse(expr,mode='eval').body,bound))
               for name,expr in OUTPUTS.items()}
    rec.trees={k: ast.parse(v,mode='eval').body for k,v in PROGRAM.items()}
    rec.INPUTS=dag.INPUTS
    rec.evaluate_add_serialized.cache_clear()
    low={name:rec.evaluate_add(ast.parse(expr,mode='eval').body) for name,expr in OUTPUTS.items()}
    weights={name: ((2 if i<2 else 3 if i<4 else 1),0) for i,name in enumerate(dag.INPUTS[:5])}
    weights.update({name: (0,(2 if i<2 else 3 if i<4 else 1)) for i,name in enumerate(dag.INPUTS[5:])})
    def weight(t):
        if isinstance(t,ast.Name): return weights[t.id]
        if isinstance(t,ast.Constant): return (0,0)
        if isinstance(t,ast.UnaryOp): return weight(t.operand)
        a=weight(t.left)
        if isinstance(t.op,ast.Pow): return tuple(x*t.right.value for x in a)
        b=weight(t.right)
        if isinstance(t.op,(ast.Add,ast.Sub)):
            assert a==b, (ast.unparse(t),a,b)
            return a
        assert isinstance(t.op,ast.Mult)
        return tuple(x+y for x,y in zip(a,b))
    for name,expr in PROGRAM.items():
        weights[name]=weight(ast.parse(expr,mode='eval').body)
    outweights={name:weight(ast.parse(expr,mode='eval').body) for name,expr in OUTPUTS.items()}
    assert list(outweights.values())==[(20,20),(20,20),(30,30),(30,30),(10,10)]
    return dict(program_temporaries=len(PROGRAM),forward=dict(forward), bounds=outbounds,
                weighted_bidegrees=outweights,
                recursive_scratch=max(x.scratch for x in low.values()),
                recursive_counts=dict(sum((x.counts for x in low.values()),Counter())),
                recursive_outputs={name:dict(scratch=x.scratch,counts=dict(x.counts)) for name,x in low.items()})

def main():
    rng=random.Random(20260911)
    counts=Counter()
    for q in (3,5,7,11,101,127):
        f=addition.curve(q)
        divs=(addition.all_divisors(f,q) if q<=11 else
              addition.random_split_divisor(f,q,rng))
        pairs=[(rng.choice(divs),rng.choice(divs)) for _ in range(1000)]
        for d,e in pairs:
            kind,ref=addition.reference(d,e,f,q)
            if kind!='generic':
                counts['skipped_'+kind]+=1
                continue
            enc=addition.encode(d,rng.randrange(1,q),q)+addition.encode(e,rng.randrange(1,q),q)
            out,env=evaluate(enc,q)
            assert decode(out,q)==ref,(q,d,e,out,ref,decode(out,q))
            assert env['s11'] and env['s12']
            counts['generic_verified']+=1
    q=2**127-1
    f,divs=terminal.point_divisors_large(q,rng,220)
    for d,e in zip(divs[::2],divs[1::2]):
        kind,ref=addition.reference(d,e,f,q)
        if kind!='generic':
            counts['large_skipped_'+kind]+=1
            continue
        enc=addition.encode(d,rng.randrange(1,q),q)+addition.encode(e,rng.randrange(1,q),q)
        out,_=evaluate(enc,q)
        assert decode(out,q)==ref
        counts['large_generic_verified']+=1
    for _ in range(30):
        coords=tuple(rng.randrange(-3,4) for _ in range(10))
        exact,_=evaluate(coords)
        for p in (3,5,11,13,127):
            mod,_=evaluate(tuple(x%p for x in coords),p)
            assert tuple(x%p for x in exact)==mod
            counts['integer_modulus_commutation']+=1
    report=resource()
    trace=rec.ExplicitSchedule()
    for name,expr in OUTPUTS.items():
        trace.add(ast.parse(expr,mode='eval').body, 'out'+name)
    assert trace.peak==report['recursive_scratch']==8
    assert dict(Counter(op[0] for op in trace.operations))==report['recursive_counts']
    for p in (3,5,11,127,2**127-1):
        for _ in range(5):
            source=tuple(rng.randrange(p) for _ in range(10))
            target=tuple(rng.randrange(p) for _ in range(5))
            regs=dict(zip(dag.INPUTS,source))
            regs.update({f'work{i}':0 for i in range(trace.peak)})
            regs.update(dict(zip(('out'+s for s in OUTPUTS),target)))
            initial=regs.copy()
            expected,_=evaluate(source,p)
            rec.execute(trace.operations,regs,p)
            assert tuple(regs['out'+s] for s in OUTPUTS)==tuple((x+y)%p for x,y in zip(target,expected))
            assert all(regs[f'work{i}']==0 for i in range(trace.peak))
            assert tuple(regs[s] for s in dag.INPUTS)==source
            reverse=[(kind,-sign,t,a,b) for kind,sign,t,a,b in reversed(trace.operations)]
            rec.execute(reverse,regs,p)
            assert regs==initial
            counts['literal_clean_register_traces']+=1
    report['literal_primitive_trace_length']=len(trace.operations)
    print(json.dumps(dict(resource=report,tests=dict(counts)),indent=2))

if __name__=='__main__':
    main()
