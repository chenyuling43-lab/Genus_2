#!/usr/bin/env python3
"""Bit-level Toffoli audit of the manuscript's bounded-trace Jacobi phase."""
import json
import random
from pathlib import Path
from validate_modular_primitives import mcx, ripple, get, put, run, tof


def controlled(circuit, enable, aux):
    out = []
    for cs, t in circuit:
        controls = [enable] + list(cs)
        if len(controls) == 3:
            out += [((controls[0], controls[1]), aux),
                    ((aux, controls[2]), t),
                    ((controls[0], controls[1]), aux)]
        else:
            out += [(tuple(controls), t)]
    return out


def compare(a, b, out, carry):
    # a + bitwise_not(b) + 1 has carry iff a>=b.
    forward = []
    for i in range(len(a)):
        c = carry if i == 0 else b[i-1]
        forward += [((b[i],), a[i]), ((b[i],), c), ((a[i], c), b[i])]
    flips = [((), t) for t in b] + [((), carry)]
    return flips + forward + [((b[-1],), out)] + forward[::-1] + flips[::-1] + [((), out)]


def cswap(g, a, b):
    return [((b,), a), ((g, a), b), ((b,), a)]


def macro(a, b, j, c0, c1, z, lt, carry, enable, aux):
    n = len(a)
    flips = [((), t) for t in a]
    zero = flips + mcx(a, z, b) + flips[::-1]
    less = compare(a, b, lt, carry)
    out = zero + less
    out += [((a[0],), c1)]
    out += [((), a[0]), ((), z), ((a[0], z), c0), ((), z), ((), a[0])]
    out += [((a[0], lt), c0)]
    out += less[::-1] + zero[::-1]
    # H or S: e_2(b)=b_1 xor b_2.
    out += [((c0,), enable), ((c1,), enable)]
    out += [((enable, b[i]), j) for i in [1, 2] if i < n]
    out += [((c1,), enable), ((c0,), enable)]
    # X: reciprocity plus e_2(a).
    out += [((c0, c1), enable)]
    out += [((enable, a[1]), aux), ((aux, b[1]), j), ((enable, a[1]), aux)]
    out += [((enable, a[i]), j) for i in [1, 2] if i < n]
    out += [((c0, c1), enable)]
    # S: a <- a-b.
    s_control = [((), c0), ((c0, c1), enable), ((), c0)]
    out += s_control
    out += controlled(ripple(b, a, carry)[::-1], enable, aux)
    out += s_control[::-1]
    # X: b <- b-a, then exchange.
    out += [((c0, c1), enable)]
    out += controlled(ripple(a, b, carry)[::-1], enable, aux)
    for x, y in zip(a, b):
        out += cswap(enable, x, y)
    out += [((c0, c1), enable)]
    # Every active branch halves its new, even first operand.
    active = [((c0,), enable), ((c1,), enable), ((c0, c1), enable)]
    out += active
    for i in range(n-1):
        out += cswap(enable, a[i], a[i+1])
    out += active[::-1]
    return out


def prime(p):
    return p >= 2 and all(p % d for d in range(2, int(p**0.5)+1))


def main():
    rng = random.Random(20260911)
    cases = 0
    sizes = []
    for n in range(2, 8):
        a = list(range(n))
        b = list(range(n, 2*n))
        T = 2*n+1
        trace = list(range(2*n, 2*n+2*T))
        j, z, lt, carry, enable, aux = range(6*n+2, 6*n+8)
        circuit = []
        for t in range(T):
            one = macro(a, b, j, trace[2*t], trace[2*t+1], z, lt, carry, enable, aux)
            assert tof(one) <= 34*n
            circuit += one
        sizes.append({"n": n, "width": 6*n+8,
                      "full_clean_phase_Toffoli": 2*tof(circuit),
                      "bound": 68*n*(2*n+1)})
        for p in range((1 << (n-1)) | 1, 1 << n, 2):
            if not prime(p):
                continue
            inputs = list(range(p)) if n <= 5 else [0, 1, p-1] + [rng.randrange(p) for _ in range(20)]
            for x in inputs:
                state = [0]*(6*n+8)
                put(state, a, x)
                put(state, b, p)
                old = state[:]
                run(state, circuit)
                expected = 0 if x == 0 or pow(x, (p-1)//2, p) == 1 else 1
                assert state[j] == expected, (p, x, state[j], expected)
                assert get(state, a) == 0
                assert not any(state[t] for t in [z, lt, carry, enable, aux])
                run(state, circuit[::-1])
                assert state == old
                cases += 1
    report = {"status": "passed", "cases": cases, "width_certificate": "6n+8",
              "advertised_width": "6n+12", "Toffoli_bound": "68n(2n+1)",
              "sizes": sizes,
              "scope": "Exact primitive-level networks, prime fields below128; phase recorded at midpoint and all arithmetic reversed."}
    Path(__file__).with_name("jacobi_gate_validation.json").write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
