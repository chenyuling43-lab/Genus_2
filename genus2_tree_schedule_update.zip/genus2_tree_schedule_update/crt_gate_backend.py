"""Small-instance X/CNOT/Toffoli compiler for the entire CRT arithmetic trace.

Root residues use explicit truth-table XOR circuits. This validates complete
reconstruction/cleanup and supplies a reference backend, not cryptographic
root-tree synthesis or a certificate of the paper's finite width allocation.
All allocated registers, including extra borrowed bits, are reported.
"""
import validate_modular_primitives as gates


class GateBackend:
    def __init__(self, params, integer_table):
        if len(integer_table) < 2 or len(integer_table) & (len(integer_table)-1):
            raise ValueError('input table length must be a power of two >=2')
        if any(abs(x) > params.bound for x in integer_table):
            raise ValueError('input table violates certified bound')
        self.params, self.table = params, tuple(integer_table)
        self.words, self.width = {}, 0

        def allocate(name, size):
            word = list(range(self.width, self.width+size))
            self.width += size
            self.words[name] = word
            return word

        allocate('input', (len(integer_table)-1).bit_length())
        for name, size in [('Y', params.output_bits), ('A', params.fp_bits),
                           ('r', params.residue_bits), ('t', params.residue_bits),
                           ('O', params.output_bits)]:
            allocate(name, size)
        self.h, self.f, self.carry, self.g, self.aux = allocate('flags', 5)
        allocate('constant', max(params.output_bits, params.residue_bits)+1)
        allocate('borrowed', max(params.fp_bits+1, params.residue_bits+1,
                                  len(self.words['input'])+1)+2)
        self.checkpoints = []

    def modular_add(self, target, constant, modulus, controls):
        word = self.words[target]
        return gates.clean_modadd(word, self.h, self.f,
                                  self.words['constant'][:len(word)+1],
                                  self.carry, self.g, self.aux,
                                  modulus, constant % modulus, controls)

    def compile_op(self, op):
        words, params = self.words, self.params
        dirty = words['borrowed']
        circuit = []
        if op.kind == 'root_xor':
            for address, integer in enumerate(self.table):
                toggles = [((), bit) for j, bit in enumerate(words['input'])
                           if not ((address >> j) & 1)]
                circuit += toggles
                residue = integer % op.modulus
                for j, bit in enumerate(words[op.target]):
                    if (residue >> j) & 1:
                        circuit += gates.mcx(words['input'], bit, dirty)
                circuit += toggles[::-1]
        elif op.kind == 'mac':
            for j, bit in enumerate(words[op.source]):
                circuit += self.modular_add(op.target, op.constant*(1 << j), op.modulus, [bit])
        elif op.kind == 'double':
            circuit = gates.dirty_double(words[op.target], self.h, self.f, op.modulus, dirty)
        elif op.kind in ('fp_controlled', 'fp_constant'):
            controls = [] if op.kind == 'fp_constant' else [words[op.source][op.bit]]
            circuit = gates.constadd(words['A'], op.constant, controls, dirty)
        elif op.kind == 'mod_controlled':
            circuit = self.modular_add(op.target, op.constant, op.modulus,
                                       [words[op.source][op.bit]])
        elif op.kind == 'copy_xor':
            circuit = [((a,), b) for a, b in zip(words[op.source], words[op.target])]
        elif op.kind != 'clean_checkpoint':
            raise ValueError(op.kind)
        if op.direction == -1:
            circuit = circuit[::-1]
        for controls, target in circuit:
            assert len(controls) <= 2 and target not in controls
            assert len(set(controls)) == len(controls)
        return circuit

    def compile(self, trace):
        circuit, checkpoints = [], []
        for op in trace:
            circuit += self.compile_op(op)
            if op.kind == 'clean_checkpoint':
                checkpoints.append(len(circuit))
        self.checkpoints = checkpoints
        return circuit

    def state(self, address, O=0, Y=0, A=0, borrowed=0):
        state = [0]*self.width
        for name, value in [('input', address), ('O', O), ('Y', Y), ('A', A), ('borrowed', borrowed)]:
            gates.put(state, self.words[name], value)
        return state

    def registers(self, state):
        return {name: gates.get(state, self.words[name]) for name in ('Y', 'A', 'r', 't', 'O')}

    def report(self, circuit):
        return dict(total_allocated_bits=self.width,
                    word_sizes={k:len(v) for k,v in self.words.items()},
                    X=sum(len(c)==0 for c,_ in circuit),
                    CNOT=sum(len(c)==1 for c,_ in circuit),
                    Toffoli=gates.tof(circuit), total_gates=len(circuit),
                    scope='reference small-instance backend; includes extra borrowed workspace')


if __name__ == '__main__':
    import argparse
    import json
    from dataclasses import asdict
    from reversible_crt import CRTParameters, clean_xor_trace
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--netlist', help='write an explicit small clean-XOR gate network')
    args = parser.parse_args()
    params = CRTParameters(7, (3,5), 3)
    backend = GateBackend(params, [-3,-2,-1,0,1,2,3,0])
    circuit = backend.compile(clean_xor_trace(params))
    report = backend.report(circuit)
    if args.netlist:
        with open(args.netlist, 'w', encoding='utf-8') as stream:
            json.dump(dict(parameters=asdict(params), input_integer_table=backend.table,
                           register_bit_indices=backend.words, resources=report,
                           gate_encoding='[controls, target]; 0/1/2 controls mean X/CNOT/Toffoli',
                           gates=circuit), stream, separators=(',', ':'))
            stream.write('\n')
    print(json.dumps(report, indent=2))
