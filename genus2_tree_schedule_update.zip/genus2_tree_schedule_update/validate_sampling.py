"""Deterministic protocol-level checks for genus-two phase sampling.

Run with Python 3 and NumPy.  This file imports the exact classical Cantor
reference from ../addition_audit (or the same directory in a flattened
bundle).  It does not synthesize or simulate a gate-level quantum circuit.
All group arithmetic is exact; Fourier transforms use complex128 with
absolute tolerance 2e-12.  JSON is written to stdout.
"""
import json
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "addition_audit"))
from cantor_complete import (all_reduced, cantor_add, curve,
                             encode_canonical, negate)

TOL = 2e-12
IDENTITY = ((1,), (0,))


def scalar(D, a, f, p):
    out = IDENTITY
    while a:
        if a & 1:
            out = cantor_add(out, D, f, p)
        D = cantor_add(D, D, f, p)
        a >>= 1
    return out


def is_prime(a):
    return a >= 2 and all(a % d for d in range(2, int(a ** 0.5) + 1))


def subgroup(f, p):
    ds = all_reduced(f, p)
    order = len(ds)
    n1, n2 = independent_curve_counts(f, p)
    assert (n1 * n1 + n2) % 2 == 0
    assert order == (n1 * n1 + n2) // 2 - p
    r = max(d for d in range(2, order + 1) if order % d == 0 and is_prime(d))
    for D in ds[1:]:
        P = scalar(D, order // r, f, p)
        if P != IDENTITY:
            break
    result = [IDENTITY]
    for _ in range(1, r):
        result.append(cantor_add(result[-1], P, f, p))
    assert len(set(result)) == r
    assert cantor_add(result[-1], P, f, p) == IDENTITY
    return result, order


def independent_curve_counts(f, p):
    """Count curve points over F_p and F_(p^2), independently of Cantor.

    The genus-two zeta identity is #J(F_p)=(N1^2+N2)/2-p.  Represent
    F_(p^2) by a+b*t with t^2 a fixed nonsquare, and enumerate squares.
    """
    nonsquare = next(x for x in range(2, p) if pow(x, (p-1)//2, p) == p-1)

    def multiply(x, y):
        a, b = x
        c, d = y
        return ((a*c + nonsquare*b*d) % p, (a*d+b*c) % p)

    elements = [(a, b) for a in range(p) for b in range(p)]
    square_counts = Counter(multiply(x, x) for x in elements)
    n2 = 1
    for x in elements:
        fx = (0, 0)
        for c in reversed(f):
            fx = multiply(fx, x)
            fx = ((fx[0]+c) % p, fx[1])
        n2 += square_counts[fx]
    n1 = 1 + sum(sum(y*y % p == sum(c*pow(x, i, p) for i, c in enumerate(f)) % p
                         for y in range(p)) for x in range(p))
    return n1, n2


def phase_sign(D, gamma, p):
    if len(D[0]) != 3:
        return 1
    x = (D[0][0] + gamma) % p
    return -1 if pow(x, (p - 1) // 2, p) == p - 1 else 1


def exact_useful(signs):
    return 1 - Fraction(sum(signs), len(signs)) ** 2


def fft_phase(signs, r, k, shape):
    a, b = np.indices(shape)
    values = np.asarray(signs)[(a + k * b) % r]
    return np.abs(np.fft.fft2(values) / values.size) ** 2


def fft_full(r, k, shape):
    a, b = np.indices(shape)
    classes = (a + k * b) % r
    result = np.zeros(shape)
    for t in range(r):
        result += np.abs(np.fft.fft2(classes == t) / classes.size) ** 2
    return result


def encoding_word(D, n):
    degree, *coeffs = encode_canonical(D)
    return degree | sum(c << (2 + n * j) for j, c in enumerate(coeffs))


def induced_phase_patterns(group, p):
    """All restrictions of binary linear phases, each with equal weight.

    The map from all 2^(4n+2) seeds to sign patterns is linear, so every
    pattern has the same number of preimages.  Gaussian elimination on
    its columns removes only this uniform multiplicity.
    """
    n = p.bit_length()
    words = [encoding_word(D, n) for D in group]
    assert len(set(words)) == len(words)
    pivots = {}
    for bit in range(4 * n + 2):
        column = sum(((word >> bit) & 1) << t for t, word in enumerate(words))
        while column:
            lead = column.bit_length() - 1
            if lead in pivots:
                column ^= pivots[lead]
            else:
                pivots[lead] = column
                break
    patterns = [0]
    for column in pivots.values():
        patterns += [pattern ^ column for pattern in patterns]
    assert len(patterns) == len(set(patterns)) == 2 ** len(pivots)
    signs = np.array([[1 - 2 * ((pattern >> t) & 1) for t in range(len(group))]
                      for pattern in patterns], dtype=np.int32)
    return signs, len(pivots), 4 * n + 2


def validate_case(p, enumerate_canonical=True):
    f = curve(p)
    group, full_order = subgroup(f, p)
    r, k = len(group), 2
    a, b = np.indices((r, r))
    offline = b != (k * a) % r
    all_signs = [[phase_sign(D, gamma, p) for D in group] for gamma in range(p)]
    exact = [exact_useful(signs) for signs in all_signs]
    mean = sum(exact, Fraction()) / p
    max_error = 0.0
    max_offline = 0.0
    for signs, prediction in zip(all_signs, exact):
        distribution = fft_phase(signs, r, k, (r, r))
        max_error = max(max_error, abs(float(distribution[a != 0].sum()) - float(prediction)))
        max_offline = max(max_offline, float(distribution[offline].sum()))
        assert abs(float(distribution.sum()) - 1) < TOL
    assert max_error < TOL and max_offline < TOL
    full = fft_full(r, k, (r, r))
    target = np.zeros((r, r))
    target[np.arange(r), k * np.arange(r) % r] = 1 / r
    assert np.max(np.abs(full - target)) < TOL
    e = sum(len(D[0]) < 3 for D in group)
    fibers = Counter(D[0][0] for D in group if len(D[0]) == 3)
    lower = (1 - Fraction(1, p)) * (1 - Fraction(e * e + sum(m * m for m in fibers.values()), r * r))
    assert mean >= lower
    result = dict(q=p, f_ascending=f, jacobian_order=full_order,
                  independent_curve_point_counts=independent_curve_counts(f, p),
                  P=group[1], Q=group[k], r=r, k=k,
                  degree_below_two=e, u0_fibers=dict(sorted(fibers.items())),
                  unshifted_useful=str(exact[0]), shifted_useful=str(mean),
                  shifted_by_seed=[str(x) for x in exact],
                  fiber_lower_bound=str(lower), full_output_useful=str(Fraction(r-1, r)),
                  max_fourier_prediction_error=max_error, max_offline_mass=max_offline)
    if enumerate_canonical:
        signs, rank, seed_bits = induced_phase_patterns(group, p)
        covariance = signs.T @ signs
        assert np.array_equal(covariance, len(signs) * np.eye(r, dtype=np.int32))
        spectrum = np.mean(np.abs(np.fft.fft(signs, axis=1) / r) ** 2, axis=0)
        assert np.max(np.abs(spectrum - 1 / r)) < TOL
        shape = (8, 4)
        aa, bb = np.indices(shape)
        values = signs[:, (aa + k * bb) % r]
        averaged = np.mean(np.abs(np.fft.fft2(values, axes=(-2, -1)) / 32) ** 2, axis=0)
        rect_full = fft_full(r, k, shape)
        err = float(np.max(np.abs(averaged - rect_full)))
        assert err < TOL
        result.update(canonical_seed_bits=seed_bits, induced_seed_rank=rank,
                      canonical_patterns_enumerated=len(signs),
                      original_seeds_represented=2 ** seed_bits,
                      rectangular_shape=shape, rectangular_canonical_max_error=err)
    else:
        result["canonical_patterns_enumerated"] = None
    return result


def rectangle_obstruction():
    p, f = 5, curve(5)
    group, order = subgroup(f, p)
    r, k = len(group), len(group) - 1
    assert len(group[1][0]) == 2
    assert group[k] == negate(group[1], p)
    distributions = [fft_phase([phase_sign(D, gamma, p) for D in group], r, k, (2, 2))
                     for gamma in range(p)]
    target = np.array([[1., 0.], [0., 0.]])
    assert all(np.max(np.abs(x-target)) < TOL for x in distributions)
    full = fft_full(r, k, (2, 2))
    assert np.max(np.abs(full - [[3/8, 1/8], [1/8, 3/8]])) < TOL
    signs, rank, seed_bits = induced_phase_patterns(group, p)
    aa, bb = np.indices((2, 2))
    averaged = np.mean(np.abs(np.fft.fft2(signs[:, (aa + k * bb) % r], axes=(-2, -1)) / 4) ** 2, axis=0)
    assert np.max(np.abs(averaged-full)) < TOL
    return dict(q=p, f_ascending=f, jacobian_order=order, P=group[1], Q=group[k], r=r, k=k,
                shape=[2, 2], all_shifted_distributions=target.tolist(),
                full_output_distribution=full.tolist(),
                canonical_averaged_distribution=averaged.tolist(),
                shifted_vs_full_total_variation=5/8,
                interpretation="No universal rectangular-domain transfer identity; not a refutation of a specified short-domain DLP postprocessing theorem.")


def main():
    results = [validate_case(p, enumerate_canonical=p != 11) for p in (3, 5, 7, 11)]
    obstruction = rectangle_obstruction()
    print(json.dumps(dict(test_scope="Exact group arithmetic and protocol-level Fourier distributions; not gate-level simulation.",
                         tolerance=TOL, cases=results, rectangle_obstruction=obstruction), indent=2))


if __name__ == "__main__":
    main()
