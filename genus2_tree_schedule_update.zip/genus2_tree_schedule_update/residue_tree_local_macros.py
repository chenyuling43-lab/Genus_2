"""Literal field-operation bridge for ghost correction and root consumption.

Uses the existing M/S/A/C interpreter. Measurement and classically selected Z
phases remain macro operations; this file does not compile Clifford+T gates.
"""
import ast
from collections import Counter
from functools import lru_cache
import audit_compact_weighted as compact
import audit_phase_terminal as terminal
import audit_generic_schedule as dag
import audit_recursive_expression as rec


def inverse(ops):
    return tuple((kind, -sign, target, a, b)
                 for kind, sign, target, a, b in reversed(ops))


@lru_cache(maxsize=1)
def compile_macros():
    # The legacy scheduler uses module globals. Restore them after compilation,
    # including its cost cache, so importing this bridge does not change audits.
    previous_trees, previous_inputs = rec.trees, rec.INPUTS
    try:
        rec.INPUTS = dag.INPUTS
        rec.trees = {k: ast.parse(v, mode='eval').body for k, v in compact.PROGRAM.items()}
        rec.evaluate_add_serialized.cache_clear()
        coordinate_traces = []
        peaks = []
        for expr in compact.OUTPUTS.values():
            trace = rec.ExplicitSchedule()
            trace.add(ast.parse(expr, mode='eval').body, 'scalar')
            assert not trace.live
            coordinate_traces.append(tuple(trace.operations))
            peaks.append(trace.peak)
        rec.trees = {f's{i}': ast.parse(expr, mode='eval').body
                     for i, expr in enumerate(terminal.SMALL_PROGRAM)}
        rec.evaluate_add_serialized.cache_clear()
        numerator, denominator = rec.ExplicitSchedule(), rec.ExplicitSchedule()
        numerator.add(ast.parse('s23', mode='eval').body, 'scalar')
        denominator.add(ast.parse('s24', mode='eval').body, 'D')
        # D is one local word. gamma is a classical constant, not a qubit word.
        root_ops = (tuple(numerator.operations) + tuple(denominator.operations)
                    + (('M', 1, 'scalar', 'D', 'gamma'),)
                    + inverse(denominator.operations))
        terminal_peak = max(numerator.peak, 1 + denominator.peak)
        assert max(peaks) == 8 and terminal_peak == 6
        assert sum(map(len, coordinate_traces)) == 35505
        return tuple(coordinate_traces), tuple(root_ops), terminal_peak
    finally:
        rec.trees, rec.INPUTS = previous_trees, previous_inputs
        rec.evaluate_add_serialized.cache_clear()


def phase_correct(coords, mask, p):
    """Return the applied phase; assert scalar/local cleanup and source retention.

    mask packs five b-bit measurement masks, low coordinate first. Actual
    classical feed-forward applies Z to each scalar bit selected by its mask.
    """
    assert len(coords) == 10 and all(0 <= x < p for x in coords)
    b = p.bit_length()
    assert 0 <= mask < 1 << (5 * b)
    traces, _, _ = compile_macros()
    regs = dict(zip(dag.INPUTS, coords))
    regs.update({f'work{i}': 0 for i in range(8)})
    regs['scalar'] = 0
    initial = regs.copy()
    phase = 1
    for i, ops in enumerate(traces):
        rec.execute(ops, regs, p)
        phase *= 1 - 2 * (((mask >> (i*b)) & regs['scalar']).bit_count() % 2)
        rec.execute(inverse(ops), regs, p)
        assert regs == initial
    return phase


def consume_root(coords, target, p, gamma):
    """Compute scalar, bitwise XOR to an arbitrary b-bit target, then uncompute."""
    assert len(coords) == 10 and all(0 <= x < p for x in coords)
    assert 0 <= target < 1 << p.bit_length()
    _, ops, _ = compile_macros()
    regs = dict(zip(dag.INPUTS, coords))
    regs.update({f'work{i}': 0 for i in range(5)})
    regs.update(D=0, scalar=0, gamma=gamma % p)
    initial = regs.copy()
    rec.execute(ops, regs, p)
    assert regs['D'] == 0 and all(regs[f'work{i}'] == 0 for i in range(5))
    result = target ^ regs['scalar']
    rec.execute(inverse(ops), regs, p)
    assert regs == initial
    return result


def macro_resources():
    traces, root, peak = compile_macros()
    counts = Counter(op[0] for op in root)
    counts['M'] -= 1  # separate the one classically constant multiplication
    return dict(node_forward_field_operations=sum(map(len, traces)),
                phase_correction_field_operations=2*sum(map(len, traces)),
                phase_correction_local_words=8, phase_correction_scalar_words=1,
                terminal_forward_counts=dict(counts), terminal_constant_multiplications=1,
                terminal_local_words=peak, terminal_scalar_words=1)


def leaf_phase_from_table(table, address, mask, b):
    """Direct selector phase: one table pass, not five repeated lookups.

    A clean equality selector computes [address == a] into flag, a Z is
    applied iff the classical packed table value has odd overlap with mask,
    and the selector is uncomputed. A w-bit equality selector fits the
    existing conservative 4*w Toffoli allowance per entry. This function is
    its word-level semantics, not a compiled multi-control gate network.
    """
    assert len(table) >= 2 and len(table) & (len(table)-1) == 0
    assert 0 <= address < len(table) and 0 <= mask < 1 << (5*b)
    phase, flag = 1, 0
    for a, coords in enumerate(table):
        assert len(coords) == 5 and all(0 <= x < 1 << b for x in coords)
        packed = sum(x << (i*b) for i, x in enumerate(coords))
        flag ^= int(address == a)
        if (mask & packed).bit_count() % 2:
            phase *= 1 - 2*flag
        flag ^= int(address == a)
        assert flag == 0
    return phase
