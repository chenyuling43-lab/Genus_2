"""Finite verification of a reversible bounded-trace binary Jacobi macro.

This validates arithmetic and branch reversal, not synthesized quantum gates.
"""

import math


def chi2(b):
    assert b > 0 and b % 2 == 1
    return int(b % 8 in (3, 5))


def branch(a, b):
    if a == 0:
        return "D"
    if a % 2 == 0:
        return "H"
    return "S" if a >= b else "X"


def delta(a, b, h):
    if h in ("H", "S"):
        return chi2(b)
    if h == "X":
        return int(a % 4 == 3 and b % 4 == 3) ^ chi2(a)
    return 0


def forward(a, b, j):
    h = branch(a, b)
    j ^= delta(a, b, h)
    if h == "H":
        a //= 2
    elif h == "S":
        a = (a-b)//2
    elif h == "X":
        a, b = (b-a)//2, a
    return a, b, j, h


def backward(a, b, j, h):
    if h == "H":
        a *= 2
    elif h == "S":
        a = 2*a+b
    elif h == "X":
        a, b = b, 2*a+b
    j ^= delta(a, b, h)
    assert branch(a, b) == h
    return a, b, j


def jacobi_reference(a, b):
    assert b > 0 and b % 2 == 1
    answer = 1
    a %= b
    while a:
        while a % 2 == 0:
            a //= 2
            if b % 8 in (3, 5):
                answer = -answer
        a, b = b, a
        if a % 4 == 3 and b % 4 == 3:
            answer = -answer
        a %= b
    return answer if b == 1 else 0


def prime(p):
    return p >= 2 and all(p % k for k in range(2, math.isqrt(p)+1))


def main():
    cases = prime_cases = max_steps = 0
    for b0 in range(3, 512, 2):
        n = b0.bit_length()
        for a0 in range(b0):
            a, b, j = a0, b0, 0
            trace = []
            actual = 0
            for _ in range(2*n+1):
                oldprod = a*b
                a, b, j, h = forward(a, b, j)
                trace.append(h)
                actual += h != "D"
                if h != "D":
                    assert 2*a*b <= oldprod
                assert b > 0 and b % 2 == 1
                assert max(a, b) < 2**n
            assert a == 0
            result = (-1)**j if b == 1 else 0
            assert result == jacobi_reference(a0, b0)
            if prime(b0):
                phase = (-1)**j
                expected = 1 if a0 == 0 else (1 if pow(a0, (b0-1)//2, b0) == 1 else -1)
                assert phase == expected
                prime_cases += 1
            for h in reversed(trace):
                a, b, j = backward(a, b, j, h)
            assert (a, b, j) == (a0, b0, 0)
            cases += 1
            max_steps = max(max_steps, actual)
    print(f"Verified {cases} canonical inputs for every odd denominator 3..511.")
    print(f"Among these, {prime_cases} prime-field phases equal completed Legendre.")
    print(f"All branch traces reverse exactly; maximum observed active steps {max_steps}.")


if __name__ == "__main__":
    main()
