#!/usr/bin/env python3
"""Exact bit-level validation of the conservative modular primitives.

The networks below contain only X, CNOT, and Toffoli gates. Dirty borrowed
bits are initialized to arbitrary values and checked after each circuit.
This verifies the concrete constructions; it is not an optimized synthesis.
"""
import json
import random
from pathlib import Path


def gate(state, controls, target):
    if all(state[i] for i in controls):
        state[target] ^= 1


def mcx(controls, target, dirty):
    k = len(controls)
    if k <= 2:
        return [(tuple(controls), target)]
    a = controls
    d = dirty[:k-2]
    assert len(d) == k-2
    assert not (set(a + [target]) & set(d))
    first = [(tuple(a[:2]), d[0])]
    ladder = [((d[i-1], a[i+1]), d[i]) for i in range(1, k-2)]
    center = [((d[-1], a[-1]), target)]
    block = ladder + center + ladder[::-1]
    return first + block + first + block


def constadd(word, c, controls, dirty):
    """Controlled add c modulo 2^len(word), with dirty carry ladders."""
    c %= 1 << len(word)
    out = []
    for j in range(len(word)):
        if (c >> j) & 1:
            for i in reversed(range(j, len(word))):
                out += mcx(list(controls) + word[j:i], word[i], dirty)
    return out


def dirty_modadd(word, h, f, p, c, controls, dirty):
    w = word + [h]
    a = constadd(w, c, controls, dirty)
    a += constadd(w, -p, controls, dirty)
    a += mcx(list(controls) + [h], f, dirty)
    a += constadd(w, p, list(controls) + [f], dirty)
    a += mcx(list(controls), f, dirty)
    a += constadd(w, -c, controls, dirty)
    a += mcx(list(controls) + [h], f, dirty)
    a += constadd(w, c, controls, dirty)
    return a


def dirty_double(word, h, f, p, dirty):
    w = word + [h]
    # Rotating the extended register left maps (h=0,z) to 2z.
    a = []
    for i in reversed(range(len(w)-1)):
        a += [((w[i],), w[i+1]), ((w[i+1],), w[i]), ((w[i],), w[i+1])]
    a += constadd(w, -p, [], dirty)
    a += [((h,), f)]
    a += constadd(w, p, [f], dirty)
    a += [((), f), ((word[0],), f)]
    return a


def ripple(a, b, carry):
    out = []
    for i in range(len(a)):
        c = carry if i == 0 else a[i-1]
        out += [((a[i],), b[i]), ((a[i],), c), ((b[i], c), a[i])]
    for i in reversed(range(len(a))):
        c = carry if i == 0 else a[i-1]
        out += [((b[i], c), a[i]), ((a[i],), c), ((c,), b[i])]
    return out


def load_constant(word, c, control=None):
    return [(tuple([] if control is None else [control]), word[i])
            for i in range(len(word)) if (c >> i) & 1]


def clean_modadd(word, h, f, cw, carry, g, aux, p, c, controls):
    """Uses b+6 clean bits and <=20(b+1) Toffolis, b>=2."""
    w = word + [h]
    compute_g = mcx(list(controls), g, [aux])
    add = ripple(cw, w, carry)
    sub = add[::-1]
    restore = []
    for cs, t in add:
        controlled = [f] + list(cs)
        if len(controlled) == 3:
            restore += [((controlled[0], controlled[1]), aux),
                        ((aux, controlled[2]), t),
                        ((controlled[0], controlled[1]), aux)]
        else:
            restore += mcx(controlled, t, [aux])
    a = compute_g[:]
    a += load_constant(cw, c, g) + add + load_constant(cw, c, g)
    a += load_constant(cw, p) + sub + [((h,), f)]
    a += restore + load_constant(cw, p)
    a += [((), f)]
    a += load_constant(cw, c, g) + sub + [((h,), f)] + add
    a += load_constant(cw, c, g)
    a += compute_g[::-1]
    return a


def get(s, word):
    return sum(s[i] << j for j, i in enumerate(word))


def put(s, word, value):
    for j, i in enumerate(word):
        s[i] = (value >> j) & 1


def run(s, circuit):
    for controls, target in circuit:
        gate(s, controls, target)


def tof(circuit):
    return sum(len(c) == 2 for c, _ in circuit)


def main():
    rng = random.Random(20260911)
    counts = {"dirty_modular_addition": 0, "dirty_doubling": 0,
              "clean_modular_addition": 0, "multiply_accumulate": 0,
              "square_accumulate": 0}
    # Exhaustive values and controls, arbitrary sampled dirty bits.
    for b in range(2, 5):
        word = list(range(b))
        h, f = b, b+1
        controls = [b+2, b+3]
        dirty = list(range(b+4, 2*b+7))
        for p in range((1 << (b-1)) | 1, 1 << b, 2):
            for c in range(p):
                circuit = dirty_modadd(word, h, f, p, c, controls, dirty)
                assert tof(circuit) <= 20*(b+1)**2*(b+3)+10
                for z in range(p):
                    for u in range(4):
                        s = [0]*(2*b+7)
                        put(s, word, z)
                        put(s, controls, u)
                        put(s, dirty, rng.randrange(1 << len(dirty)))
                        old = s[:]
                        run(s, circuit)
                        assert get(s, word) == (z + (c if u == 3 else 0)) % p
                        assert s[b:] == old[b:]
                        run(s, circuit[::-1])
                        assert s == old
                        counts["dirty_modular_addition"] += 1
    for b in range(2, 7):
        word = list(range(b))
        h, f = b, b+1
        dirty = list(range(b+2, 2*b+5))
        for p in range((1 << (b-1)) | 1, 1 << b, 2):
            circuit = dirty_double(word, h, f, p, dirty)
            assert tof(circuit) <= 8*(b+1)**2*(b+3)+2
            for z in range(p):
                s = [0]*(2*b+5)
                put(s, word, z)
                put(s, dirty, rng.randrange(1 << len(dirty)))
                old = s[:]
                run(s, circuit)
                assert get(s, word) == 2*z % p
                assert s[b:] == old[b:]
                run(s, circuit[::-1])
                assert s == old
                counts["dirty_doubling"] += 1
    for b in range(2, 5):
        word = list(range(b))
        h, f, carry, g, aux = range(b, b+5)
        cw = list(range(b+5, 2*b+6))
        controls = [2*b+6, 2*b+7]
        for p in range((1 << (b-1)) | 1, 1 << b, 2):
            for c in range(p):
                circuit = clean_modadd(word, h, f, cw, carry, g, aux, p, c, controls)
                assert tof(circuit) <= 20*(b+1)
                for z in range(p):
                    for u in range(4):
                        s = [0]*(2*b+8)
                        put(s, word, z)
                        put(s, controls, u)
                        old = s[:]
                        run(s, circuit)
                        assert get(s, word) == (z + (c if u == 3 else 0)) % p
                        assert s[b:] == old[b:]
                        counts["clean_modular_addition"] += 1
    for p in [3, 5, 7, 11, 13, 17, 31]:
        b = p.bit_length()
        word = list(range(b))
        h, f, carry, g, aux = range(b, b+5)
        cw = list(range(b+5, 2*b+6))
        xw = list(range(2*b+6, 3*b+6))
        yw = list(range(3*b+6, 4*b+6))
        for square in [False, True]:
            circuit = []
            for i in range(b):
                for j in range(b):
                    controls = [xw[i], xw[j] if square else yw[j]]
                    controls = list(dict.fromkeys(controls))
                    circuit += clean_modadd(word, h, f, cw, carry, g, aux,
                                            p, pow(2, i+j, p), controls)
            assert tof(circuit) <= 20*b*b*(b+1)
            for _ in range(100):
                x, y, z = [rng.randrange(p) for _ in range(3)]
                s = [0]*(4*b+6)
                put(s, word, z)
                put(s, xw, x)
                put(s, yw, y)
                old = s[:]
                run(s, circuit)
                assert get(s, word) == (z + x*(x if square else y)) % p
                assert s[b:] == old[b:]
                run(s, circuit[::-1])
                assert s == old
                counts["square_accumulate" if square else "multiply_accumulate"] += 1
    report = {"status": "passed", "counts": counts,
              "clean_modular_add_scratch": "b+6 (conservative advertised b+10)",
              "clean_modular_add_Toffoli_bound": "20(b+1)",
              "dirty_modular_add_scratch": "2 clean, b+1 borrowed dirty",
              "dirty_modular_add_Toffoli_bound": "20(b+1)^2(b+3)+10",
              "dirty_doubling_scratch": "2 clean, at most b+1 borrowed dirty",
              "dirty_doubling_Toffoli_bound": "8(b+1)^2(b+3)+2"}
    out = Path(__file__).with_name("modular_primitive_validation.json")
    out.write_text(json.dumps(report, indent=2)+"\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
