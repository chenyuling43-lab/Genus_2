"""End-to-end reversible CRT tests: signed guard, phase, XOR, gates and cleanup.

Independent reference uses exact integers and division ONLY in assertions.
The executed reconstruction streams parity bits into A without division.
"""
from dataclasses import asdict
from functools import lru_cache
from math import prod
from pathlib import Path
import json
import random
import numpy as np

import audit_compact_weighted as compact
import audit_phase_terminal as terminal
import audit_generic_schedule as dag
from reversible_crt import (CRTParameters, build_reconstruction, clean_xor_trace,
                            execute, invert, zero_registers, completed_character,
                            clean_phase, smoke_check)
from crt_gate_backend import GateBackend, gates


def exact_reference(value, params):
    assert abs(value) <= params.bound
    M = params.product
    digits = [(value % p)*pow(M//p, -1, p) % p for p in params.moduli]
    S = sum(t*(M//p) for t,p in zip(digits,params.moduli))
    assert (S-value) % M == 0
    eta = (S-value)//M
    A = sum(((1 << params.tau)*t)//p for t,p in zip(digits,params.moduli))
    assert (A+(1 << (params.tau-1))) >> params.tau == eta
    assert A+(1 << (params.tau-1)) < 1 << params.fp_bits
    return dict(A=A, eta=eta, value=value % params.q, digits=digits)


def check_value(value, params, oracle=None, label=None, target=0, offset=0):
    oracle = oracle or (lambda x,p:x % p)
    label = value if label is None else label
    ref = exact_reference(value, params)
    forward = build_reconstruction(params)
    registers = zero_registers(Y=offset, O=target)
    initial = registers.copy()
    execute(forward, registers, params, label, oracle)
    assert registers == zero_registers(Y=(offset+ref['value']) % params.q,
                                      O=target, A=ref['A'])
    execute(invert(forward), registers, params, label, oracle)
    assert registers == initial
    registers = zero_registers(O=target)
    execute(clean_xor_trace(params), registers, params, label, oracle)
    assert registers == zero_registers(O=target ^ ref['value'])
    phase = clean_phase(params, label, oracle,
                        lambda y: completed_character(y, params.q))
    assert phase == completed_character(value, params.q)
    return ref


def small_primes():
    found = []
    p = 3
    while True:
        if all(p % d for d in found if d*d <= p):
            found.append(p)
            yield p
        p += 2


def moduli_for(bound, q):
    ps, M = [], 1
    for p in small_primes():
        if p == q:
            continue
        ps.append(p)
        M *= p
        if M > 4*bound:
            return tuple(ps)


def integer_and_modular_tree(leaves, gamma, modulus=None):
    def reduce(value):
        return value if modulus is None else value % modulus
    values = {len(leaves)+j: tuple(reduce(x) for x in leaf)
              for j,leaf in enumerate(leaves)}
    for node in range(len(leaves)-1,1,-1):
        values[node] = compact.evaluate(values[2*node]+values[2*node+1],modulus)[0]
    env = dict(zip(dag.INPUTS, values[2]+values[3]))
    for i,expr in enumerate(terminal.SMALL_PROGRAM):
        env[f's{i}'] = reduce(eval(expr, {'__builtins__':{}}, env))
    return reduce(env['s23'] + gamma*env['s24'])


def gate_cases(rng, np_rng):
    reports = []
    maximum_xor_error = maximum_phase_error = 0.0
    total_basis = total_lockstep = 0
    for q, ps, B in [(7,(3,5),3),(5,(3,7),5)]:
        params = CRTParameters(q, ps, B)
        table = list(range(-B,B+1))
        table += [0]*((1 << (len(table)-1).bit_length())-len(table))
        backend = GateBackend(params, table)
        forward = build_reconstruction(params)
        R = backend.compile(forward)
        compiled_inverse = backend.compile(invert(forward))
        # A fresh self-inverse root XOR can have a different gate ordering
        # from its literal gate reversal. Compare their actions below.
        xor = backend.compile(clean_xor_trace(params))
        shape = len(table), 1 << params.output_bits, 2
        initial = np_rng.normal(size=shape) + 1j*np_rng.normal(size=shape)
        initial /= np.linalg.norm(initial)
        observed = np.zeros_like(initial)
        expected = np.zeros_like(initial)
        observed_phase = np.zeros_like(initial)
        expected_phase = np.zeros_like(initial)
        for address,value in enumerate(table):
            dirty = rng.getrandbits(len(backend.words['borrowed']))
            # Lockstep checks every macro boundary, including flags/carries,
            # borrowed restoration, doubled t and partial fixed-point digits.
            state = backend.state(address, borrowed=dirty)
            registers = zero_registers()
            for op in forward + invert(forward):
                gates.run(state, backend.compile_op(op))
                execute((op,), registers, params, value, lambda x,p:x % p)
                want = backend.state(address, Y=registers['Y'], A=registers['A'], borrowed=dirty)
                for name in ('r','t'):
                    gates.put(want,backend.words[name],registers[name])
                assert state == want
                total_lockstep += 1
            for target in range(1 << params.output_bits):
                state = backend.state(address, O=target, borrowed=dirty)
                original = state.copy()
                gates.run(state, xor)
                output = gates.get(state,backend.words['O'])
                want = original.copy()
                gates.put(want,backend.words['O'],target ^ (value % q))
                assert state == want
                observed[address,output,:] = initial[address,target,:]
                expected[address,target ^ (value % q),:] = initial[address,target,:]
                # Independently run the compiled R^-1 Phi R on the same
                # arbitrary external target/reference amplitudes.
                state = original.copy()
                gates.run(state,R)
                ref = exact_reference(value,params)
                assert backend.registers(state) == zero_registers(Y=value % q,A=ref['A'],O=target)
                sign = completed_character(gates.get(state,backend.words['Y']),q)
                literal_reverse = state.copy()
                gates.run(literal_reverse,R[::-1])
                assert literal_reverse == original
                gates.run(state,compiled_inverse)
                assert state == original
                observed_phase[address,target,:] = sign*initial[address,target,:]
                expected_phase[address,target,:] = completed_character(value,q)*initial[address,target,:]
                total_basis += 1
        maximum_xor_error = max(maximum_xor_error,float(np.max(np.abs(observed-expected))))
        maximum_phase_error = max(maximum_phase_error,float(np.max(np.abs(observed_phase-expected_phase))))
        reports.append(dict(parameters=asdict(params),table=table,
                            forward=backend.report(R),clean_xor=backend.report(xor)))
    assert maximum_xor_error < 1e-12 and maximum_phase_error < 1e-12
    return dict(circuits=reports,basis_cases=total_basis,macro_boundary_checks=total_lockstep,
                max_entangled_xor_amplitude_error=maximum_xor_error,
                max_entangled_phase_amplitude_error=maximum_phase_error)


def main():
    rng = random.Random(20260914)
    np_rng = np.random.default_rng(20260914)
    count = negative = zero = eta_equal_K = 0
    for ps in [(5,), (3,5), (3,5,7), (3,5,7,11), (5,7,11,13)]:
        params = CRTParameters(101,ps,(prod(ps)-1)//4)
        for value in range(-params.bound,params.bound+1):
            ref = check_value(value,params,target=rng.getrandbits(params.output_bits),
                              offset=rng.randrange(params.q))
            count += 1
            negative += value < 0
            zero += value == 0
            eta_equal_K += ref['eta'] == len(ps)
    extra_cases = 0
    primes = list()
    for p in small_primes():
        if p != 101:
            primes.append(p)
        if len(primes) == 9:
            break
    for K in (1,2,3,4,5,7,8,9):
        ps = tuple(primes[:K]) if K > 1 else (5,)
        params = CRTParameters(101,ps,(prod(ps)-1)//4)
        values = {-params.bound,-params.bound+1,-1,0,1,params.bound-1,params.bound}
        values.update(rng.randint(-params.bound,params.bound) for _ in range(30))
        for value in sorted(values):
            check_value(value,params,target=rng.getrandbits(params.output_bits))
            extra_cases += 1
    # Coprime odd composite auxiliary moduli are also valid for the CRT lemma.
    params = CRTParameters(101,(9,25,49),(9*25*49-1)//4)
    for value in (-params.bound,-1,0,1,params.bound):
        check_value(value,params)
        extra_cases += 1
    # Large signed integers and a 127-bit output accumulator at word level.
    large_bound = 1 << 256
    params = CRTParameters(2**127-1,moduli_for(large_bound,2**127-1),large_bound)
    large_values = [-large_bound,-large_bound+1,-1,0,1,large_bound-1,large_bound]
    large_values += [rng.randint(-large_bound,large_bound) for _ in range(25)]
    for value in large_values:
        check_value(value,params,target=rng.getrandbits(params.output_bits))

    # Nonzero fixed-point seeds test inverse permutation behavior only.
    # Reconstruction's advertised semantics require A initially zero.
    params = CRTParameters(7,(3,5),3)
    trace = build_reconstruction(params)
    for _ in range(128):
        value = rng.randint(-3,3)
        registers = zero_registers(Y=rng.randrange(7),O=rng.randrange(8),A=rng.randrange(1<<params.fp_bits))
        initial = registers.copy()
        execute(trace,registers,params,value,lambda x,p:x % p)
        execute(invert(trace),registers,params,value,lambda x,p:x % p)
        assert registers == initial

    # Full integer-polynomial -> auxiliary residue -> reversible CRT bridge.
    # Use the paper's conservative height bound, not a bound fit to outcomes.
    trees = []
    for q in (3,5):
        n = q.bit_length()
        H = n+10+12*(20*n+16)  # four leaves: h=2
        B = 1 << H
        tree_params = CRTParameters(q,moduli_for(B,q),B)
        for _ in range(8):
            leaves = [tuple(rng.randrange(q) for _ in range(4))+(1,) for _ in range(4)]
            gamma = rng.randrange(q)
            if q == 5 and _ == 0:
                # Fixed canonical-coefficient example with a NEGATIVE integer
                # lift; auxiliary residues must reconstruct its signed value.
                leaves = [(2,2,0,2,1),(4,1,3,2,1),(0,4,3,1,1),(1,4,0,2,1)]
                gamma = 0
            value = integer_and_modular_tree(leaves,gamma)
            assert abs(value) < B
            requests = []
            @lru_cache(maxsize=None)
            def residue(p):
                result = integer_and_modular_tree(leaves,gamma,p)
                assert result == value % p
                return result
            def oracle(label,p):
                requests.append(p)
                return residue(p)
            check_value(value,tree_params,oracle=oracle,label=0,target=rng.getrandbits(n))
            assert len(requests) == 12*len(tree_params.moduli)
            trees.append(dict(q=q,height=2,integer_sign=(value>0)-(value<0),
                              integer_bits=abs(value).bit_length(),certified_height_bits=H,
                              moduli=len(tree_params.moduli),root_oracle_calls=len(requests)))

    assert any(t['integer_sign'] < 0 for t in trees)
    assert any(t['integer_sign'] == 0 for t in trees)
    assert any(t['integer_sign'] > 0 for t in trees)

    rejected = []
    invalid = [('guard', (7,(3,5),4,None)), ('precision',(7,(3,5),3,3)),
               ('noncoprime',(7,(9,15),1,None)), ('even',(7,(2,5),1,None))]
    for name,args in invalid:
        try:
            CRTParameters(*args)
        except ValueError:
            rejected.append(name)
    assert len(rejected) == len(invalid)
    params = CRTParameters(7,(3,5),3)
    trace = build_reconstruction(params)
    # Incorrect floor instead of nearest-integer correction: reject by output.
    wrong_rounding = tuple(op for op in trace if op.kind != 'fp_constant')
    registers = zero_registers()
    execute(wrong_rounding,registers,params,-1,lambda x,p:x % p)
    assert registers['Y'] != (-1) % 7
    wrong_rounding_output = registers['Y']
    # Dropping fixed-point uncomputation leaves detectable input-dependent A.
    registers = zero_registers()
    execute(trace,registers,params,1,lambda x,p:x % p)
    faulty_inverse = tuple(op for op in invert(trace) if op.kind != 'fp_controlled')
    execute(faulty_inverse,registers,params,1,lambda x,p:x % p)
    assert registers['A'] != 0
    leftover_fixed_point = registers['A']

    gate_report = gate_cases(rng,np_rng)
    report = dict(status='passed',scope='complete streaming CRT word trace plus small X/CNOT/Toffoli reference circuits',
                  exhaustive_signed_cases=count,negative_cases=negative,zero_cases=zero,
                  quotient_equal_modulus_count_cases=eta_equal_K,
                  additional_guard_and_K_boundary_cases=extra_cases,
                  large_127bit_output_cases=len(large_values),nonzero_fixed_point_inverse_cases=128,
                  polynomial_tree_cases=trees,gate_validation=gate_report,
                  rejected_parameters=rejected,
                  negative_controls=dict(wrong_rounding_output=wrong_rounding_output,
                                         expected_output=6,missing_cleanup_leftover_A=leftover_fixed_point),
                  mandatory_ledger_smoke_cases=smoke_check(),
                  limitations=['Cryptographic root oracle not synthesized in the gate backend.',
                               'Gate backend is a reference implementation with separately reported scratch.',
                               'Character phase is a specified diagonal operation; existing Jacobi gate audit is separate.',
                               'Finite tests supplement the mathematical composition proof.'])
    Path(__file__).with_name('reversible_crt_validation_report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
