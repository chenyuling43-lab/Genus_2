"""Complete classical Cantor addition for genus two over an odd prime field.

Canonical pairs use coefficient arrays in increasing order.  An identity is
((1,), (0,)); a point (x,y) is ((-x mod p,1),(y,)).  The field modulus must
be an odd prime and f a square-free polynomial of degree five.  Arithmetic
is exact Python integer arithmetic.  This is a reference algorithm, not a
compiled quantum circuit or a fixed-degree integer CRT addition law.
"""
import json
from collections import Counter
from audit import (all_divisors, curve, encode, pgcd, pmul, pdiv, psub,
                   recover, schedule, trim)


def padd(a, b, p):
    return trim([((a[i] if i < len(a) else 0) +
                  (b[i] if i < len(b) else 0)) % p
                 for i in range(max(len(a), len(b)))])


def pscale(a, s, p):
    return trim([s*x % p for x in a])


def pxgcd(a, b, p):
    """Return monic d and Bezout s,t with d=s*a+t*b."""
    r0, r1 = list(a), list(b)
    s0, s1, t0, t1 = [1], [0], [0], [1]
    while r1 != [0]:
        q, r = pdiv(r0, r1, p)
        r0, r1 = r1, r
        s0, s1 = s1, psub(s0, pmul(q, s1, p), p)
        t0, t1 = t1, psub(t0, pmul(q, t1, p), p)
    inv = pow(r0[-1], -1, p)
    return pscale(r0, inv, p), pscale(s0, inv, p), pscale(t0, inv, p)


def exact_div(a, b, p):
    q, r = pdiv(a, b, p)
    assert r == [0], ('non-exact division', a, b, r, p)
    return q


def canonical(u, v, p):
    u = trim([x % p for x in u])
    assert u != [0]
    u = pscale(u, pow(u[-1], -1, p), p)
    v = pdiv(trim([x % p for x in v]), u, p)[1]
    return tuple(u), tuple(v)


def valid(D, f, p):
    u, v = map(list, D)
    return (len(u) <= 3 and u[-1] == 1 and trim(u.copy()) == u and
            trim(v.copy()) == v and
            (len(v) < len(u) or (u == [1] and v == [0])) and
            pdiv(psub(f, pmul(v, v, p), p), u, p)[1] == [0])


def negate(D, p):
    return canonical(list(D[0]), [(-x) % p for x in D[1]], p)


def cantor_add(D, E, f, p, validate=True):
    """Complete composition and reduction, including all degree changes.

    Inputs are reduced Mumford pairs.  The two xgcd calls each process
    polynomials of degree at most two.  Composition produces deg(u)<=4,
    deg(v)<deg(u).  Thus at most one reduction produces deg(u)<=2.
    """
    if validate:
        assert valid(D, f, p) and valid(E, f, p)
    u1, v1 = map(list, D)
    u2, v2 = map(list, E)
    d0, e1, e2 = pxgcd(u1, u2, p)
    d, c1, c2 = pxgcd(d0, padd(v1, v2, p), p)
    s1, s2, s3 = pmul(c1, e1, p), pmul(c1, e2, p), c2
    u = exact_div(pmul(u1, u2, p), pmul(d, d, p), p)
    numerator = padd(
        padd(pmul(pmul(s1, u1, p), v2, p),
             pmul(pmul(s2, u2, p), v1, p), p),
        pmul(s3, padd(pmul(v1, v2, p), f, p), p), p)
    v = pdiv(exact_div(numerator, d, p), u, p)[1]
    if len(u) > 3:
        u = exact_div(psub(f, pmul(v, v, p), p), u, p)
        u = pscale(u, pow(u[-1], -1, p), p)
        v = pdiv(pscale(v, -1, p), u, p)[1]
    answer = canonical(u, v, p)
    assert len(answer[0]) <= 3
    if validate:
        assert valid(answer, f, p)
    return answer


def encode_canonical(D):
    """Four canonical field words plus a degree tag."""
    u, v = D
    degree = len(u)-1
    if degree == 0:
        return (0, 0, 0, 0, 0)
    if degree == 1:
        return (1, 0, u[0], 0, v[0])
    return (2, u[1], u[0], v[1] if len(v)>1 else 0, v[0])


def decode_canonical(record):
    degree, a, b, s, r = record
    if degree == 0:
        assert (a, b, s, r) == (0, 0, 0, 0)
        return ((1,), (0,))
    if degree == 1:
        assert a == 0 and s == 0
        return ((b, 1), (r,))
    assert degree == 2
    return ((b, a, 1), tuple(trim([r, s])))


def all_reduced(f, p):
    result = [((1,), (0,))]
    for x in range(p):
        fx = sum(c*pow(x, i, p) for i,c in enumerate(f)) % p
        for y in range(p):
            if y*y % p == fx:
                result.append((((-x) % p, 1), (y,)))
    for a,b,s,r in all_divisors(f, p):
        result.append(((b,a,1), tuple(trim([r,s]))))
    assert len(set(result)) == len(result)
    assert all(valid(D, f, p) for D in result)
    return result


def main():
    report = {}
    for p in (3, 5, 7, 11):
        f = curve(p)
        ds = all_reduced(f, p)
        index = {D:i for i,D in enumerate(ds)}
        table = [[None]*len(ds) for _ in ds]
        counts = Counter()
        for i,D in enumerate(ds):
            assert decode_canonical(encode_canonical(D)) == D
            assert cantor_add(D, ds[0], f, p) == D
            assert cantor_add(D, negate(D,p), f, p) == ds[0]
            for j,E in enumerate(ds):
                R = cantor_add(D,E,f,p)
                table[i][j] = index[R]
                counts[f'{len(D[0])-1}+{len(E[0])-1}->{len(R[0])-1}'] += 1
                if len(D[0]) == len(E[0]) == 3:
                    drec, erec = encode_canonical(D), encode_canonical(E)
                    got,t = schedule(encode(drec[1:], 1, p),
                                     encode(erec[1:], 1, p), p)
                    if t[17] and t[24]:
                        assert recover(got,p) == encode_canonical(R)[1:]
                        counts['generic_schedule_agreement'] += 1
        n = len(ds)
        for i in range(n):
            for j in range(n):
                assert table[i][j] == table[j][i]
                for k in range(n):
                    assert table[table[i][j]][k] == table[i][table[j][k]]
        report[str(p)] = dict(curve=f, reduced_classes=n,
                              ordered_additions=n*n,
                              associativity_triples=n**3,
                              counts=dict(counts))
    print(json.dumps(report,indent=2))


if __name__ == '__main__':
    main()
