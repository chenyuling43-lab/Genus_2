"""Independent homogeneous-height and rational-reduction audit.

The AST bound checker here is independent of audit_generic_schedule.
The exact sparse-polynomial identities use rational interpolation,
not finite-field points.  No external packages are needed.
"""
import ast
import json
import audit_compact_weighted as compact


class Poly:
    def __init__(self, terms):
        self.terms = {m: c for m, c in terms.items() if c}
    @staticmethod
    def wrap(value):
        return value if isinstance(value, Poly) else Poly({(0,)*10: value})
    def __add__(self, other):
        result = self.terms.copy()
        for m,c in self.wrap(other).terms.items():
            result[m] = result.get(m,0)+c
        return Poly(result)
    __radd__ = __add__
    def __neg__(self):
        return Poly({m:-c for m,c in self.terms.items()})
    def __sub__(self, other):
        return self+-self.wrap(other)
    def __rsub__(self, other):
        return self.wrap(other)+-self
    def __mul__(self, other):
        result = {}
        for m,c in self.terms.items():
            for n,d in self.wrap(other).terms.items():
                key = tuple(x+y for x,y in zip(m,n))
                result[key] = result.get(key,0)+c*d
        return Poly(result)
    __rmul__ = __mul__
    def __pow__(self, k):
        result = self.wrap(1)
        for _ in range(k):
            result = result*self
        return result
    def is_zero(self):
        return not self.terms


def certificate():
    names = compact.dag.INPUTS
    env = {}
    for i, name in enumerate(names):
        w = (2, 2, 3, 3, 1)[i % 5]
        env[name] = ((w, 0) if i < 5 else (0, w), 1)

    def bound(t):
        if isinstance(t, ast.Name):
            return env[t.id]
        if isinstance(t, ast.Constant):
            return (0, 0), abs(t.value)
        if isinstance(t, ast.UnaryOp):
            return bound(t.operand)
        a, A = bound(t.left)
        if isinstance(t.op, ast.Pow):
            k = t.right.value
            return tuple(k * x for x in a), A ** k
        b, B = bound(t.right)
        if isinstance(t.op, (ast.Add, ast.Sub)):
            assert a == b, (ast.unparse(t), a, b)
            return a, A + B
        assert isinstance(t.op, ast.Mult)
        return tuple(x + y for x, y in zip(a, b)), A * B

    for name, expr in compact.PROGRAM.items():
        env[name] = bound(ast.parse(expr, mode='eval').body)
    outs = {name: bound(ast.parse(expr, mode='eval').body)
            for name, expr in compact.OUTPUTS.items()}
    assert [x[0] for x in outs.values()] == [(20,20), (20,20),
                                            (30,30), (30,30), (10,10)]
    for (_, norm), weight in zip(outs.values(), (2,2,3,3,1)):
        assert norm <= 2 ** (8 * weight)
    terminalN = env['s23']
    terminalD = bound(ast.parse('s4*s15', mode='eval').body)
    assert terminalN == ((12,12),640)
    assert terminalD == ((12,12),64)
    exact_env = {name: Poly({tuple(int(i==j) for j in range(10)):1})
                 for i,name in enumerate(names)}
    for i, expr in enumerate(compact.terminal.SMALL_PROGRAM):
        exact_env[f's{i}'] = eval(expr, {'__builtins__':{}}, exact_env)
    exact_norm_N = sum(abs(c) for c in exact_env['s23'].terms.values())
    exact_norm_D = sum(abs(c) for c in exact_env['s24'].terms.values())
    assert exact_norm_N == 232
    assert exact_norm_D == 64
    return dict(outputs=outs, terminal_N_DAG=terminalN, terminal_D_DAG=terminalD,
                terminal_N_exact_norm=exact_norm_N,
                terminal_D_exact_norm=exact_norm_D)


def interpolation_proof():
    a,b,c,d,s,t,u,v = [Poly({tuple(int(i==j) for j in range(10)):1})
                      for i in range(8)]
    da, dc, ds, du = b-a, d-c, t-s, v-u
    cross = a*d-c*b
    R = dc**2-cross*da
    E = ds*dc-du*da
    L = dc*du-cross*ds
    B1 = s*R-a*L-(a*b+c)*E
    B0 = u*R-c*L-b*c*E
    # R*ell is a polynomial, making these exact polynomial identities.
    for aa,cc,ss,uu in ((a,c,s,u),(b,d,t,v)):
        assert (-E*(aa**2-cc)+(L+(a+b)*E)*aa+B1-R*ss).is_zero()
        assert (-E*aa*cc+(L+(a+b)*E)*cc+B0-R*uu).is_zero()
    A = 2*L*E+(a+b)*E**2-R**2
    T = L*E-R**2
    N = L**2+2*a*L*E+(a*b-d+c)*E**2-2*s*R*E+(a+b)*R**2
    # Coefficients x^5,x^4 of ell^2-f = b3^2*u1*u2*u3.
    # f is monic degree 5 and its x^4 coefficient vanishes.
    high5 = 2*E*(L+(a+b)*E)-R**2
    assert (high5-(A+(a+b)*E**2)).is_zero()
    high4 = (L+(a+b)*E)**2-2*E*B1
    assert (high4-(N+(a+b)*A+(c+d+a*b)*E**2)).is_zero()
    # R*E^3 times coefficients of -ell mod u3.
    old_v1 = -B1*E**3-(L+(a+b)*E)*A*E+A*A-N*E**2
    old_v0 = -B0*E**3-(L+(a+b)*E)*N*E+A*N
    new_v1 = A*T-E**2*(B1*E+N)
    new_v0 = N*T-B0*E**3
    assert (old_v1-new_v1).is_zero()
    assert (old_v0-new_v0).is_zero()
    return dict(interpolation_remainders=2, quotient_coefficients=2,
                reduction_coefficients=2, identities='exact over integer polynomial ring')


if __name__ == '__main__':
    print(json.dumps(dict(height=certificate(), rational=interpolation_proof()),indent=2))
