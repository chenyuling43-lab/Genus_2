"""Reference-level validation of bounded reversible binary arithmetic.

This tests the mathematical branch trace and its inverse.  It is not a
gate-synthesized Toffoli count or a quantum-circuit simulator.
"""
from __future__ import annotations

import json
import random


def half_mod(value, q):
    value %= q
    return (value + (value & 1) * q) // 2


def eta2(odd):
    return int(odd % 8 in (3, 5))


def binary_compute(x, q):
    """Overwrites a=x, computes inverse in d and character in sign."""
    a, b, c, d, sign = x, q, 1, 0, 0
    trace = []
    active = 0
    for _ in range(2 * q.bit_length() + 1):
        old_product = a * b
        if a == 0:
            row = 0
        elif a % 2 == 0:
            row = 1
            sign ^= eta2(b)
            a //= 2
            c = half_mod(c, q)
        elif a >= b:
            row = 2
            sign ^= eta2(b)
            a = (a - b) // 2
            c = half_mod(c - d, q)
        else:
            row = 3
            sign ^= int(a % 4 == b % 4 == 3) ^ eta2(a)
            a, b = (b - a) // 2, a
            c, d = half_mod(d - c, q), c
        trace.append(row)
        if row:
            active += 1
            assert 2 * a * b <= old_product
        assert 0 <= a < q and 0 < b <= q and b % 2 == 1
        assert 0 <= c < q and 0 <= d < q
        assert (a - c * x) % q == 0
        assert (b - d * x) % q == 0
    assert a == 0
    return (a, b, c, d, sign), trace, active


def binary_reverse(state, trace, q):
    a, b, c, d, sign = state
    for row in reversed(trace):
        if row == 0:
            pass
        elif row == 1:
            a *= 2
            c = 2 * c % q
            sign ^= eta2(b)
        elif row == 2:
            a = 2 * a + b
            c = (2 * c + d) % q
            sign ^= eta2(b)
        elif row == 3:
            a, b = b, 2 * a + b
            c, d = d, (2 * c + d) % q
            sign ^= int(a % 4 == b % 4 == 3) ^ eta2(a)
        else:
            raise AssertionError("invalid row")
        assert 0 <= a < q and 0 < b <= q and b % 2 == 1
    return a, b, c, d, sign


def check(x, q):
    state, trace, steps = binary_compute(x, q)
    expected_inv = pow(x, -1, q) if x else 0
    assert state[3] == expected_inv
    expected_char = pow(x, (q - 1) // 2, q) if x else 1
    assert pow(-1, state[4], q) == expected_char
    assert binary_reverse(state, trace, q) == (x, q, 1, 0, 0)
    return steps


def is_prime(value):
    return value >= 2 and all(value % d for d in range(2, int(value ** 0.5) + 1))


def main():
    report = {"scope": "classical branch-trace validation; no synthesized gate counts"}
    primes = [q for q in range(3, 258, 2) if is_prime(q)]
    total = 0
    worst = 0
    for q in primes:
        for x in range(q):
            worst = max(worst, check(x, q))
            total += 1
    report["exhaustive"] = {"primes": len(primes), "largest_q": max(primes),
                            "inputs": total, "largest_active_step_count": worst}
    q = (1 << 127) - 1
    rng = random.Random(20260911)
    inputs = [0, 1, 2, q - 2, q - 1] + [rng.randrange(q) for _ in range(1000)]
    lengths = [check(x, q) for x in inputs]
    report["large_prime"] = {"q": str(q), "inputs": len(inputs),
                              "largest_active_step_count": max(lengths),
                              "fixed_schedule_length": 2 * q.bit_length() + 1}
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
