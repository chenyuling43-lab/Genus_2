"""Exact classical checks for the published Gaudry--Schost genus-two instance.

Parameters: Renes, Schwabe, Smith, Batina, muKummer (CHES 2016),
author version 2017-01-26, Sections 2.1 and 3.2:
https://cryptojedi.org/papers/mukummer-20170126.pdf

This validates a curve isomorphism, divisor membership and scalar order.
It does not recompute the Jacobian cardinality or compile a quantum circuit.
Run alongside cantor_complete.py and audit.py, or from the development tree.
"""
from fractions import Fraction
from math import comb, log2
from pathlib import Path
import json
import sys

HERE = Path(__file__).resolve().parent
if not (HERE / 'cantor_complete.py').exists():
    sys.path.insert(0, str(HERE.parent / 'addition_audit'))
from cantor_complete import cantor_add, valid, negate, canonical
from audit import pmul, pgcd

q = 2**127 - 1
r = 2**250 - int('334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD', 16)
rosenhain = tuple(int(x, 16) for x in (
    '15555555555555555555555555555552',
    '73E334FBB315130E05A505C31919A746',
    '552AB1B63BF799716B5806482D2D21F3'))
published_f = [0] + [int(x, 16) for x in (
    '1EDD6EE48E0C2F16F537CD791E4A8D6E',
    '73E799E36D9FCC210C9CD1B164C39A35',
    '4B9E333F48B6069CC47DC236188DF6E8',
    '219CC3F8BB9DFE2B39AD9E9F6463E172')] + [1]
u1, u0, v1, v0 = [int(x, 16) for x in (
    '7D5D9C3307E959BF27B8C76211D35E8A',
    '2703150F9C594E0CA7E8302F93079CE8',
    '444569AF177A9C1C721736D8F288C942',
    '7F26CFB225F42417316836CFF8AEFB11')]
P_published = ((u0,u1,1),(v0,v1))
IDENTITY = ((1,), (0,))


def scalar(k, P, f):
    R = IDENTITY
    for bit in bin(k)[2:]:
        R = cantor_add(R, R, f, q)
        if bit == '1':
            R = cantor_add(R, P, f, q)
    return R


def shift(poly, a):
    """Coefficients of poly(t+a), increasing order, modulo q."""
    return [sum(poly[j]*comb(j,i)*pow(a,j-i,q)
                for j in range(i,len(poly))) % q for i in range(len(poly))]


def transform(D, a):
    return canonical(shift(D[0],a), shift(D[1],a), q)


def hx(v):
    return f'{v:032X}'


def probable_prime(n):
    """Fixed-base Miller--Rabin sanity check, not a primality certificate."""
    d,s=n-1,0
    while d%2==0:
        d//=2
        s+=1
    for base in (2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53,59,61,67,71):
        x=pow(base,d,n)
        if x in (1,n-1):
            continue
        for _ in range(s-1):
            x=x*x%n
            if x==n-1:
                break
        else:
            return False
    return True


def main():
    f = [1]
    for root in (0,1)+rosenhain:
        f = pmul(f, [(-root)%q,1],q)
    assert f == published_f
    assert len(set((0,1)+rosenhain)) == 5
    assert pgcd(f, [i*f[i]%q for i in range(1,len(f))],q) == [1]
    assert valid(P_published,f,q)
    assert P_published != IDENTITY
    assert scalar(r,P_published,f) == IDENTITY
    a = -f[4]*pow(5,-1,q)%q
    f_shift = shift(f,a)
    assert f_shift[4] == 0 and f_shift[5] == 1
    P = transform(P_published,a)
    assert valid(P,f_shift,q)
    assert scalar(r,P,f_shift) == IDENTITY
    # Independently verify the isomorphism on selected multiples and sums.
    multiples = (0,1,2,3,5,16,127,20260911,r-1)
    for k in multiples:
        assert transform(scalar(k,P_published,f),a) == scalar(k,P,f_shift)
    for i,j in ((1,1),(1,2),(2,3),(5,16),(127,20260911),(1,r-1)):
        D,E = scalar(i,P,f_shift),scalar(j,P,f_shift)
        assert cantor_add(D,E,f_shift,q) == scalar((i+j)%r,P,f_shift)
    # Lucas--Lehmer proves that 2^127-1 is prime (127 itself is prime).
    ll=4
    for _ in range(125):
        ll=(ll*ll-2)%q
    assert ll==0
    assert probable_prime(r)
    report = {
        'source':'https://cryptojedi.org/papers/mukummer-20170126.pdf',
        'q_decimal':q,'r_decimal':r,'q_bits':q.bit_length(),
        'r_bits':r.bit_length(),'exact_input_bits':2*r.bit_length(),
        'published_cofactor':16,'published_group_order':16*r,
        'rosenhain_hex':[hx(x) for x in rosenhain],
        'published_f_hex':[hx(x) for x in published_f],
        'shift_x_equals_t_plus_a_hex':hx(a),
        'shifted_f_hex':[hx(x) for x in f_shift],
        'shifted_generator_u_hex':[hx(x) for x in P[0]],
        'shifted_generator_v_hex':[hx(x) for x in P[1]],
        'rP_zero_original_and_shifted':True,
        'nonidentity_generator':True,
        'isomorphism_multiples_checked':len(multiples),
        'addition_identities_checked':6,
        'primality_checks':{'q_lucas_lehmer_proof':True,
          'r_20_fixed_base_miller_rabin':True,
          'scope':'Subgroup primality is taken from the source; fixed-base Miller--Rabin is only a sanity check.'},
        'mask_union_bounds':{},
        'scope':'Classical parameter checks; source cardinality not recomputed; not a quantum gate audit.'}
    for L in (32,64,128,256,512):
        bound=Fraction((L-1)*(14*q+3),r)
        report['mask_union_bounds'][str(L)]={
            'numerator':bound.numerator,'denominator':bound.denominator,
            'upper_bound_decimal':float(bound),
            'log2_bound':log2(float(bound)),
            'state_distance_bound_2sqrt_delta':2*float(bound)**0.5}
    print(json.dumps(report,indent=2))
    (HERE/'gaudry_schost_report.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__ == '__main__':
    main()
