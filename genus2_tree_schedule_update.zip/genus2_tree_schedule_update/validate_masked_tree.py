"""Exact small-field checks for the public zero-sum masked generic tree.

This validates finite-field algebra, the mask distribution, and exact
Fourier-event probabilities. It does not compile quantum gates or certify
the separate CRT or character circuit resource estimates.
"""
import json
import sys
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path

HERE = Path(__file__).resolve()
ROOT = HERE.parents[2]
for folder in ('addition_audit', 'resource_audit', 'sampling_validation',
               'phase_terminal', 'residue_peak'):
    sys.path.insert(0, str(ROOT / 'tmp' / folder))

from audit import encode, pgcd, schedule_optimized
from cantor_complete import cantor_add, curve, encode_canonical
from validate_sampling import subgroup, phase_sign
from audit_phase_terminal import SMALL_CODES, completed_character
from audit_generic_schedule import INPUTS
from audit_compact_weighted import evaluate as compact_evaluate


def chart(D, q):
    record = encode_canonical(D)
    if record[0] < 2:
        return (0, 0, 0, 0, 1)
    return encode(record[1:], 1, q)


def terminal(D, E, q):
    env = dict(zip(INPUTS, tuple(D) + tuple(E)))
    for i, code in enumerate(SMALL_CODES):
        env[f's{i}'] = eval(code, {'__builtins__': {}}, env) % q
    return env['s23'], env['s24']


def generic(D, E, R, q):
    return (len(D[0]) == len(E[0]) == len(R[0]) == 3
            and pgcd(list(D[0]), list(E[0]), q) == [1])


def useful_probability(signs, r, k):
    sums = [0] * r
    for a in range(r):
        for b in range(r):
            sums[(a+k*b) % r] += signs[a][b]
    # Exact Parseval identity on the annihilator, excluding zero.
    return (Fraction(sum(s*s for s in sums), r**3)
            - Fraction(sum(sums)**2, r**4))


def check_case(q):
    f = curve(q)
    group, order = subgroup(f, q)
    r = len(group)
    encoded = [chart(D, q) for D in group]
    e = sum(len(D[0]) < 3 for D in group)
    generic_pairs = [[False]*r for _ in range(r)]
    values = [[None]*r for _ in range(r)]
    support_max = 0
    generic_count = 0
    checked_signs = 0
    for i,D in enumerate(group):
        if len(D[0]) == 3:
            supported = sum(len(E[0]) == 3 and
                            pgcd(list(D[0]), list(E[0]), q) != [1]
                            for E in group)
            support_max = max(support_max, supported)
            assert supported <= 8*q
        for j,E in enumerate(group):
            answer = cantor_add(D, E, f, q)
            assert answer == group[(i+j) % r]
            good = generic(D, E, answer, q)
            generic_pairs[i][j] = good
            generic_count += int(good)
            nb,db = terminal(encoded[i], encoded[j], q)
            values[i][j] = [completed_character(nb+gamma*db, q)
                            for gamma in range(q)]
            if good:
                for gamma in range(q):
                    assert values[i][j][gamma] == phase_sign(answer, gamma, q)
                    checked_signs += 1
    bad = Fraction(r*r-generic_count, r*r)
    delta = min(Fraction(1), Fraction(3*e+8*q, r))
    assert bad <= delta

    # Exhaust the exact r-by-r input domain, every L=2 mask, and every
    # field-shift seed. Tables select aP+R and bQ-R with Q=kP.
    k = 2 % r
    means = Fraction(0)
    ideal_means = Fraction(0)
    mismatch_total = 0
    bad_basis_total = 0
    max_violation = 0.0
    root_pairs = Counter()
    for mask in range(r):
        bad_basis = 0
        for a,b in product(range(r), repeat=2):
            i, j = (a+mask) % r, (k*b-mask) % r
            root_pairs[(i,j)] += 1
            bad_basis += not generic_pairs[i][j]
        bad_basis_total += bad_basis
        for gamma in range(q):
            actual = [[values[(a+mask) % r][(k*b-mask) % r][gamma]
                       for b in range(r)] for a in range(r)]
            ideal = [[phase_sign(group[(a+k*b) % r], gamma, q)
                      for b in range(r)] for a in range(r)]
            mismatch = sum(actual[a][b] != ideal[a][b]
                           for a,b in product(range(r), repeat=2))
            assert mismatch <= bad_basis
            mismatch_total += mismatch
            pa = useful_probability(actual, r, k)
            pi = useful_probability(ideal, r, k)
            assert 0 <= pa <= 1 and 0 <= pi <= 1
            epsilon = Fraction(bad_basis, r*r)
            # Equivalent exact squared inequality for the 2sqrt(epsilon)
            # variation bound; valid also when the bound exceeds one.
            assert (pa-pi)**2 <= 4*epsilon
            max_violation = max(max_violation, float(abs(pa-pi)))
            means += pa / (r*q)
            ideal_means += pi / (r*q)
    assert len(root_pairs) == r*r and set(root_pairs.values()) == {r}
    assert Fraction(bad_basis_total, r**3) == bad
    # Failure-subspace bound: mean actual failure <=
    # (sqrt(mean ideal failure) + 2sqrt(mean bad mass))^2.
    assert float(1-means) <= (float(1-ideal_means)**0.5 +
                              2*float(bad)**0.5)**2 + 1e-15

    # Exhaust L=4 mask seeds at a fixed input with all unmasked leaves 0.
    # Proper node pairs are uniform although the root sums have sum zero.
    left_pairs = Counter()
    right_pairs = Counter()
    fixed_root = Counter()
    averaged_root = Counter()
    for r1,r2,r3 in product(range(r), repeat=3):
        r4 = (-r1-r2-r3) % r
        left_pairs[(r1,r2)] += 1
        right_pairs[(r3,r4)] += 1
        fixed_root[((r1+r2) % r, (r3+r4) % r)] += 1
        for total in range(r):
            averaged_root[((r1+r2) % r, (r3+r4+total) % r)] += 1
    assert set(left_pairs.values()) == set(right_pairs.values()) == {r}
    assert len(fixed_root) == r
    assert set(averaged_root.values()) == {r*r}

    # Over jointly uniform leaves, use the actual polynomial at both
    # internal nodes and the scalar polynomial at the root. Jointly
    # uniform leaves have exactly the averaged masked-input law.
    tree_bad = tree_mismatch = tree_checks = compact_tree_mismatch = 0
    if q in (3, 5):
        poly = [[schedule_optimized(encoded[i], encoded[j], q)[0]
                 for j in range(r)] for i in range(r)]
        compact_poly = [[compact_evaluate(tuple(encoded[i]) + tuple(encoded[j]), q)[0]
                         for j in range(r)] for i in range(r)]
        for i,j,h,l in product(range(r), repeat=4):
            ig, jg = (i+j) % r, (h+l) % r
            good = generic_pairs[i][j] and generic_pairs[h][l] and generic_pairs[ig][jg]
            tree_bad += not good
            nb,db = terminal(poly[i][j], poly[h][l], q)
            compact_nb,compact_db = terminal(compact_poly[i][j], compact_poly[h][l], q)
            answer = group[(ig+jg) % r]
            for gamma in range(q):
                got = completed_character(nb+gamma*db, q)
                compact_got = completed_character(compact_nb+gamma*compact_db, q)
                expect = phase_sign(answer, gamma, q)
                if good:
                    assert got == expect
                    assert compact_got == expect
                tree_mismatch += got != expect
                compact_tree_mismatch += compact_got != expect
                tree_checks += 1
        assert Fraction(tree_bad, r**4) <= 3*bad
        assert tree_mismatch <= q*tree_bad
        assert compact_tree_mismatch <= q*tree_bad

    return dict(q=q, curve_coefficients=f, jacobian_order=order,
                subgroup_order=r, generator=group[1], lower_degree=e,
                maximum_shared_support_partners=support_max,
                generic_pair_count=generic_count,
                pair_bad_fraction=str(bad), conservative_delta=str(delta),
                generic_phase_sign_checks=checked_signs,
                two_leaf_masked_phase_checks=r**3*q,
                two_leaf_phase_mismatches=mismatch_total,
                two_leaf_mean_useful=str(means),
                ideal_mean_useful=str(ideal_means),
                largest_probability_difference=max_violation,
                four_leaf_fixed_input_mask_seeds=r**3,
                four_leaf_root_averaged_configurations=r**4,
                four_leaf_polynomial_phase_checks=tree_checks,
                four_leaf_compact_polynomial_phase_checks=tree_checks,
                four_leaf_bad_configurations=tree_bad,
                four_leaf_good_phase_checks=(tree_checks-q*tree_bad),
                four_leaf_phase_mismatches=tree_mismatch,
                four_leaf_compact_phase_mismatches=compact_tree_mismatch)


if __name__ == '__main__':
    print(json.dumps(dict(cases=[check_case(q) for q in (3,5,7)],
                          all_checks_passed=True), indent=2))
