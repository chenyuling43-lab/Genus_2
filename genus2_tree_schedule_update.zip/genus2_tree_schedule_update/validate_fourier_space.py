#!/usr/bin/env python3
"""Exact modular-shift checks and numerical Fourier-readout tail checks.

Run: python3 validate_fourier_space.py
No quantum circuit simulator is required.  The integer checks audit the
five-addition reversible schedule.  The floating-point checks evaluate
the exact phase-estimation distribution rather than sampled outcomes.
The cited ripple-adder gate decomposition is not recompiled by this test.
"""
import json
import math
from pathlib import Path

import numpy as np


def modular_shift(r, x, c0, d):
    m = (r - 1).bit_length()
    modulus = 1 << (m + 1)
    c = d * c0
    a = (x + c) % modulus
    a = (a - r) % modulus
    f = (a >> m) & 1
    a = (a + f * r) % modulus
    assert a < r
    a = (a - c) % modulus
    f ^= (a >> m) & 1
    a = (a + c) % modulus
    f ^= 1
    assert f == 0 and (a >> m) == 0
    assert a == (x + d * c0) % r
    return a


def phase_distribution(r, j, t):
    size = 1 << t
    z = np.arange(size, dtype=np.float64)
    delta = j / r - z / size
    # sinc form handles theta=z/M exactly, including j=0.
    p = (np.sinc(size * delta) / np.sinc(delta)) ** 2
    assert abs(float(p.sum()) - 1.0) < 2e-10
    return p


def recycled_phase_distribution(r, j, t):
    """Enumerate adaptive single-control measurements, least bit first."""
    distribution = np.ones(1)
    theta = j / r
    for power in reversed(range(t)):
        partial = np.arange(len(distribution), dtype=np.float64)
        correction = partial / (2 ** (t - power))
        angle = 2 * math.pi * ((2 ** power) * theta - correction)
        zero_probability = (1 + np.cos(angle)) / 2
        distribution = np.concatenate(
            (distribution * zero_probability,
             distribution * (1 - zero_probability))
        )
    return distribution


def main():
    shifts = 0
    for r in range(3, 96):
        for x in range(r):
            for c in range(r):
                for d in (0, 1):
                    modular_shift(r, x, c, d)
                    shifts += 1
    eps_joint = 0.1
    n_phases = 0
    recycled_checks = 0
    worst = (0.0, None)
    for r in range(3, 64):
        m = (r - 1).bit_length()
        t = m + math.ceil(math.log2(4 + 2 / eps_joint))
        size = 1 << t
        z = np.arange(size, dtype=np.int64)
        # Exact integer rounding, with ties consistently rounded upward.
        decode = ((2 * r * z + size) // (2 * size)) % r
        for j in range(r):
            p = phase_distribution(r, j, t)
            err = float(p[decode != j].sum())
            assert err <= eps_joint / 2 + 1e-12
            if err > worst[0]:
                worst = (err, {"r": r, "j": j, "t": t})
            n_phases += 1
            if r in (3, 5, 7, 23):
                iterative = recycled_phase_distribution(r, j, t)
                assert np.max(np.abs(iterative - p)) < 2e-11
                recycled_checks += 1
    # Explicit arbitrary entangled input verifies the classical-channel
    # description and the joint total variation estimate.
    rng = np.random.default_rng(9071)
    joint_checks = 0
    worst_tv = 0.0
    for r in (3, 5, 7, 11, 23):
        m = (r - 1).bit_length()
        t = m + math.ceil(math.log2(4 + 2 / eps_joint))
        size = 1 << t
        z = np.arange(size, dtype=np.int64)
        decode = ((2 * r * z + size) // (2 * size)) % r
        channel = np.zeros((r, r))
        for j in range(r):
            p = phase_distribution(r, j, t)
            channel[:, j] = np.bincount(decode, weights=p, minlength=r)
        for _ in range(12):
            state = rng.normal(size=(r, r)) + 1j * rng.normal(size=(r, r))
            state /= np.linalg.norm(state)
            ideal = np.abs(np.fft.fft2(state, norm="ortho")) ** 2
            observed = channel @ ideal @ channel.T
            tv = float(np.abs(observed - ideal).sum() / 2)
            assert tv <= eps_joint + 1e-12
            worst_tv = max(worst_tv, tv)
            joint_checks += 1
    report = {
        "modular_shift_basis_checks": shifts,
        "moduli_shift": "all integers 3 through 95",
        "phase_estimation_eigenstate_checks": n_phases,
        "adaptive_recycled_control_distribution_checks": recycled_checks,
        "moduli_fourier": "all integers 3 through 63",
        "target_joint_tv": eps_joint,
        "worst_eigenlabel_error": worst[0],
        "worst_eigenlabel_instance": worst[1],
        "entangled_input_checks": joint_checks,
        "worst_joint_tv": worst_tv,
        "status": "PASS",
        "scope": "exact integer schedule and numerical full QPE distributions; no gate-level compilation",
    }
    Path(__file__).with_name("fourier_validation_report.json").write_text(
        json.dumps(report, indent=2) + "\n"
    )
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
