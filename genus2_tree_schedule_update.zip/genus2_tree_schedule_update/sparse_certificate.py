"""Exact sparse expansion to detect removable square monomial factors.

This is an independent algebraic audit, not the implemented circuit.
It uses only the standard library.
"""
import ast
from functools import reduce
from math import gcd
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'resource_audit'))
from audit_generic_schedule import INPUTS, PROGRAM
from audit_phase_terminal import SMALL_PROGRAM

ZERO = (0,) * len(INPUTS)


def add(a, b, sign=1):
    c = a.copy()
    for m, v in b.items():
        c[m] = c.get(m, 0) + sign * v
        if not c[m]:
            del c[m]
    return c


def multiply(a, b):
    c = {}
    for m, v in a.items():
        for n, w in b.items():
            k = tuple(x + y for x, y in zip(m, n))
            c[k] = c.get(k, 0) + v * w
    return {k: v for k, v in c.items() if v}


def evaluate(node, known):
    if isinstance(node, ast.Name):
        return known[node.id]
    if isinstance(node, ast.Constant):
        return {ZERO: node.value}
    if isinstance(node, ast.UnaryOp):
        assert isinstance(node.op, ast.USub)
        return {m: -v for m, v in evaluate(node.operand, known).items()}
    a = evaluate(node.left, known)
    if isinstance(node.op, ast.Pow):
        p = ast.literal_eval(node.right)
        return reduce(multiply, [a] * p, {ZERO: 1})
    b = evaluate(node.right, known)
    if isinstance(node.op, ast.Add):
        return add(a, b)
    if isinstance(node.op, ast.Sub):
        return add(a, b, -1)
    if isinstance(node.op, ast.Mult):
        return multiply(a, b)
    raise ValueError(ast.dump(node))


def main():
    known = {name: {tuple(int(i == j) for j in range(len(INPUTS))): 1}
             for i, name in enumerate(INPUTS)}
    for i, text in enumerate(PROGRAM[:42]):
        known[f't{i}'] = evaluate(ast.parse(text, mode='eval').body, known)
    for i, text in enumerate(SMALL_PROGRAM):
        known[f's{i}'] = evaluate(ast.parse(text, mode='eval').body, known)
    factor_exponents = tuple(14 if name == 'z1' else 6 if name == 'z2' else 0
                             for name in INPUTS)
    factor = {factor_exponents: 4}
    assert known['t40'] == multiply(factor, known['s23'])
    assert known['t41'] == multiply(factor, known['s24'])
    report = {}
    for name in ['t40', 't41', 's23', 's24']:
        p = known[name]
        minimum = tuple(min(m[i] for m in p) for i in range(len(INPUTS)))
        report[name] = dict(terms=len(p), degree=max(map(sum, p)),
                           norm=sum(abs(v) for v in p.values()),
                           coefficient_gcd=reduce(gcd, p.values()),
                           minimum_exponents=dict(zip(INPUTS, minimum)))
    report['exact_integer_identities'] = [
        't40 = 4*z1**14*z2**6*s23',
        't41 = 4*z1**14*z2**6*s24']
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
