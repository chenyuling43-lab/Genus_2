"""Reproduce the 57-register, dead-code-eliminated generic certificate."""
import ast
import json
from collections import Counter
from audit_generic_schedule import Bound, INPUTS, PROGRAM, bound, primitives


def main():
    program = {f't{i}': expr for i, expr in enumerate(PROGRAM[:55]) if i != 43}
    program.update(t55='t31*t41', t56='t55*t5', t57='t31*t37')
    outputs = dict(U1='t35*t56', U0='t40*t55', V1='t50*t57',
                   V0='t54*t56', Z='t22*t41')
    known = {name: Bound(1, 1) for name in INPUTS}
    forward, writes = Counter(), Counter()
    dependencies = {}
    for name, expr in program.items():
        node = ast.parse(expr, mode='eval').body
        known[name] = bound(node, known)
        forward.update(primitives(node))
        dependencies[name] = {x.id for x in ast.walk(node) if isinstance(x, ast.Name)}
    out = {}
    used = set()
    for name, expr in outputs.items():
        node = ast.parse(expr, mode='eval').body
        value = bound(node, known)
        out[name] = dict(degree_upper=value.degree, l1_upper=value.norm)
        writes.update(primitives(node))
        used.update(x.id for x in ast.walk(node) if isinstance(x, ast.Name))
    while True:
        expanded = used | set().union(*(dependencies.get(x, set()) for x in used))
        if expanded == used:
            break
        used = expanded
    assert set(program) <= used, 'Unexpected retained dead temporary'
    clean = forward + forward + writes
    assert len(program) == 57
    assert clean == Counter(multiply_accumulate=157, square_accumulate=22,
                            linear_accumulate=6)
    assert max(x['degree_upper'] for x in out.values()) == 165
    assert max(x['l1_upper'] for x in out.values()) < 2**47
    print(json.dumps(dict(temporaries=len(program), forward=dict(forward),
                          clean_node=dict(clean), outputs=out,
                          width_in_field_registers=10+5+len(program)), indent=2))


if __name__ == '__main__':
    main()
