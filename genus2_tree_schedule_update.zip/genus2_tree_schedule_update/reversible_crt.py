"""Explicit reversible CRT reconstruction, using the streaming digit schedule.

Registers: canonical q-accumulator Y; unsigned fixed-point A; two short
residue words r,t; arbitrary external XOR target O. No zi or eta word.
Root evaluation is a clean XOR oracle supplied by the caller. Its inverse
invocation denotes a FRESH corrected invocation if it uses measurements.
This interpreter validates word-level operations; crt_gate_backend.py
also compiles small complete examples into X/CNOT/Toffoli networks.
"""
from dataclasses import dataclass, asdict
from math import gcd, prod
import argparse
import json


def ceil_log2(n):
    if n < 1:
        raise ValueError('positive integer required')
    return (n-1).bit_length()


@dataclass(frozen=True)
class CRTParameters:
    q: int
    moduli: tuple
    bound: int
    tau: int | None = None

    def __post_init__(self):
        object.__setattr__(self, 'moduli', tuple(self.moduli))
        if self.q < 3 or self.q % 2 == 0 or self.bound < 1 or not self.moduli:
            raise ValueError('q must be odd >=3, bound >=1, and moduli nonempty')
        for i, p in enumerate(self.moduli):
            if p < 3 or p % 2 == 0 or gcd(p, self.q) != 1:
                raise ValueError('auxiliary moduli must be odd >=3 and coprime to q')
            if any(gcd(p, other) != 1 for other in self.moduli[:i]):
                raise ValueError('auxiliary moduli must be pairwise coprime')
        if self.product <= 4*self.bound:
            raise ValueError('guard requires product(moduli) > 4*bound')
        minimum = ceil_log2(8*len(self.moduli))
        if self.tau is None:
            object.__setattr__(self, 'tau', minimum)
        elif self.tau < minimum:
            raise ValueError('tau must be at least ceil(log2(8K))')

    @property
    def product(self):
        return prod(self.moduli)

    @property
    def fp_bits(self):
        return self.tau + ceil_log2(len(self.moduli)) + 1

    @property
    def residue_bits(self):
        return max(p.bit_length() for p in self.moduli)

    @property
    def output_bits(self):
        return self.q.bit_length()


@dataclass(frozen=True)
class Op:
    kind: str
    target: str = ''
    source: str = ''
    constant: int = 0
    modulus: int = 0
    bit: int = 0
    direction: int = 1

    def inverse(self):
        return self if self.kind in ('root_xor', 'copy_xor', 'clean_checkpoint') else Op(
            self.kind, self.target, self.source, self.constant, self.modulus,
            self.bit, -self.direction)


def invert(trace):
    return tuple(op.inverse() for op in reversed(trace))


def build_reconstruction(params):
    ops = []
    for p in params.moduli:
        Mi = params.product//p
        a = pow(Mi, -1, p)
        ops += [Op('root_xor', 'r', modulus=p), Op('mac', 't', 'r', a, p)]
        for j in range(1, params.tau+1):
            ops += [Op('double', 't', modulus=p),
                    Op('fp_controlled', 'A', 't', 1 << (params.tau-j), bit=0)]
        # Restore t by reversing only the doublings. Retain the digit in A.
        ops += [Op('double', 't', modulus=p, direction=-1)]*params.tau
        ops += [Op('mac', 'Y', 't', Mi % params.q, params.q),
                Op('mac', 't', 'r', a, p, direction=-1),
                Op('root_xor', 'r', modulus=p), Op('clean_checkpoint')]
    # A's upper bits are eta controls. Never allocate a quotient word.
    half = 1 << (params.tau-1)
    ops.append(Op('fp_constant', 'A', constant=half))
    for j in range(params.tau, params.fp_bits):
        c = (params.product * (1 << (j-params.tau))) % params.q
        ops.append(Op('mod_controlled', 'Y', 'A', c, params.q, j, -1))
    ops += [Op('fp_constant', 'A', constant=half, direction=-1), Op('clean_checkpoint')]
    return tuple(ops)


def zero_registers(Y=0, O=0, A=0):
    return dict(Y=Y, A=A, r=0, t=0, O=O)


def execute(trace, registers, params, logical_input, root_oracle, observer=None):
    """Mutate registers by the specified operations, without storing old values.

    root_oracle(input,p) returns the canonical root residue. In particular,
    it must recompute the SAME fixed integer polynomial for every p.
    """
    widths = dict(Y=params.output_bits, O=params.output_bits,
                  A=params.fp_bits, r=params.residue_bits, t=params.residue_bits)
    assert set(registers) == set(widths)
    assert all(0 <= registers[k] < 1 << width for k, width in widths.items())
    for index, op in enumerate(trace):
        if op.kind == 'root_xor':
            residue = root_oracle(logical_input, op.modulus)
            assert 0 <= residue < op.modulus
            registers[op.target] ^= residue
        elif op.kind == 'mac':
            assert 0 <= registers[op.target] < op.modulus
            registers[op.target] = (registers[op.target] + op.direction*op.constant*registers[op.source]) % op.modulus
        elif op.kind == 'double':
            assert 0 <= registers[op.target] < op.modulus
            multiplier = 2 if op.direction == 1 else pow(2, -1, op.modulus)
            registers[op.target] = multiplier*registers[op.target] % op.modulus
        elif op.kind in ('fp_controlled', 'fp_constant'):
            control = 1 if op.kind == 'fp_constant' else (registers[op.source] >> op.bit) & 1
            registers['A'] = (registers['A'] + op.direction*control*op.constant) % (1 << params.fp_bits)
        elif op.kind == 'mod_controlled':
            assert 0 <= registers[op.target] < op.modulus
            control = (registers[op.source] >> op.bit) & 1
            registers[op.target] = (registers[op.target] + op.direction*control*op.constant) % op.modulus
        elif op.kind == 'copy_xor':
            registers[op.target] ^= registers[op.source]
        elif op.kind == 'clean_checkpoint':
            assert registers['r'] == registers['t'] == 0
        else:
            raise ValueError(op.kind)
        if observer is not None:
            observer(index, op, registers.copy())
    return registers


def clean_xor_trace(params):
    forward = build_reconstruction(params)
    return forward + (Op('copy_xor', 'O', 'Y'),) + invert(forward)


def completed_character(value, prime):
    """Completed Legendre sign: zero has sign +1. Requires prime modulus."""
    value %= prime
    if value == 0:
        return 1
    result = pow(value, (prime-1)//2, prime)
    if result not in (1, prime-1):
        raise ValueError('character helper requires a prime modulus')
    return 1 if result == 1 else -1


def clean_phase(params, logical_input, root_oracle, phase_function):
    registers = zero_registers()
    forward = build_reconstruction(params)
    execute(forward, registers, params, logical_input, root_oracle)
    phase = phase_function(registers['Y'])
    execute(invert(forward), registers, params, logical_input, root_oracle)
    assert registers == zero_registers()
    return phase


def smoke_check():
    """Small mandatory end-to-end check used by the existing ledger entry point."""
    params = CRTParameters(7, (3, 5), 3)
    trace = clean_xor_trace(params)
    for value in range(-3, 4):
        for target in (0, 3, 7):
            regs = zero_registers(O=target)
            execute(trace, regs, params, value, lambda x, p: x % p)
            assert regs == zero_registers(O=target ^ (value % 7))
    return 21


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--trace', help='write a small complete forward/XOR/reverse trace')
    args = parser.parse_args()
    params = CRTParameters(7, (3, 5), 3)
    data = dict(parameters=asdict(params), fp_bits=params.fp_bits,
                forward_operations=[asdict(op) for op in build_reconstruction(params)],
                clean_xor_operations=[asdict(op) for op in clean_xor_trace(params)],
                smoke_checks=smoke_check())
    if args.trace:
        example_states = []
        example = zero_registers(O=5)
        def observe(index, op, registers):
            example_states.append(dict(index=index, operation=asdict(op), registers=registers))
        execute(clean_xor_trace(params), example, params, -1, lambda x,p:x % p, observe)
        assert example == zero_registers(O=3)
        data['example'] = dict(integer_input=-1, initial_target=5, final_registers=example,
                               clean_xor_register_trace=example_states)
        with open(args.trace, 'w', encoding='utf-8') as stream:
            json.dump(data, stream, indent=2)
            stream.write('\n')
    print(json.dumps(dict(smoke_checks=data['smoke_checks'], fp_bits=params.fp_bits,
                         forward_operations=len(data['forward_operations']),
                         clean_xor_operations=len(data['clean_xor_operations'])), indent=2))
