# Genus-two phase-oracle validation companion

This accompanies `genus2_phase_oracles_revised.tex`. The manuscript is
self-contained: compile it twice with `pdflatex`; no external bibliography,
images, or source-code listings are needed.

Extract this archive into one directory and run the commands below there.
Python 3.10 or later is required. Only `validate_sampling.py` needs NumPy;
the other scripts use the standard library.

```sh
python3 audit.py
python3 cantor_complete.py
python3 validate_binary_backend.py
python3 audit_binary_jacobi.py
python3 audit_generic_schedule.py
python3 audit_optimized_certificate.py
python3 audit_phase_terminal.py
python3 sparse_certificate.py
python3 validate_sampling.py
```

The arithmetic checks cover the original and smaller-scale generic
addition formulas, arbitrary-target cleanup, integer/reduction
compatibility, complete small-field Cantor addition, fixed binary
inversion/Jacobi traces, and static register/degree certificates.
`REPORT.md` records the earlier arithmetic coverage. Its workspace paths
refer to the original development layout; the scripts are placed together
in this archive so their imports also work after extraction.

The new direct terminal oracle has 25 temporary field words and exact
local phase cost `68 Macc + 12 Sacc + 2 Add + 2 C_gamma + G_chi`.
`audit_phase_terminal.py` checks the phase against an independent affine
interpolation oracle, including zero completion and independently scaled
weighted inputs. Its tests include the 127-bit base field `2^127-1`, but
do not certify a cryptographic subgroup or a complete attack benchmark.
`TERMINAL_VALIDATION.md` explains the test scope and precise totals.
`sparse_certificate.py` checks the square-factor cancellation as an exact
integer polynomial identity, and certifies numerator degree 19 and norm
232, denominator degree 18 and norm 64. The associated JSON reports record
the expected results.

`validate_sampling.py` verifies abstract Fourier sampling on four complete
small-field instances, canonical-phase covariance on exact and rectangular
domains, and the explicit field-shift rectangle obstruction. Group orders
are independently checked by counting curve points over the prime field
and its quadratic extension. Sign counts use exact integers and fractions;
NumPy transforms use complex128 with the stated numerical tolerance.

The supplied MATLAB listings remain in the paper and were not executed
in this environment. None of these scripts synthesizes or simulates a
gate-level quantum circuit. The generic terminal saving does not prove a
whole-algorithm qubit reduction. The complete low-degree CRT-compatible
exceptional-case program and concrete canonical circuit constants remain
uninstantiated, as stated in the manuscript.

The source retains six main sections, coefficient weights `(2,2,3,3)`,
CFS as reference [4], and the Chen et al. comparison. Longer derivations,
primitive inventories, and conditional residue bounds are in appendices.
