# Public zero-sum masks for the generic residue tree

`masked_tree.tex` proves an approximate phase construction on the exact
uniform domain Z_r x Z_r. The central algebraic estimate is

    delta_G <= min(1, (3e + 8q)/r) <= min(1, (14q + 3)/r),

where e is the number of subgroup elements with reduced degree below two.
There are L - 1 internal nodes. The expected fraction of basis states with
at least one exceptional true addition is at most

    epsilon_tree = min(1, (L - 1) delta_G).

With a fresh field shift and masks, the mean useful-sample probability is
at least

    max(0, 1 - (sqrt(1 - V_G) + 2 sqrt(epsilon_tree))^2).

The proof projects onto all failed Fourier outcomes, including the origin
and off-line outcomes, then uses the triangle and Minkowski inequalities.
It does not assume that the implemented phase remains periodic on bad
inputs. For r = Theta(q^2) and polynomially many leaves this is
1 - O(L/q). A weaker trace-distance consequence is also available, but is
not needed for the stated success bound.

Run `python3 validate_masked_tree.py`. The script imports the existing
Cantor, generic-schedule, terminal-phase, compact weighted map, recursive
expression, and subgroup validation modules.
It also works in the flattened validation bundle with those modules in the
same directory. The subgroup module requires NumPy, although the new exact
probability calculations themselves use only rational arithmetic.

All checks passed on the existing square-free test curves over q = 3, 5,
7. Their prime-order subgroups have orders 11, 23, 11, respectively.

- 74,145 two-leaf phase evaluations exhaust every scalar input, every
  zero-sum mask, and every field shift on the three test cases.
- Generic inputs always give the ideal field-shifted phase.
- Exact rational Fourier useful-event probabilities satisfy both the
  state-distance and failure-projector bounds.
- Four-leaf mask distributions were exhaustively checked at fixed input
  and after averaging a uniform total group element.
- The q = 3 and q = 5 cases additionally checked 1,443,128 phases for
  each of two actual four-leaf polynomial trees: the earlier degree-165
  internal map and the NEW compact weighted internal map with output
  degrees (32,31,48,47,15). Both use the degree-19 terminal polynomial.
  These checks include invalid intermediate tuples, all mask-averaged
  input configurations, and every field shift. Every good tree
  configuration gives the ideal phase for both maps; mismatches on bad
  configurations satisfy the stated bounds.

The conservative bound delta_G = 1 is vacuous on these very small fields;
the tests validate the identities and their precise scope, not a numerical
small-field performance gain. They do not synthesize quantum gates or
verify the independent guarded-CRT reconstruction and character-circuit
resource accounting.

The masked circuit is a total polynomial circuit. It is an approximate
phase oracle for the specified input state, not an exact complete group
law or a diamond-norm approximation to group addition. Masks are public
classical constants; lower-degree table entries are replaced by a fixed
dummy tuple and covered by the error estimate.
