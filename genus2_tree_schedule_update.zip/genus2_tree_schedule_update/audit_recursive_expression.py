"""Explicit low-scratch clean evaluator for the existing generic polynomial map.

Named temporaries are recursively expanded.  A sum is accumulated term by
term into the requested target.  For a product, its non-input operands are
computed into clean scratch words, multiplied into the target, and reversed.
Squares use a single operand word.  Child order minimizes peak scratch.
The count is for clean field primitives, not Clifford+T gates.
"""
import ast
import json
import sys
from collections import Counter
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'resource_audit'))
from audit_generic_schedule import INPUTS, PROGRAM

program = {f't{i}': x for i, x in enumerate(PROGRAM[:55]) if i != 43}
program.update(t55='t31*t41', t56='t55*t5', t57='t31*t37')
outputs = dict(U1='t35*t56', U0='t40*t55', V1='t50*t57',
               V0='t54*t56', Z='t22*t41')
trees = {k: ast.parse(v, mode='eval').body for k, v in program.items()}

@dataclass
class Cost:
    scratch: int
    counts: Counter

def resolve(t):
    while isinstance(t, ast.Name) and t.id in trees:
        t = trees[t.id]
    return t

def literal(t):
    if isinstance(t, ast.Constant):
        return t.value
    if isinstance(t, ast.UnaryOp) and isinstance(t.op, ast.USub):
        a = literal(t.operand)
        return None if a is None else -a
    return None

def terms(t, scale=1):
    t = resolve(t)
    if isinstance(t, ast.UnaryOp):
        yield from terms(t.operand, -scale if isinstance(t.op, ast.USub) else scale)
    elif isinstance(t, ast.BinOp) and isinstance(t.op, (ast.Add, ast.Sub)):
        yield from terms(t.left, scale)
        yield from terms(t.right, -scale if isinstance(t.op, ast.Sub) else scale)
    elif isinstance(t, ast.BinOp) and isinstance(t.op, ast.Mult) and literal(t.left) is not None:
        yield from terms(t.right, scale * literal(t.left))
    elif isinstance(t, ast.BinOp) and isinstance(t.op, ast.Mult) and literal(t.right) is not None:
        yield from terms(t.left, scale * literal(t.right))
    else:
        yield t, scale

def is_input(t):
    return isinstance(t, ast.Name) and t.id in INPUTS

def scaled(c, k):
    return Counter({a: b*k for a, b in c.items()})

@lru_cache(None)
def evaluate_add_serialized(s):
    t = ast.parse(s, mode='eval').body
    total = Counter()
    width = 0
    for term, scale in terms(t):
        c = term_cost(term, abs(scale))
        total += c.counts
        width = max(width, c.scratch)
    return Cost(width, total)

def evaluate_add(t):
    return evaluate_add_serialized(ast.unparse(t))

def term_cost(t, scale):
    t = resolve(t)
    if is_input(t):
        return Cost(0, Counter(A=scale))
    if isinstance(t, ast.Constant):
        return Cost(0, Counter(C=scale))
    assert isinstance(t, ast.BinOp), ast.dump(t)
    if isinstance(t.op, ast.Pow):
        assert literal(t.right) == 2
        a = resolve(t.left)
        if is_input(a):
            return Cost(0, Counter(S=scale))
        c = evaluate_add(a)
        return Cost(1+c.scratch, scaled(c.counts, 2) + Counter(S=scale))
    assert isinstance(t.op, ast.Mult), ast.dump(t)
    left, right = resolve(t.left), resolve(t.right)
    if ast.dump(left) == ast.dump(right):
        return term_cost(ast.BinOp(left, ast.Pow(), ast.Constant(2)), scale)
    ka, kb = int(not is_input(left)), int(not is_input(right))
    ca = evaluate_add(left) if ka else Cost(0, Counter())
    cb = evaluate_add(right) if kb else Cost(0, Counter())
    w_ab = max(ka+ca.scratch, ka+kb+cb.scratch, ka+kb)
    w_ba = max(kb+cb.scratch, ka+kb+ca.scratch, ka+kb)
    return Cost(min(w_ab,w_ba), scaled(ca.counts+cb.counts,2)+Counter(M=scale))

class ExplicitSchedule:
    """Emit the literal clean M/S/A field-operation trace and allocate words."""
    def __init__(self):
        self.live=set()
        self.peak=0
        self.operations=[]
    def allocate(self):
        i=0
        while i in self.live: i+=1
        self.live.add(i)
        self.peak=max(self.peak,len(self.live))
        return f'work{i}'
    def release(self,reg):
        self.live.remove(int(reg[4:]))
    def reverse(self,ops):
        self.operations.extend((kind,-sign,target,a,b) for kind,sign,target,a,b in reversed(ops))
    def add(self,t,target,sign=1):
        for term,scale in terms(t): self.term(term,target,sign*scale)
    def term(self,t,target,scale):
        t=resolve(t)
        sign=1 if scale>=0 else -1
        repeat=abs(scale)
        if is_input(t):
            self.operations.extend(('A',sign,target,t.id,None) for _ in range(repeat))
            return
        if isinstance(t,ast.Constant):
            self.operations.extend(('C',sign,target,t.value,None) for _ in range(repeat))
            return
        assert isinstance(t,ast.BinOp)
        if isinstance(t.op,ast.Pow):
            assert literal(t.right)==2
            a=resolve(t.left)
            if is_input(a):
                self.operations.extend(('S',sign,target,a.id,None) for _ in range(repeat))
            else:
                reg=self.allocate()
                start=len(self.operations)
                self.add(a,reg)
                part=self.operations[start:]
                self.operations.extend(('S',sign,target,reg,None) for _ in range(repeat))
                self.reverse(part)
                self.release(reg)
            return
        assert isinstance(t.op,ast.Mult)
        a,b=resolve(t.left),resolve(t.right)
        if ast.dump(a)==ast.dump(b):
            self.term(ast.BinOp(a,ast.Pow(),ast.Constant(2)),target,scale)
            return
        ka,kb=int(not is_input(a)),int(not is_input(b))
        ca=evaluate_add(a) if ka else Cost(0,Counter())
        cb=evaluate_add(b) if kb else Cost(0,Counter())
        wab=max(ka+ca.scratch,ka+kb+cb.scratch,ka+kb)
        wba=max(kb+cb.scratch,ka+kb+ca.scratch,ka+kb)
        operands=[a,b] if wab<=wba else [b,a]
        regs=[]
        recorded=[]
        for operand in operands:
            if is_input(operand):
                regs.append(operand.id)
                recorded.append(None)
            else:
                reg=self.allocate()
                start=len(self.operations)
                self.add(operand,reg)
                regs.append(reg)
                recorded.append(self.operations[start:])
        self.operations.extend(('M',sign,target,regs[0],regs[1]) for _ in range(repeat))
        for reg,part in reversed(list(zip(regs,recorded))):
            if part is not None:
                self.reverse(part)
                self.release(reg)

def execute(operations,registers,modulus):
    for kind,sign,target,a,b in operations:
        if kind=='M': val=registers[a]*registers[b]
        elif kind=='S': val=registers[a]**2
        elif kind=='A': val=registers[a]
        elif kind=='C': val=a
        else: raise ValueError(kind)
        registers[target]=(registers[target]+sign*val)%modulus

def main():
    ans = {name: evaluate_add(ast.parse(expr, mode='eval').body)
           for name,expr in outputs.items()}
    total = sum((a.counts for a in ans.values()), Counter())
    report = dict(outputs={name: dict(scratch=a.scratch, counts=dict(a.counts))
                            for name,a in ans.items()},
                  clean_node_scratch=max(a.scratch for a in ans.values()),
                  clean_node_counts=dict(total),
                  primitive_calls=sum(total.values()),
                  semantics='arbitrary modular accumulator targets; inputs preserved; scratch clean')
    print(json.dumps(report, indent=2))

if __name__ == '__main__':
    main()
