"""Validate tree scheduling and its conditional quantum instrument.

The state is represented exactly on (read-only input, arbitrary XOR target,
reference). Each live work register is a deterministic function of input,
so storing that function is a lossless compression of the reachable state.
Local arithmetic is an oracle contract, NOT an elementary-gate simulation.
"""
from functools import lru_cache
import itertools
import json
from pathlib import Path
import random

import numpy as np
import audit_compact_weighted as compact
import audit_phase_terminal as terminal
import audit_generic_schedule as dag
from residue_tree_local_macros import phase_correct, consume_root, macro_resources, leaf_phase_from_table
from residue_tree_schedule import build_schedule, certify_tree_schedule, verify_schedule


class Model:
    def __init__(self, height, p=2, toy=False):
        self.height, self.leaves = height, 1 << height
        self.p, self.toy = p, toy
        self.b = 1 if toy else p.bit_length()
        self.c = 1 if toy else 5
        self.nx, self.target_size, self.reference_size = 4, 1 << self.b, 2

    @lru_cache(maxsize=None)
    def leaf(self, node, x):
        if self.toy:
            return ((x >> (node % 2)) & 1,)
        # Fixed integer tables over base q=5; reduce constants modulo the
        # auxiliary p. These test polynomial semantics, not valid divisors.
        return tuple(((node * (i + 1) + x * (i + 2) + x * x) % 5) % self.p
                     for i in range(4)) + (1,)

    @lru_cache(maxsize=None)
    def internal(self, node, left, right):
        if self.toy:
            return ((left[0] ^ right[0]) if node % 2 else (left[0] & right[0]),)
        return compact.evaluate(left + right, self.p)[0]

    @lru_cache(maxsize=None)
    def root(self, left, right):
        if self.toy:
            return left[0] ^ right[0]
        env = dict(zip(dag.INPUTS, left + right))
        for i, expr in enumerate(terminal.SMALL_PROGRAM):
            env[f's{i}'] = eval(expr, {'__builtins__': {}}, env) % self.p
        gamma = 2 % self.p
        return (env['s23'] + gamma * env['s24']) % self.p

    def pack(self, value):
        assert len(value) == self.c and all(0 <= v < (1 << self.b) for v in value)
        return sum(v << (i * self.b) for i, v in enumerate(value))

    def expected_root(self, x):
        # Independent bottom-up evaluation, without ghosts, slots or scheduling.
        values = {v: self.leaf(v, x) for v in range(self.leaves, 2 * self.leaves)}
        for v in range(self.leaves - 1, 1, -1):
            values[v] = self.internal(v, values[2*v], values[2*v+1])
        return self.root(values[2], values[3])


def xor_target(state, values):
    result = np.empty_like(state)
    for x, value in enumerate(values):
        for y in range(state.shape[1]):
            result[x, y ^ value, :] = state[x, y, :]
    return result


def execute(model, events, initial, outcomes, omit_phase_at=None):
    state = initial.copy()
    live, masks = {}, {}
    outcomes = iter(outcomes)
    erased_bits = 0
    probability_error = 0.0

    def node_value(v):
        if v >= model.leaves:
            return tuple(model.leaf(v, x) for x in range(model.nx))
        return tuple(model.internal(v, live[2*v][x], live[2*v+1][x])
                     for x in range(model.nx))

    for event in events:
        v = event.node
        if event.kind == 'compute':
            assert v not in live
            live[v] = node_value(v)
        elif event.kind == 'ghost':
            m = next(outcomes)
            bits = model.c * model.b
            assert 0 <= m < (1 << bits)
            # H^tensor followed by outcome m and reset has amplitude
            # 2^(-bits/2) (-1)^<m,value>. Keep normalized conditional state
            # and its probability separately to avoid large-tree underflow.
            phase = np.array([1 - 2 * ((m & model.pack(value)).bit_count() % 2)
                              for value in live.pop(v)])
            branch = state * phase[:, None, None] * 2.0**(-bits / 2)
            probability_error = max(probability_error,
                                    abs(float(np.vdot(branch, branch).real) - 2.0**(-bits)))
            state *= phase[:, None, None]
            erased_bits += bits
            masks[v] = masks.get(v, 0) ^ m
        elif event.kind == 'correct':
            assert v in masks and v not in live
            m = masks.pop(v)
            values = node_value(v)  # Recompute from currently live children.
            if v != omit_phase_at:
                phase = np.array([1 - 2 * ((m & model.pack(value)).bit_count() % 2)
                                  for value in values])
                state *= phase[:, None, None]
        elif event.kind == 'consume':
            values = [model.root(live[2][x], live[3][x]) for x in range(model.nx)]
            state = xor_target(state, values)
        else:
            raise AssertionError(event)
    assert next(outcomes, None) is None and not live and not masks
    return state, erased_bits, probability_error


def initial_state(model, rng):
    shape = model.nx, model.target_size, model.reference_size
    state = rng.normal(size=shape) + 1j * rng.normal(size=shape)
    return state / np.linalg.norm(state)


def main():
    rng = np.random.default_rng(20260913)
    random_masks = random.Random(20260913)
    certificates = [certify_tree_schedule(h) for h in range(1, 9)]
    cases, max_error, max_probability_error = [], 0.0, 0.0
    leaf_cases = 0
    for w in (1, 2, 3, 4):
        b = 4
        table = [tuple(random_masks.randrange(1 << b) for _ in range(5))
                 for _ in range(1 << w)]
        for _ in range(8):
            address = random_masks.randrange(1 << w)
            mask = random_masks.getrandbits(5*b)
            packed = sum(x << (i*b) for i, x in enumerate(table[address]))
            assert leaf_phase_from_table(table, address, mask, b) == 1 - 2*((mask & packed).bit_count() % 2)
            leaf_cases += 1
    local_cases = 0
    for p in (3, 7, 127, 2**127 - 1):
        for _ in range(8):
            coords = tuple(random_masks.randrange(p) for _ in range(10))
            b = p.bit_length()
            mask = random_masks.getrandbits(5*b)
            expected_vector = compact.evaluate(coords, p)[0]
            packed = sum(v << (i*b) for i, v in enumerate(expected_vector))
            assert phase_correct(coords, mask, p) == 1 - 2*((mask & packed).bit_count() % 2)
            # This includes targets outside the canonical residue range.
            target = random_masks.getrandbits(b)
            env = dict(zip(dag.INPUTS, coords))
            for i, expr in enumerate(terminal.SMALL_PROGRAM):
                env[f's{i}'] = eval(expr, {'__builtins__': {}}, env) % p
            gamma = random_masks.randrange(p)
            scalar = (env['s23'] + gamma*env['s24']) % p
            result = consume_root(coords, target, p, gamma)
            assert result == target ^ scalar
            assert consume_root(coords, result, p, gamma) == target
            local_cases += 1
    # Exhaust every measurement transcript on 2- and 4-leaf bit-valued trees.
    # Larger cases sample full transcripts; the symbolic certificate is universal.
    models = [(Model(1, toy=True), 'exhaustive', None),
              (Model(2, toy=True), 'exhaustive', None),
              (Model(3, toy=True), 'sampled', 32)]
    models += [(Model(h, p=p), 'sampled', 12) for h in (1, 2, 3, 4)
               for p in (3, 7, 11)]
    models += [(Model(h, p=p), 'sampled', 12) for h in (1, 2, 3, 4, 5)
               for p in (101, 127)]
    for model, mode, samples in models:
        events = build_schedule(model.height)
        cert = certify_tree_schedule(model.height)
        measured = cert['measurement_vector_count']
        bits = model.c * model.b
        if mode == 'exhaustive':
            transcripts = itertools.product(range(1 << bits), repeat=measured)
        else:
            transcripts = ([random_masks.getrandbits(bits) for _ in range(measured)]
                           for _ in range(samples))
        initial = initial_state(model, rng)
        expected = xor_target(initial, [model.expected_root(x) for x in range(model.nx)])
        checked = 0
        for outcomes in transcripts:
            result, erased_bits, prob_error = execute(model, events, initial, outcomes)
            error = float(np.max(np.abs(result - expected)))
            assert error < 1e-12 and prob_error < 1e-12
            assert erased_bits == measured * bits
            max_error = max(max_error, error)
            max_probability_error = max(max_probability_error, prob_error)
            # XOR is self-inverse; a second fresh, forward schedule must clean
            # the target even though measurement itself cannot be reversed.
            reverse_outcomes = [random_masks.getrandbits(bits) for _ in range(measured)]
            restored, _, _ = execute(model, events, result, reverse_outcomes)
            assert np.max(np.abs(restored - initial)) < 1e-12
            checked += 1
        if mode == 'exhaustive':
            assert checked == 1 << (measured * bits)
            assert checked * 2.0**(-measured * bits) == 1.0
        cases.append(dict(height=model.height, toy=model.toy, modulus=model.p,
                          coordinates=model.c, mode=mode, transcripts=checked,
                          erased_bits_per_transcript=measured * bits))

    # Adversarial sensitivity: losing one nonzero phase correction must fail.
    model = Model(1, toy=True)
    initial = initial_state(model, rng)
    expected = xor_target(initial, [model.expected_root(x) for x in range(model.nx)])
    bad, _, _ = execute(model, build_schedule(1), initial, [1, 0], omit_phase_at=2)
    fidelity = float(abs(np.vdot(expected, bad))**2)
    assert fidelity < .99
    # A missing correction must also be rejected by the structural verifier.
    rejected = False
    try:
        verify_schedule(2, tuple(e for e in build_schedule(2)
                                 if not (e.kind == 'correct' and e.node == 2)))
    except AssertionError:
        rejected = True
    assert rejected
    report = dict(scope='word-level schedule and conditional quantum instrument; not gate synthesis',
                  local_macro_cases=local_cases, leaf_selector_phase_cases=leaf_cases, local_macro_resources=macro_resources(),
                  structural_certificates=certificates, instrument_cases=cases,
                  forward_transcripts=sum(c['transcripts'] for c in cases),
                  fresh_forward_cleanup_transcripts=sum(c['transcripts'] for c in cases),
                  max_state_amplitude_error=max_error,
                  max_conditional_outcome_probability_error=max_probability_error,
                  missing_phase_correction_fidelity=fidelity,
                  malformed_schedule_rejected=rejected,
                  all_checks_passed=True)
    path = Path(__file__).with_name('residue_tree_schedule_report.json')
    path.write_text(json.dumps(report, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
