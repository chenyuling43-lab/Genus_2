"""Explicit measurement/phase-correction schedule for a perfect residue tree.

Word-level macros, not an elementary-gate netlist. Root is a scalar XOR
oracle; proper nodes are vectors. Classical ghost masks may coexist with
recomputed live nodes. See TREE_SCHEDULE_NOTES.md for the circuit contracts.
"""
from collections import Counter
from dataclasses import asdict, dataclass
from functools import lru_cache
import argparse
import json


@dataclass(frozen=True)
class Event:
    kind: str
    node: int
    slot: int | None = None


def build_schedule(height):
    if not isinstance(height, int) or height < 1:
        raise ValueError('height must be an integer >= 1')
    leaves = 1 << height
    events, live = [], {}

    def emit(kind, node):
        slot = None
        if kind == 'compute':
            assert node not in live
            slot = next(i for i in range(height + 2) if i not in live.values())
            live[node] = slot
        elif kind == 'ghost':
            slot = live.pop(node)
        events.append(Event(kind, node, slot))

    def evaluate(node):
        if node < leaves:
            evaluate(2 * node)
            evaluate(2 * node + 1)
        emit('compute', node)
        if node < leaves:
            emit('ghost', 2 * node)
            emit('ghost', 2 * node + 1)

    evaluate(2)
    evaluate(3)
    emit('consume', 1)
    emit('ghost', 2)
    emit('ghost', 3)
    # Heap order is topological: every parent is corrected before its children.
    for node in range(2, 2 * leaves):
        if node < leaves:
            evaluate(2 * node)
            evaluate(2 * node + 1)
        emit('correct', node)
        if node < leaves:
            emit('ghost', 2 * node)
            emit('ghost', 2 * node + 1)
    assert not live
    return tuple(events)


def verify_schedule(height, events):
    """Independent precondition, slot-liveness and symbolic phase-token check.

    A distinct symbol represents each measurement mask. Keeping symbols even
    when the numerical mask is zero makes this certificate outcome-independent.
    """
    leaves = 1 << height
    live, ghosts = {}, {}
    corrected, created, cancelled = set(), set(), set()
    peak = peak_masks = roots = 0
    counts = Counter()
    for index, event in enumerate(events):
        kind, node, slot = event.kind, event.node, event.slot
        assert 1 <= node < 2 * leaves
        counts[kind] += 1
        if kind in ('compute', 'correct', 'consume') and node < leaves:
            assert 2 * node in live and 2 * node + 1 in live, (index, event)
        if kind == 'compute':
            assert node != 1 and node not in live
            assert isinstance(slot, int) and 0 <= slot < height + 2
            assert slot not in live.values()
            live[node] = slot
        elif kind == 'ghost':
            assert node not in corrected, ('new ghost after correction', event)
            assert node in live and live.pop(node) == slot
            ghosts.setdefault(node, set()).add(index)
            created.add(index)
        elif kind == 'correct':
            assert slot is None and node != 1 and node not in live
            assert node not in corrected and node in ghosts
            tokens = ghosts.pop(node)
            assert not (tokens & cancelled)
            cancelled.update(tokens)
            corrected.add(node)
        elif kind == 'consume':
            assert slot is None and node == 1 and roots == 0
            roots += 1
        else:
            raise AssertionError(('unknown event', event))
        peak = max(peak, len(live))
        peak_masks = max(peak_masks, len(ghosts))
    assert roots == 1 and not live and not ghosts
    assert corrected == set(range(2, 2 * leaves))
    assert created == cancelled
    expected = (4 * height - 2) * leaves + 3
    assert len(events) == expected
    assert peak <= height + 2 and len(events) <= 8 * (height + 1) * leaves
    assert counts['compute'] == counts['ghost']
    return dict(height=height, leaves=leaves, macro_moves=len(events),
                counts=dict(sorted(counts.items())), peak_vector_pebbles=peak,
                vector_pebble_bound=height + 2,
                macro_move_bound=8 * (height + 1) * leaves,
                peak_classical_mask_records=peak_masks,
                measurement_vector_count=counts['ghost'],
                corrected_mask_tokens=len(cancelled), all_workspace_clean=True)


@lru_cache(maxsize=None)
def _certificate(height):
    return verify_schedule(height, build_schedule(height))


def certify_tree_schedule(height):
    # Return a fresh dictionary so callers cannot corrupt the cached certificate.
    return json.loads(json.dumps(_certificate(height)))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--height', type=int, default=5)
    parser.add_argument('--trace', help='optional output JSON with all macro events')
    args = parser.parse_args()
    certificate = certify_tree_schedule(args.height)
    if args.trace:
        with open(args.trace, 'w', encoding='utf-8') as stream:
            json.dump(dict(certificate=certificate,
                           events=[asdict(e) for e in build_schedule(args.height)]),
                      stream, indent=2)
            stream.write('\n')
    print(json.dumps(certificate, indent=2))
