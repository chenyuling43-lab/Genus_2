"""Exact, standard-library check of the promoted F5 rectangular example."""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
q=5
f=[3,0,2,1,0,1]
def trim(a):
 a=[v%q for v in a]
 while a and a[-1]==0:a.pop()
 return a
def mul(a,b):
 c=[0]*(len(a)+len(b)-1)
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return trim(c)
def sub(a,b):
 return trim([(a[i] if i<len(a) else 0)-(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def rem(a,b):
 a=trim(a);b=trim(b)
 while len(a)>=len(b):
  k=len(a)-len(b);z=a[-1]*pow(b[-1],-1,q)%q
  a=sub(a,[0]*k+[z*x for x in b])
 return a
def gcd(a,b):
 while b:a,b=b,rem(a,b)
 return trim(a)
assert len(gcd(f,[i*f[i] for i in range(1,len(f))]))==1
# Enumerate all reduced Mumford pairs, including the identity.
classes=[([1],[])]
for d in (1,2):
 for uc in product(range(q),repeat=d):
  u=list(uc)+[1]
  for vc in product(range(q),repeat=d):
   v=trim(vc)
   if not rem(sub(f,mul(v,v)),u):classes.append((u,v))
e=sum(len(u)<3 for u,v in classes)
m=[sum(len(u)==3 and u[0]==a for u,v in classes) for a in range(q)]
assert ([3,1],[1]) in classes and ([3,1],[4]) in classes
N1=1+sum(1 for x,y in product(range(q),repeat=2) if (y*y-sum(c*x**i for i,c in enumerate(f)))%q==0)
# F25 = F5[t]/(t^2-2); 2 is a nonsquare in F5.
elems=list(product(range(q),repeat=2))
def ea(x,y):return ((x[0]+y[0])%q,(x[1]+y[1])%q)
def em(x,y):return ((x[0]*y[0]+2*x[1]*y[1])%q,(x[0]*y[1]+x[1]*y[0])%q)
def ef(x):
 out=(0,0);power=(1,0)
 for c in f:out=ea(out,em((c,0),power));power=em(power,x)
 return out
N2=1+sum(em(y,y)==ef(x) for x,y in product(elems,repeat=2))
J=(N1*N1+N2)//2-q
assert J==len(classes)==23 and all(J%d for d in range(2,5))
# Lexicographic input order (0,0),(0,1),(1,0),(1,1).
inputs=list(product((0,1),repeat=2));values=('O','-P','P','O')
full={}
for u,v in inputs:
 sums={z:sum((-1)**(u*a+v*b) for (a,b),value in zip(inputs,values) if value==z) for z in set(values)}
 full[str((u,v))]=Fraction(sum(a*a for a in sums.values()),16)
variation=sum(abs((1 if y==(0,0) else 0)-full[str(y)]) for y in inputs)/2
squares={x*x%q for x in range(1,q)}
def sign(x):return 1 if x%q==0 or x%q in squares else -1
means=[Fraction(e+sum(m[a]*sign(a+g) for a in range(q)),J) for g in range(q)]
success=sum(1-x*x for x in means)/q
assert (N1,N2,e,m)==(5,31,5,[0,4,4,2,8])
assert list(full.values())==[Fraction(3,8),Fraction(1,8),Fraction(1,8),Fraction(3,8)]
assert variation==Fraction(5,8) and success==Fraction(2192,2645)
result={'curve_coefficients_ascending':f,'squarefree':True,'C_F5':N1,'C_F25':N2,'J_F5':J,'lower_degree_count':e,'fiber_counts_u0':m,'full_output_rectangular_distribution':{k:str(v) for k,v in full.items()},'rectangular_total_variation':str(variation),'exact_domain_shift_means':[str(x) for x in means],'exact_domain_average_success':str(success),'scope':'Exhaustive finite-field and Mumford enumeration, exact rational distributions; not a quantum gate simulation.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
