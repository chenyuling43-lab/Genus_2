#!/usr/bin/env python3
"""Targeted independent checks of proofs in Sections 2 and 4.3.
Standard library only; finite inverse checks are exhaustive.
"""
import json
from pathlib import Path
import math
from itertools import permutations
from collections import defaultdict

# Independent sparse integer polynomial algebra with ten formal variables.
class Poly(dict):
 def __add__(self, other):
  if isinstance(other,int): other=Poly({(0,)*10:other}) if other else Poly()
  o=Poly(self)
  for e,c in other.items():
   o[e]=o.get(e,0)+c
   if not o[e]: del o[e]
  return o
 __radd__=__add__
 def __neg__(self): return Poly({e:-c for e,c in self.items()})
 def __sub__(self,other): return self+(-other)
 def __rsub__(self,other): return -self+other
 def __mul__(self,other):
  if isinstance(other,int): return Poly({e:c*other for e,c in self.items() if c*other})
  o=defaultdict(int)
  for e,c in self.items():
   for f,d in other.items(): o[tuple(x+y for x,y in zip(e,f))]+=c*d
  return Poly({e:c for e,c in o.items() if c})
 __rmul__=__mul__
 def __pow__(self,n):
  o=Poly({(0,)*10:1}); p=self
  while n:
   if n%2: o=o*p
   n//=2
   if n: p=p*p
  return o


inverse_cases = 0
maximum_steps = 0
for q in [q for q in range(3,2000,2) if all(q%d for d in range(3,math.isqrt(q)+1,2))]:
    n = q.bit_length()
    for x in range(q):
        a,b,c,d = x,q,1,0
        history = []
        initial = (a,b,c,d)
        def H(z):
            z %= q
            return (z+(z%2)*q)//2
        for step in range(2*n+1):
            old=(a,b,c,d)
            assert a%q == c*x%q and b%q == d*x%q
            assert b>0 and b%2==1 and math.gcd(a,b)==math.gcd(x,q)
            if a==0:
                row=0
            elif a%2==0:
                row=1; a,c=a//2,H(c)
            elif a>=b:
                row=2; a,c=(a-b)//2,H(c-d)
            else:
                row=3; a,b,c,d=(b-a)//2,a,H(d-c),c
            history.append((row,old))
            if row and a: assert 2*a*b <= old[0]*old[1]
        assert a==0 and d == (pow(x,-1,q) if x else 0)
        maximum_steps=max(maximum_steps,sum(row!=0 for row,_ in history))
        for row,old in reversed(history):
            if row==1: a,c=2*a,2*c%q
            elif row==2: a,c=2*a+b,(2*c+d)%q
            elif row==3: a,b,c,d=b,2*a+b,d,(2*c+d)%q
            assert (a,b,c,d)==old
        assert (a,b,c,d)==initial
        inverse_cases+=1

formal=[Poly({tuple(int(i==j) for j in range(10)):1}) for i in range(9)]
x,a,b,c,d,s,t,u,v=formal
one=Poly({(0,)*10:1})
zero=Poly()
def rem_monic_x(poly,modulus,degree):
    while poly and max(e[0] for e in poly)>=degree:
        k=max(e[0] for e in poly)
        lead=Poly({(e[0]-degree,)+e[1:]:co for e,co in poly.items() if e[0]==k})
        poly=poly-lead*modulus
    return poly
matrix=[[one,a,c,zero],[zero,one,a,c],[one,b,d,zero],[zero,one,b,d]]
resultant=Poly()
for perm in permutations(range(4)):
    inv=sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4))
    term=one
    for i,j in enumerate(perm): term=term*matrix[i][j]
    resultant=resultant+((-1)**inv)*term
R=(d-c)**2-(a*d-c*b)*(b-a)
E=(t-s)*(d-c)-(v-u)*(b-a)
L=(d-c)*(v-u)-(a*d-c*b)*(t-s)
B1=s*R-a*L-(a*b+c)*E
B0=u*R-c*L-b*c*E
A=2*L*E+(a+b)*E**2-R**2
N=L**2+2*a*L*E+(a*b-d+c)*E**2-2*s*R*E+(a+b)*R**2
T=L*E-R**2
u1=x**2+a*x+c; u2=x**2+b*x+d
P=-E*x**3-(L+(a+b)*E)*x**2+B1*x+B0
identities={
 'resultant': resultant==R,
 'first_interpolation_remainder': not rem_monic_x(P-R*(s*x+u),u1,2),
 'second_interpolation_remainder': not rem_monic_x(P-R*(t*x+v),u2,2),
}
res=P**2-R**2*x**5-u1*u2*(E**2*x**2+A*x+N)
identities['leading_three_reduction_coefficients']=max(e[0] for e in res)<=3
identities['v1_reduction']=(A**2-N*E**2-A*L*E-(a+b)*A*E**2-B1*E**3)==(A*T-E**2*(B1*E+N))
identities['v0_reduction']=(A*N-L*N*E-(a+b)*N*E**2-B0*E**3)==(N*T-B0*E**3)
assert all(identities.values()),identities
report={
 'clean_inverse_exhaustive_cases': inverse_cases,
 'clean_inverse_prime_range':'3 <= q < 2000',
 'clean_inverse_maximum_active_steps': maximum_steps,
 'inverse_invariants_terminal_value_and_history_reversal':True,
 'symbolic_identities_over_Z':identities,
 'scope':'Checks complement the mathematical proofs; no full quantum gate-network synthesis is asserted.'
}
Path(__file__).with_name('arithmetic_proof_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
