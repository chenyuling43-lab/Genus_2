#!/usr/bin/env python3
"""Structural check of the explicit ghost-corrected binary-tree schedule.

This verifies legal data dependencies, vector allocation, descending ghost
elimination, and finite move counts. It does not simulate quantum gates.
Ghost phases are symbolic nonzero records: an existing record is cancelled
when its function is recomputed, and an erasure creates a new record.
"""
import json
from pathlib import Path


def check(h):
    pebbles, ghosts = set(), set()
    moves = peak = 0
    absorptions = 0

    def children(node):
        level, index = node
        assert level > 0
        return (level - 1, 2 * index), (level - 1, 2 * index + 1)

    def put(node):
        nonlocal moves, peak, absorptions
        assert node not in pebbles
        if node[0]:
            assert set(children(node)) <= pebbles
        pebbles.add(node)
        peak = max(peak, len(pebbles))
        if node in ghosts:
            ghosts.remove(node)
            absorptions += 1
        moves += 1
        assert not pebbles.intersection(ghosts)

    def ghost(node):
        nonlocal moves
        assert node in pebbles and node not in ghosts
        pebbles.remove(node)
        ghosts.add(node)
        moves += 1

    def forward(node):
        if node[0]:
            left, right = children(node)
            forward(left)
            forward(right)
            put(node)
            ghost(left)
            ghost(right)
        else:
            put(node)

    left, right = children((h, 0))
    forward(left)
    forward(right)
    assert pebbles == {left, right}
    moves += 1  # Compute scalar, XOR-copy, and uncompute.
    ghost(left)
    ghost(right)
    initial_moves = moves
    assert not pebbles
    assert initial_moves == 4 * (1 << h) - 3

    for level in reversed(range(h)):
        for index in range(1 << (h - level)):
            node = (level, index)
            assert node in ghosts  # Worst-case nonzero transcript.
            if level:
                left, right = children(node)
                forward(left)
                forward(right)
                assert pebbles == {left, right}
            moves += 1  # Complete local compute/parity/uncompute.
            ghosts.remove(node)
            if level:
                ghost(left)
                ghost(right)
            assert not pebbles
        assert all(v[0] < level for v in ghosts)

    leaves = 1 << h
    assert not ghosts and not pebbles
    assert moves == (4 * h - 2) * leaves + 3
    assert moves <= 8 * (h + 1) * leaves
    assert peak <= h + 2
    return dict(height=h, leaves=leaves, vector_peak=peak,
                vector_bound=h+2, moves=moves,
                move_bound=8*(h+1)*leaves,
                existing_records_absorbed=absorptions,
                ghosts_remaining=0)


if __name__ == '__main__':
    results = [check(h) for h in range(1, 11)]
    out = Path(__file__).with_name('spooky_schedule_results.json')
    out.write_text(json.dumps({
        'scope': 'Structural dependency and workspace audit; no quantum gate synthesis',
        'cases': results}, indent=2) + '\n')
    print(json.dumps(results, indent=2))
