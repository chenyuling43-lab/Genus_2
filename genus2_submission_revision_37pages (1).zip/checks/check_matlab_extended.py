#!/usr/bin/env python3
"""Independent fixtures for native MATLAB regression; does not execute MATLAB.

Regenerate deliberately with --write-fixtures. Default mode recomputes the
fixtures, compares the committed JSON, and checks generic formulas against
Cantor on every degree-two pair in F3,F5,F7 plus deterministic larger samples.
"""
import argparse
import ast
import json
import random
from itertools import product
from pathlib import Path

HERE = Path(__file__).resolve().parent


def definitions(path, stop_name):
    tree = ast.parse(path.read_text())
    cut = next(i for i, node in enumerate(tree.body)
               if isinstance(node, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == stop_name for t in node.targets))
    ns = {'__file__': str(path)}
    exec(compile(ast.Module(body=tree.body[:cut], type_ignores=[]), str(path), 'exec'), ns)
    return ns


def record(D):
    return {'u': D[0], 'v': D[1]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write-fixtures', action='store_true')
    args = parser.parse_args()
    ns = definitions(HERE/'audit_finite.py', 'reports')
    formula = definitions(HERE/'check_matlab_algebra.py', 'p')
    rng = random.Random(20260916)
    fixtures, rows = [], []
    for p in (3, 5, 7, 11, 13, 101):
        ns['p'] = p
        f = [3, 5, 7, 11, 0, 1] if p == 101 else [1, 1, 0, 0, 0, 1]
        while len(ns['xgcd'](f, [i*f[i] for i in range(1, 6)])[0]) != 1:
            f[0] += 1
        O = ([1], [])
        divisors = [O]
        if p < 101:
            for degree in (1, 2):
                for uc in product(range(p), repeat=degree):
                    u = list(uc)+[1]
                    for vc in product(range(p), repeat=degree):
                        v = ns['tr'](list(vc))
                        if not ns['div'](ns['sub'](f, ns['mul'](v, v)), u)[1]:
                            divisors.append((u, v))
        else:
            divisors += [([28, 90, 1], [58, 95]), ([72, 84, 1], [71, 97])]
            base = divisors[1]
            acc = O
            for _ in range(70):
                acc = ns['cantor'](acc, base, f)
                if acc not in divisors:
                    divisors.append(acc)
        degree_two = [D for D in divisors if len(D[0]) == 3]
        base = degree_two[0]
        chosen = [(O, O, 'identity'), (O, base, 'left_identity'),
                  (base, O, 'right_identity'), (base, base, 'doubling'),
                  (base, (base[0], ns['neg'](base[1])), 'inverse')]
        low = next((D for D in divisors if len(D[0]) == 2), None)
        if low:
            chosen += [(low, base, 'degree_one_input'), (low, low, 'degree_one_doubling')]
        chosen += [(rng.choice(divisors), rng.choice(divisors), 'sample') for _ in range(3)]
        # Select B3=0 with H!=0 and an actual degree-one output, and a pair
        # for which a4 succeeds but a0 must reject a zero constant coefficient.
        special = {}
        pairs = product(degree_two, repeat=2) if p <= 7 else (
            (rng.choice(degree_two), rng.choice(degree_two)) for _ in range(600))
        counts = {'a4': 0, 'a0': 0, 'a4_rejected': 0, 'a0_rejected': 0}
        for D, L in pairs:
            expected = ns['cantor'](D, L, f)
            DP, LP = ns['coords'](D, 1), ns['coords'](L, 1)
            answers = {}
            for method in ('a4', 'a0'):
                out = formula['matlab_add'](DP, LP, p, f, method)
                answers[method] = out
                if out is None:
                    counts[method+'_rejected'] += 1
                    continue
                u1, u0, v1, v0 = formula['recover'](out, p)
                assert (ns['tr']([u0, u1, 1]), ns['tr']([v0, v1])) == expected
                counts[method] += 1
            if answers['a4'] is not None and answers['a0'] is None:
                special.setdefault('a0_zero', (D, L, 'a0_zero'))
            g = ns['xgcd'](D[0], L[0])[0]
            if len(g) == 1 and answers['a4'] is None and len(expected[0]) == 2:
                special.setdefault('b3_zero', (D, L, 'b3_zero'))
            if D != L and len(g) > 1 and expected != O:
                special.setdefault('shared_support', (D, L, 'shared_support'))
        chosen += list(special.values())
        for D, L, label in chosen:
            expected = ns['cantor'](D, L, f)
            assert expected == ns['cantor'](L, D, f)
            assert ns['cantor'](expected, (L[0], ns['neg'](L[1])), f) == D
            fixtures.append({'p': p, 'curve': f[:4], 'label': label,
                             'left': record(D), 'right': record(L), 'expected': record(expected)})
        rows.append({'p': p, 'available_divisors': len(divisors), **counts})
    labels = {row['label'] for row in fixtures}
    assert {'doubling', 'inverse', 'b3_zero', 'shared_support', 'a0_zero',
            'degree_one_input', 'identity'} <= labels
    payload = {'scope': 'Expected values from the archived independent Python Cantor implementation; not MATLAB execution.',
               'seed': 20260916, 'cases': fixtures}
    target = HERE.parent/'matlab'/'regression_fixtures.json'
    if args.write_fixtures:
        target.write_text(json.dumps(payload, indent=2)+'\n')
    else:
        assert json.loads(target.read_text()) == payload, 'MATLAB fixtures are stale'
    result = {'status': 'passed', 'native_matlab_executed': False,
              'native_fixture_cases': len(fixtures), 'fixture_labels': sorted(labels),
              'generic_formula_comparisons': rows}
    (HERE/'matlab_extended_results.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
