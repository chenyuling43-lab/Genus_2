#!/usr/bin/env python3
"""Verify a deterministic Pocklington certificate for the displayed order r.

Verification uses exact integer arithmetic and the Python standard library.
No probable-prime test or factorization algorithm is used by this verifier.
The certificate lists complete factorizations of n-1; in particular their
certified product exceeds sqrt(n), as required by Pocklington's theorem.
"""
from pathlib import Path
import json
import math

def verify(path=None):
    here=Path(__file__).resolve().parent
    data=json.loads((Path(path) if path else here/'subgroup_prime_certificate.json').read_text())
    expected=2**250-int('334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD',16)
    assert int(data['r'])==expected
    certs=data['certificates']
    verified=set()
    active=set()
    def check(n):
        if n in verified:return
        assert n>=2 and n not in active
        active.add(n)
        c=certs[str(n)]
        if 'trial_division_through' in c:
            assert c['trial_division_through']==math.isqrt(n)
            assert n<1000000
            assert all(n%d for d in range(2,math.isqrt(n)+1))
        else:
            factors=c['factors_n_minus_one']
            assert factors and all(isinstance(p,int) and 2<=p<n for p in factors)
            F=math.prod(factors)
            assert F==n-1 and F*F>n
            witnesses=c['pocklington_witnesses']
            assert set(witnesses)==set(map(str,factors))
            for p in set(factors):
                check(p)
                a=witnesses[str(p)]
                assert isinstance(a,int) and 1<a<n
                assert pow(a,n-1,n)==1
                assert math.gcd(pow(a,(n-1)//p,n)-1,n)==1
        active.remove(n)
        verified.add(n)
    check(expected)
    return {'subgroup_order':str(expected),'subgroup_bits':expected.bit_length(),
            'deterministic_primality_verified':True,
            'method':'Recursive Pocklington certificate with exact trial-division leaves',
            'certified_primes_including_leaves':len(verified),
            'probable_prime_tests_used_by_verifier':False}

if __name__=='__main__':
    result=verify()
    Path(__file__).with_name('subgroup_prime_verification_results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
