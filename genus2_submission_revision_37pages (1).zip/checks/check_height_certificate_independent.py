#!/usr/bin/env python3
"""Independent coordinatewise-height and rational prime-allocation certificate.

Standard library only. Imports the previously independently audited sparse integer
polynomials, then independently recomputes norm ceilings, support maxima, and
all finite allocations. No floating point or probable-prime tests are used.
"""
from pathlib import Path
from fractions import Fraction
import json

HERE = Path(__file__).resolve().parent
POLY_FILE = HERE / 'audit_arithmetic.py'
namespace = {}
exec(compile(POLY_FILE.read_text().split('weights=')[0], str(POLY_FILE), 'exec'), namespace)
polynomials = namespace['out']
terminal = [namespace['N'], namespace['D']]


def ceil_log2(value):
    assert isinstance(value, int) and value >= 1
    exponent = 0
    power = 1
    while power < value:
        power *= 2
        exponent += 1
    return exponent


def bound_for_polynomial(poly, vector):
    """Proves |P(x)| <= 2^result under |x_i| <= 2^vector_i."""
    assert poly and all(c != 0 for c in poly.values())
    assert len(vector) == 10 and all(v >= 0 for v in vector)
    norm = sum(abs(coefficient) for coefficient in poly.values())
    monomial_bounds = []
    for exponents in poly:
        assert len(exponents) == 10
        degree_bound = 0
        for position in range(10):
            degree_bound += exponents[position] * vector[position]
        monomial_bounds.append(degree_bound)
    return ceil_log2(norm) + max(monomial_bounds)


# Rational enclosure from ln(2)=2 sum_{k>=0} (1/3)^(2k+1)/(2k+1).
# The remainder is bounded by replacing every denominator by 2M+1.
M = 100
ln2_lower = sum((Fraction(2, (2*k+1)*3**(2*k+1)) for k in range(M)), Fraction(0))
ln2_upper = ln2_lower + Fraction(2, (2*M+1)*3**(2*M+1)) / (1-Fraction(1,9))
assert 0 < ln2_upper - ln2_lower < Fraction(1, 10**96)


def fraction_ceil(value):
    return -((-value.numerator) // value.denominator)


def allocation(n, h, H, b):
    x = 2**b
    # Dusart's theta(x) lower bound, converted to bits; 2 and q removed.
    # Each factor below is a rational lower bound for its positive factor.
    prime_bits_lower = Fraction(x, 1) / ln2_upper * (1-Fraction(1,5)/(b*b*ln2_lower**2)) - 1 - n
    valid = x >= 3594641 and prime_bits_lower > H + 2
    k_upper = fraction_ceil(Fraction(x,1)/(b*ln2_lower-Fraction(11,10)))
    ell = ceil_log2(k_upper)
    afp = 2*ell + 4
    width = 500+n+afp+(5*(h+2)+11)*b+4
    return dict(b=b, K=k_upper, a_fp=afp, reconstruction_peak=width,
                certified=valid, prime_bits_margin_floor=(prime_bits_lower-H-2).__floor__())

expected = {
    64: (2800596977,31,105333026,58,2270),
    32: (140029735,27,7619525,50,1923),
    16: (7001373,23,565180,44,1618),
}
records=[]
for L,(expected_H,expected_b,expected_K,expected_afp,expected_width) in expected.items():
    h=ceil_log2(L)
    assert 2**h == L
    v=[127,127,127,127,0]
    history=[v]
    for level in range(1,h):
        v=[bound_for_polynomial(p, v+v) for p in polynomials]
        history.append(v)
    bn,bd=[bound_for_polynomial(p,v+v) for p in terminal]
    H=1+max(bn,127+bd)
    assert H==expected_H
    candidates=[allocation(127,h,H,b) for b in range(22,35)]
    chosen=next(record for record in candidates if record['certified'])
    assert (chosen['b'],chosen['K'],chosen['a_fp'],chosen['reconstruction_peak']) == (expected_b,expected_K,expected_afp,expected_width)
    # Check all competing stages against the reconstruction peak.
    b=chosen['b']; afp=chosen['a_fp']; width=chosen['reconstruction_peak']
    competitors = {
        'large_modulus_update':500+2*127+afp+2*b+20,
        'completed_character':500+afp+6*127+12,
        'input_preparation_and_fourier':3*250+5,
    }
    assert all(value<=width for value in competitors.values())
    records.append(dict(leaves=L,height=h,coordinate_bit_history=history,N_bits=bn,D_bits=bd,H=H,
                        allocation=chosen,competing_stage_widths=competitors,
                        excluded_previous_b=allocation(127,h,H,chosen['b']-1)))

# All-zero coefficients with Z=1 give the declared dummy tuple. Every input
# integer is bounded pointwise, independently of curve equations or branches.
dummy=(0,0,0,0,1)*2
for p in polynomials + terminal:
    result=sum(c*__import__('functools').reduce(lambda a,xb:a*(xb[0]**xb[1]),zip(dummy,e),1) for e,c in p.items())
    assert result==0

report={
 'method':'Exact sparse integer coefficients; independent support/norm recurrence; rational ln(2) enclosure from 100 positive series terms',
 'primitive_workspace_assumption':'A_prim(b)<=b+4, independently certified by the separate gate-level primitive verification',
 'coordinate_norm_bits':[ceil_log2(sum(abs(c) for c in p.values())) for p in polynomials],
 'terminal_norm_bits':[ceil_log2(sum(abs(c) for c in p.values())) for p in terminal],
 'leaf_bound':'|U1|,|U0|,|V1|,|V0|<2^n, Z=1; recurrence uses weak bounds <=2^v',
 'root_strictness':'|N|<=2^BN and |gamma D|<2^(n+BD); hence |N+gamma D|<2^(1+max(BN,n+BD))',
 'dummy_check':True,
 'scope':'Every integer tuple in the coordinate box, including exceptional and dummy values; gamma is any canonical integer in [0,q). This is not an improvement to the tree asymptotic exponent.',
 'records':records,
}
(HERE/'height_certificate_independent_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
