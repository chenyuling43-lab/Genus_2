#!/usr/bin/env python3
"""Independent finite ledger for the improved genus-two sampler.

Reads the accompanying normalized-height certificate JSON. This script
audits exact integer resource formulas and high-precision prime estimates;
it does not compile the complete quantum sampler. See
primitive_improvement.py for the actual local arithmetic gate circuits.
"""
from decimal import Decimal, ROUND_CEILING, localcontext
from pathlib import Path
import json


def ceildiv(x, y):
    return (x+y-1)//y


def main():
    heights = json.loads(Path(__file__).with_name(
        'normalized_height_results.json').read_text())
    heights = {row['window']: row
               for row in heights['componentwise_height_parameters']}
    n, mr = 127, 250
    q = 2**127-1
    r = 2**250-int('334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD', 16)
    assert r.bit_length() == mr
    chen_add = 85*(6*n-4)+102*n*(6*n-4)+14*2*n*(8*n-3)
    assert chen_add == 836*n*n+18*n-340 == 13485790
    chen_width = 20*n+2*(n-1).bit_length()+10+2*mr-1
    assert chen_width == 3063
    character = 72*n*(2*n+1)
    fourier = 10*292*(2*mr-1)
    preparation = 4*42*(2*mr-1)
    overhead = character+fourier+preparation
    assert (character, fourier, preparation, overhead) == (
        2331720, 1457080, 83832, 3872632)
    expected = {
        8: (31, 64, 105333026, 58, 2270),
        16: (27, 32, 7619525, 50, 1923),
        24: (27, 32, 7619525, 50, 1923),
        32: (23, 16, 565180, 44, 1618),
    }
    rows = []
    with localcontext() as ctx:
        ctx.prec = 90
        ln2 = Decimal(2).ln()
        log2 = lambda x: str(Decimal(x).ln()/ln2)
        for w, (b, L_expected, K_expected, afp_expected, peak_expected) in expected.items():
            record = heights[w]
            raw_leaves = 2*ceildiv(mr, w)
            h = (raw_leaves-1).bit_length()
            L = 2**h
            assert L == L_expected == record['leaves']
            assert h == record['height']
            H = record['H']
            assert H == record['N_bits']+1
            x = Decimal(2**b)
            # Conservative Dusart bounds; their published thresholds apply.
            assert x >= 3594641 and x >= 60184
            product_lower_bits = x/ln2*(1-Decimal('0.2')/(b*ln2)**2)-1-n
            margin = product_lower_bits-H-2
            assert margin > 0
            K = int((x/(b*ln2-Decimal('1.1'))).to_integral_value(rounding=ROUND_CEILING))
            lk = (K-1).bit_length()
            afp, tau = 2*lk+4, lk+3
            assert (b, K, afp) == (record['best']['b'], record['best']['K'],
                                    record['best']['a_fp'])
            assert (K, afp) == (K_expected, afp_expected)
            CM, CS, CA, Cgamma = 24*b*b-17*b+4, 24*b*b-23*b+4, 10*b-5, 10*b*b-5*b
            D = 4*b-2
            local_node = 274*CM+262*CS
            terminal = 130*CM+138*CS+Cgamma
            ghost = 638*CM+776*CS
            local_gate_allowance = 707*CM
            assert terminal <= local_node <= local_gate_allowance
            assert ghost <= 2*local_gate_allowance
            Qw = 4*w*2**w
            Gstar = 2*max(Qw, local_gate_allowance)
            Eh = 8*(h+1)*L*Gstar
            # The remaining CRT terms deliberately retain their earlier
            # conservative bounds. In particular, n-bit accumulator work
            # is NOT replaced by b-bit auxiliary-field arithmetic costs.
            CRT_modulus_terms = (40*b*(b+1)
                +tau*(2*D+20*(afp+1))+20*b*(n+1))
            CRT_final_terms = 40*(afp+1)+20*(lk+1)*(n+1)
            GR = K*(2*Eh+CRT_modulus_terms)+CRT_final_terms
            twice = 2*GR
            total = twice+overhead
            stages = [
                2*mr+n+afp+(5*(h+2)+11)*b+4,
                2*mr+2*n+afp+2*b+20,
                2*mr+afp+6*n+12,
                3*mr+5,
            ]
            assert max(stages) == peak_expected
            assert w-1 <= 8*b
            delta = Decimal(L-1)*(14*q+3)/r
            ideal_failure = ((1/Decimal(q)
                +Decimal((2*q+1)**2+4*q*r)/r**2).sqrt()+2*delta.sqrt())**2
            rows.append(dict(
                window=w, auxiliary_word_bits=b, raw_leaves=raw_leaves,
                leaves=L, tree_height=h, root_integer_bits=H,
                prime_count_upper_bound=K, prime_product_bit_margin=str(margin),
                fixed_point_bits=afp, ell_K=lk, quotient_fraction_bits=tau,
                stage_names=['reconstruction', 'CRT_update', 'character', 'preparation_Fourier'],
                stages=stages, peak=max(stages),
                table_entry_upper_bound=L*2**w,
                lookup_clean_chain_bits=w-1, existing_local_scratch_bits=8*b,
                primitive_clean_scratch=b+4,
                reduction_percent=str(Decimal(100)*(chen_width-max(stages))/chen_width),
                primitive_toffoli=dict(multiply=CM, square=CS, add=CA,
                    fixed_constant_multiply=Cgamma, doubling=D),
                local_node_toffoli=local_node, terminal_toffoli=terminal,
                local_node_primitive_calls=dict(multiply=274, square=262),
                terminal_primitive_calls=dict(multiply=130, square=138,
                                              fixed_constant_multiply=1),
                ghost_correction_primitive_calls=dict(multiply=638, square=776),
                ghost_correction_toffoli=ghost,
                local_gate_allowance=local_gate_allowance,
                lookup_toffoli=Qw, G_star=Gstar, E_h=Eh,
                per_modulus_non_tree_CRT_toffoli=CRT_modulus_terms,
                final_CRT_toffoli=CRT_final_terms,
                one_reconstruction_toffoli=GR,
                twice_reconstruction_toffoli=twice,
                log2_twice_reconstruction_toffoli=log2(twice),
                complete_sample_toffoli_upper_bound=total,
                log2_complete_sample_toffoli_upper_bound=log2(total),
                mask_bad_event_upper_bound=str(delta),
                ideal_arithmetic_failure_upper_bound=str(ideal_failure),
            ))
        reference = next(row for row in rows if row['window'] == 16)
        # Reproduce the OLD draft ledger as an explicitly labeled baseline.
        b, w, h, L = 28, 16, 5, 32
        old_x = Decimal(2**b)
        old_K = int((old_x/(b*ln2-Decimal('1.1'))).to_integral_value(rounding=ROUND_CEILING))
        old_lk = (old_K-1).bit_length()
        old_afp, old_tau = 2*old_lk+4, old_lk+3
        old_move = 2*max(4*w*2**w, 35506*20*b*b*(b+1))
        old_Eh = 8*(h+1)*L*old_move
        old_D = 40*(b+1)+2
        old_GR = old_K*(2*old_Eh+40*b*(b+1)
            +old_tau*(2*old_D+20*(old_afp+1))+20*b*(n+1))
        old_GR += 40*(old_afp+1)+20*(old_lk+1)*(n+1)
        old_twice = 2*old_GR
        assert old_twice == 2908862055047641311408
        primitive_only_twice = 117347306655411783696
        baseline = dict(
            label='Original draft schedule, retained only for comparison',
            peak=1977, twice_reconstruction_toffoli=old_twice,
            log2_twice_reconstruction_toffoli=log2(old_twice),
            complete_sample_toffoli_upper_bound=old_twice+overhead,
            reconstruction_bound_ratio_old_over_new=str(
                Decimal(old_twice)/reference['twice_reconstruction_toffoli']),
            complete_sample_bound_ratio_old_over_new=str(
                Decimal(old_twice+overhead)/reference['complete_sample_toffoli_upper_bound']),
            label_of_intermediate='Arithmetic primitives alone changed; other original parameters retained',
            intermediate_twice_reconstruction_toffoli=primitive_only_twice,
            intermediate_log2_twice_reconstruction_toffoli=log2(primitive_only_twice),
        )
        result = dict(
            scope='Exact integer and high-precision numerical formula audit; '
                  'does not compile the complete sampler',
            height_certificate='normalized_height_results.json',
            chen_addition_toffoli=chen_add, chen_matched_width=chen_width,
            chen_500_additions=2*mr*chen_add,
            finite_ledgers=rows,
            reference_window=16,
            mask_bad_event_upper_bound=reference['mask_bad_event_upper_bound'],
            ideal_arithmetic_failure_upper_bound=reference['ideal_arithmetic_failure_upper_bound'],
            fourier_precision_bits=292, fourier_toffoli=fourier,
            preparation_toffoli=preparation, character_toffoli=character,
            non_reconstruction_toffoli=overhead,
            toffoli_scope='Includes one clean phase oracle, fixed 42-trial preparation '
                          'allowance and Fourier Toffolis; single-qubit rotation synthesis '
                          'is reported separately and is not included in this Toffoli count.',
            historical_baseline=baseline,
        )
    Path(__file__).with_suffix('.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
