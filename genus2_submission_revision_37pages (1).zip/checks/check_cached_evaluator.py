#!/usr/bin/env python3
"""Eight-word cached genus-two polynomial evaluator: exact trace certificate.

Run beside verify_local_evaluator.py. Only the Python standard library is used.
The word primitives are imported from the separately supplied literal evaluator.
No claim of full quantum-network synthesis is made.
"""
import argparse
from collections import Counter, defaultdict
from functools import lru_cache
import json
from pathlib import Path
import random
from verify_local_evaluator import Expr, var, bound, expressions, Compiler, reference, execute


a,c,s,u,z1,b,d,t,v,z2 = map(var, range(10))
K = z1*z2
K2 = K**2
du0 = d*z1**2-c*z2**2
du1 = b*z1**2-a*z2**2
su1 = b*z1**2+a*z2**2
dv0 = v*z1**3-u*z2**3
dv1 = t*z1**3-s*z2**3
C = a*d-c*b
R = du0**2-C*du1
E = dv1*du0-dv0*du1
L = du0*dv0-C*dv1
A = 2*(K2*L*E)+su1*E**2-K**4*R**2
T = L*E-K2*R**2
B1 = s*z2**3*R-a*z2**2*L-(a*b+c*z2**2)*E
B0 = u*z2**3*R-c*z2**2*L-c*b*E
outputs, N, D = expressions()


def replace(expr, mapping):
    if expr in mapping: return mapping[expr]
    if expr[0] == 'var': return expr
    if expr[0] == 'scale':
        return Expr(('scale',expr[1],replace(expr[2],mapping)))
    return Expr((expr[0], *(replace(child,mapping) for child in expr[1:])))


@lru_cache(None)
def expand(expr):
    """Exact expansion over Z into monomials ((variable, exponent),...)."""
    kind = expr[0]
    if kind == 'var': return {((expr[1],1),):1}
    if kind == 'scale': return {m:c*expr[1] for m,c in expand(expr[2]).items()}
    if kind in ('add','sub'):
        result = defaultdict(int, expand(expr[1]))
        for m,c in expand(expr[2]).items(): result[m] += c*(1 if kind=='add' else -1)
    else:
        if kind == 'sq': first = second = expand(expr[1])
        else: first,second = map(expand,expr[1:])
        result = defaultdict(int)
        for m,c in first.items():
            for n,d in second.items():
                powers = defaultdict(int,m)
                for v,p in n: powers[v] += p
                result[tuple(sorted(powers.items()))] += c*d
    return {m:c for m,c in result.items() if c}


@lru_cache(None)
def power_expr(variable, exponent):
    if exponent == 1: return var(variable)
    choices = []
    if exponent%2 == 0: choices.append(power_expr(variable,exponent//2)**2)
    for i in range(1,exponent):
        choices.append(power_expr(variable,i)*power_expr(variable,exponent-i))
    return min(choices, key=lambda e:(bound(e)[0],sum(bound(e)[1:])))


@lru_cache(None)
def product_expr(factors):
    if len(factors)==1: return power_expr(*factors[0])
    choices = []
    # Fix the final factor on the right to avoid duplicated partitions.
    for mask in range(1,1<<(len(factors)-1)):
        left = tuple(f for j,f in enumerate(factors) if mask>>j&1)
        right = tuple(f for j,f in enumerate(factors) if not mask>>j&1)
        choices.append(product_expr(left)*product_expr(right))
    return min(choices,key=lambda e:(bound(e)[0],sum(bound(e)[1:])))


def distributed(expr):
    terms = [coefficient*product_expr(monomial) for monomial,coefficient in expand(expr).items()]
    result = terms[0]
    for term in terms[1:]: result = result+term
    assert expand(result) == expand(expr)
    return result


class Schedule(Compiler):
    def __init__(self):
        super().__init__()
        self.rows=[]

    def reserve(self,word):
        self.free.remove(word)
        self.live+=1
        self.peak=max(self.peak,self.live)

    def clean_cache(self,expr,word):
        self.reserve(word)
        start=len(self.trace)
        self.accumulate(expr,word)
        return self.trace[start:]

    def erase_cache(self,expr,word):
        # Allocate fresh scratch: the preparation's scratch may now be cached.
        self.accumulate(expr,word,-1)
        self.release(word)

    def erase_history(self,history,word):
        self.undo(history)
        self.release(word)

    def row(self,label,start):
        counts=Counter(op[0] for op in self.trace[start:])
        self.rows.append(dict(stage=label, M=counts['M'],S=counts['S'],A=counts['A'],
                              live_words_after=self.live))


def prepare(schedule):
    start=len(schedule.trace)
    for expr,word in [(du0,15),(du1,16),(dv0,17),(dv1,18),(C,19)]:
        schedule.clean_cache(expr,word)
    shared={du0:var(15),du1:var(16),dv0:var(17),dv1:var(18),C:var(19)}
    for expr,word in [(R,20),(E,21),(L,22)]:
        schedule.clean_cache(replace(expr,shared),word)
    for expr,word in [(C,19),(du0,15),(du1,16),(dv0,17),(dv1,18)]:
        schedule.erase_cache(expr,word)
    schedule.clean_cache(K2,15)
    history=schedule.trace[start:]
    schedule.row('Prepare R,E,L,K2',start)
    return history,{R:var(20),E:var(21),L:var(22),K2:var(15)}


def clear_prepare(schedule,history):
    start=len(schedule.trace)
    schedule.undo(history)
    for word in [15,20,21,22]: schedule.release(word)
    schedule.row('Clear R,E,L,K2',start)


def build_node():
    sc=Schedule()
    prep,base=prepare(sc)
    rr,ee=var(20),var(21)
    tt=replace(T,base)
    start=len(sc.trace)
    ha=sc.clean_cache(replace(A,base),16)
    ht=sc.clean_cache(tt,17)
    sc.accumulate(rr**2*var(16),10)
    sc.accumulate(distributed(rr**2*var(16)*var(17)),12)
    sc.erase_history(ht,17)
    sc.erase_history(ha,16)
    sc.row('A contribution to U1,V1',start)
    start=len(sc.trace)
    hn=sc.clean_cache(distributed(replace(N,base)),16)
    ht=sc.clean_cache(tt,17)
    sc.accumulate(rr**2*var(16),11)
    sc.accumulate(distributed(rr**2*ee**2*var(16)),12,-1)
    sc.accumulate(distributed(rr**2*var(16)*var(17)),13)
    sc.erase_history(ht,17)
    sc.erase_history(hn,16)
    sc.row('N contribution to U0,V1,V0',start)
    for expr,target,label in [(B1,12,'B1 contribution to V1'),(B0,13,'B0 contribution to V0')]:
        start=len(sc.trace)
        history=sc.clean_cache(distributed(replace(expr,base)),16)
        sc.accumulate(distributed(rr**2*ee**3*var(16)),target,-1)
        sc.erase_history(history,16)
        sc.row(label,start)
    start=len(sc.trace)
    sc.accumulate(distributed(K*rr*ee),14)
    sc.row('Z contribution',start)
    clear_prepare(sc,prep)
    assert sc.live==0 and sc.peak==8
    counts=Counter(op[0] for op in sc.trace)
    assert (counts['M'],counts['S'],counts['A'])==(274,262,0),counts
    return sc


def build_terminal():
    sc=Schedule()
    prep,base=prepare(sc)
    start=len(sc.trace)
    sc.accumulate(distributed(replace(N,base)),10)
    hd=sc.clean_cache(replace(D,base),16)
    sc.trace.append(('Cgamma',10,(16,),1))
    sc.erase_history(hd,16)
    sc.row('N plus gamma D',start)
    clear_prepare(sc,prep)
    assert sc.live==0 and sc.peak==8
    counts=Counter(op[0] for op in sc.trace)
    assert (counts['M'],counts['S'],counts['Cgamma'])==(130,138,1),counts
    return sc


def build_ghost():
    """Correct all five measured-coordinate phases using one scalar target."""
    sc=Schedule()
    prep,base=prepare(sc)
    rr=var(20)
    for index in range(5):
        start=len(sc.trace)
        if index==0:
            sc.accumulate(replace(outputs[index],base),10)
        elif index in (1,2,4):
            sc.accumulate(distributed(replace(outputs[index],base)),10)
        else:
            hn=sc.clean_cache(distributed(replace(N,base)),16)
            ht=sc.clean_cache(replace(T,base),17)
            sc.accumulate(distributed(rr**2*var(16)*var(17)),10)
            sc.erase_history(ht,17)
            sc.erase_history(hn,16)
            hb=sc.clean_cache(distributed(replace(B0,base)),16)
            sc.accumulate(distributed(rr**2*var(21)**3*var(16)),10,-1)
            sc.erase_history(hb,16)
        history=sc.trace[start:]
        sc.trace.append(('PARITY',10,(index,),1))
        sc.undo(history)
        sc.row(['Ghost U1','Ghost U0','Ghost V1','Ghost V0','Ghost Z'][index],start)
    clear_prepare(sc,prep)
    counts=Counter(op[0] for op in sc.trace)
    assert sc.live==0 and sc.peak==8
    assert (counts['M'],counts['S'],counts['PARITY'])==(638,776,5),counts
    return sc


def execute_ghost(trace,registers,modulus,masks):
    phase=1
    for kind,target,sources,sign in trace:
        if kind=='PARITY':
            if (registers[target]&masks[sources[0]]).bit_count()%2:phase=-phase
        else:execute([(kind,target,sources,sign)],registers,modulus)
    return phase


def execute_terminal(trace,registers,modulus,gamma,inverse=False):
    stream=reversed(trace) if inverse else trace
    for kind,target,sources,sign in stream:
        if kind=='Cgamma':
            value=registers[sources[0]]*gamma
            registers[target]=(registers[target]+(-sign if inverse else sign)*value)%modulus
        else: execute([(kind,target,sources,sign)],registers,modulus,inverse)


def scalar_reference(inputs,modulus,gamma):
    a,c,s,u,z1,b,d,t,v,z2=inputs
    k=z1*z2
    du0=d*z1*z1-c*z2*z2
    du1=b*z1*z1-a*z2*z2
    dv0=v*z1**3-u*z2**3
    dv1=t*z1**3-s*z2**3
    cross=a*d-c*b
    r=du0*du0-cross*du1
    e=dv1*du0-dv0*du1
    ell=du0*dv0-cross*dv1
    numerator=(k*k*ell*ell+2*a*z2*z2*ell*e+(a*b-du0)*e*e
               -2*s*z2**3*r*e+(b*z1*z1+a*z2*z2)*k*k*r*r)
    return (numerator+gamma*k*k*e*e)%modulus


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output')
    args=parser.parse_args()
    node=build_node()
    terminal=build_terminal()
    ghost=build_ghost()
    rng=random.Random(20260915)
    trials=0
    for modulus in [3,5,7,9,11,15,17,101]:
        fixtures=[[x]*10 for x in [0,1,modulus-1]]
        fixtures += [[rng.randrange(modulus) for _ in range(10)] for _ in range(12)]
        for inputs in fixtures:
            targets=[rng.randrange(modulus) for _ in range(5)]
            initial=inputs+targets+[0]*8
            state=initial.copy()
            execute(node.trace,state,modulus)
            assert state[:10]==inputs and state[15:]==[0]*8
            assert state[10:15]==[(x+y)%modulus for x,y in zip(targets,reference(inputs,modulus))]
            execute(node.trace,state,modulus,True)
            assert state==initial
            gamma=rng.randrange(modulus)
            state=initial.copy()
            execute_terminal(terminal.trace,state,modulus,gamma)
            assert state[:10]==inputs and state[11:15]==targets[1:] and state[15:]==[0]*8
            assert state[10]==(targets[0]+scalar_reference(inputs,modulus,gamma))%modulus
            execute_terminal(terminal.trace,state,modulus,gamma,True)
            assert state==initial
            state=inputs+[0]*13
            masks=[rng.randrange(1<<modulus.bit_length()) for _ in range(5)]
            phase=execute_ghost(ghost.trace,state,modulus,masks)
            assert state==inputs+[0]*13
            expected_parity=sum((value&mask).bit_count() for value,mask in zip(reference(inputs,modulus),masks))%2
            assert phase==(-1 if expected_parity else 1)
            trials+=1
    result=dict(scope='Exact modular word trace; no full quantum-network synthesis',
                seed=20260915,local_words=8,node_counts=dict(Counter(op[0] for op in node.trace)),
                node_trace_length=len(node.trace),node_stages=node.rows,
                terminal_counts=dict(Counter(op[0] for op in terminal.trace)),
                terminal_trace_length=len(terminal.trace),terminal_stages=terminal.rows,
                ghost_counts=dict(Counter(op[0] for op in ghost.trace)),
                ghost_stages=ghost.rows,ghost_single_scalar_target=True,
                ghost_phase_and_cleanup_tests=trials,
                node_arbitrary_target_reversal_tests=trials,
                terminal_arbitrary_target_reversal_tests=trials,
                old_literal_operations=34205,old_uniform_allowance=35506,
                new_node_allowance=536,new_move_half_allowance=707,
                literal_reduction_factor=34205/536,node_allowance_reduction_factor=35506/536,
                move_allowance_reduction_factor=35506/707)
    payload=json.dumps(result,indent=2)
    Path(args.output or Path(__file__).with_name('cached_evaluator_results.json')).write_text(payload+'\n')
    print(payload)

if __name__=='__main__':main()
