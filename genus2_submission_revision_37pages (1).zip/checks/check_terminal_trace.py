#!/usr/bin/env python3
"""Check the separately claimed terminal N + gamma D accumulation trace."""
import json
import random
from collections import Counter
from pathlib import Path
import verify_local_evaluator as v

def main():
    _,N,D=v.expressions()
    c=v.Compiler()
    c.accumulate(N,10)
    peakN=c.peak
    start=len(c.trace)
    c.peak=0
    c.accumulate(D,11)
    history=c.trace[start:]
    peakD=c.peak
    c.trace.append(('C',10,(11,),1))
    c.undo(history)
    counts=Counter(row[0] for row in c.trace)
    assert (counts['M'],counts['S'],counts['C'])==(985,1292,1)
    assert max(peakN,peakD+1)==6
    rng=random.Random(20260915)
    trials=0
    for p in [3,5,7,9,11,15,17,101]:
        for _ in range(12):
            xs=[rng.randrange(p) for _ in range(10)]
            target,gamma=rng.randrange(p),rng.randrange(p)
            initial=xs+[target]+[0]*12
            regs=initial.copy()
            for kind,t,src,sign in c.trace:
                if kind=='C':regs[t]=(regs[t]+sign*gamma*regs[src[0]])%p
                else:v.execute([(kind,t,src,sign)],regs,p)
            def ev(e):
                k=e[0]
                if k=='var':return xs[e[1]]
                if k=='scale':return e[1]*ev(e[2])
                if k=='add':return ev(e[1])+ev(e[2])
                if k=='sub':return ev(e[1])-ev(e[2])
                if k=='sq':return ev(e[1])**2
                if k=='mul':return ev(e[1])*ev(e[2])
                raise ValueError(k)
            assert regs[:10]==xs and regs[10]==(target+ev(N)+gamma*ev(D))%p
            assert regs[11:]==[0]*12
            for kind,t,src,sign in reversed(c.trace):
                if kind=='C':regs[t]=(regs[t]-sign*gamma*regs[src[0]])%p
                else:v.execute([(kind,t,src,sign)],regs,p,inverse=True)
            assert regs==initial
            trials+=1
    out={'scope':'Modular word-level terminal trace, not a Toffoli network',
         'M':counts['M'],'S':counts['S'],'fixed_constant_multiply_accumulates':counts['C'],
         'local_words_including_denominator':max(peakN,peakD+1),
         'arbitrary_accumulator_reversal_tests':trials,'failures':0}
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
