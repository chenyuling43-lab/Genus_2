#!/usr/bin/env python3
"""Verify the complete cached traces as polynomial identities over Z."""
import argparse
from collections import defaultdict
from functools import lru_cache
import json
from pathlib import Path
from check_cached_evaluator import build_node, build_terminal, build_ghost, outputs, N, D

class Poly(dict):
    def __add__(self,other):
        result=Poly(self)
        for powers,coefficient in other.items():
            result[powers]=result.get(powers,0)+coefficient
            if not result[powers]:del result[powers]
        return result
    def __mul__(self,other):
        if isinstance(other,int):
            return Poly({p:c*other for p,c in self.items() if c*other})
        result=defaultdict(int)
        for p,c in self.items():
            for q,d in other.items():
                result[tuple(a+b for a,b in zip(p,q))]+=c*d
        return Poly({p:c for p,c in result.items() if c})

variables=[Poly({tuple(int(i==j) for j in range(10)):1}) for i in range(10)]

@lru_cache(None)
def direct(expr):
    k=expr[0]
    if k=='var':return variables[expr[1]]
    if k=='scale':return direct(expr[2])*expr[1]
    if k=='sq':return direct(expr[1])*direct(expr[1])
    l,r=direct(expr[1]),direct(expr[2])
    if k=='add':return l+r
    if k=='sub':return l+r*(-1)
    return l*r

def run(trace,gamma=None):
    state=variables+[Poly() for _ in range(13)]
    # No output is ever used as a source, so zero-target correctness implies
    # correctness for arbitrary targets without introducing five more variables.
    assert not any(10<=s<15 for _,_,sources,_ in trace for s in sources)
    for kind,target,sources,sign in trace:
        if kind=='PARITY':
            assert state[target]==direct(outputs[sources[0]])
            continue
        if kind=='M':value=state[sources[0]]*state[sources[1]]
        elif kind=='S':value=state[sources[0]]*state[sources[0]]
        elif kind=='Cgamma':value=state[sources[0]]*gamma
        else:value=state[sources[0]]
        state[target]=state[target]+value*sign
    assert state[:10]==variables and not any(state[15:])
    return state[10:15]

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--output')
    args=parser.parse_args()
    node=run(build_node().trace)
    assert node==[direct(e) for e in outputs]
    terminal=build_terminal().trace
    zero,one=run(terminal,0),run(terminal,1)
    assert zero[0]==direct(N) and one[0]==direct(N)+direct(D)
    assert not any(zero[1:]+one[1:])
    ghost=run(build_ghost().trace)
    assert not any(ghost)
    result=dict(ghost_coordinate_identities=5,ghost_cleanup=True,method='Exact sparse polynomial propagation of every word operation over Z',
                node_identities=5,terminal_identities=2,
                input_polynomials_preserved=True,all_local_polynomials_zero=True,
                output_targets_never_read=True,
                node_monomial_counts=[len(p) for p in node],
                node_coefficient_norms=[sum(abs(c) for c in p.values()) for p in node],
                gamma_extension='One linear Cgamma call; gamma=0,1 identities establish all gamma')
    payload=json.dumps(result,indent=2)
    Path(args.output or Path(__file__).with_name('cached_symbolic_results.json')).write_text(payload+'\n')
    print(payload)
if __name__=='__main__':main()
