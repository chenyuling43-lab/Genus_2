"""Reproduce manuscript Table F.1 and canonical collision identities independently."""
import ast, json, math
from itertools import product
from fractions import Fraction
from pathlib import Path
import numpy as np
# Import only the local reference polynomial/Cantor definitions, not its test loop.
reference=Path(__file__).with_name('audit_finite.py')
module=ast.parse(reference.read_text())
cut=next(i for i,n in enumerate(module.body) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='reports' for t in n.targets))
ns={};exec(compile(ast.Module(body=module.body[:cut],type_ignores=[]),str(reference),'exec'),ns)
fixtures=[(3,[1,2,1,2,0,1],([0,0,1],[1,1]),11),(5,[3,0,2,1,0,1],([3,1],[1]),23),(7,[6,5,0,4,0,1],([3,3,1],[5,5]),11),(11,[3,5,7,0,0,1],([0,0,1],[5,6]),73)]
rows=[];maxfft=0;maxrect=0
for q,f,P,r in fixtures:
 ns['p']=q;tr=ns['tr'];mul=ns['mul'];sub=ns['sub'];div=ns['div'];cantor=ns['cantor'];xgcd=ns['xgcd']
 assert len(xgcd(f,[i*f[i] for i in range(1,len(f))])[0])==1
 group=[([1],[])];cur=P
 while cur!=group[0]:
  assert cur not in group
  group.append(cur);cur=cantor(cur,P,f)
 assert len(group)==r
 allclasses=[([1],[])]
 for d in (1,2):
  for uc in product(range(q),repeat=d):
   u=list(uc)+[1]
   for vc in product(range(q),repeat=d):
    v=tr(vc)
    if not div(sub(f,mul(v,v)),u)[1]:allclasses.append((u,v))
 e=sum(len(u)<3 for u,v in group);m=[sum(len(u)==3 and u[0]==a for u,v in group) for a in range(q)]
 chi=lambda x:0 if x%q==0 else (1 if pow(x%q,(q-1)//2,q)==1 else -1)
 sq=lambda x:chi(x)+(x%q==0)
 signs=np.array([[1 if len(u)<3 else sq(u[0]+g) for u,v in group] for g in range(q)])
 means=[Fraction(int(sum(s)),r) for s in signs]
 success=[1-x*x for x in means]
 avg=sum(success)/q;V=Fraction(q-1,q)*(1-Fraction(e*e+sum(x*x for x in m),r*r))
 aa,bb=np.indices((r,r));idx=(aa+2*bb)%r
 for g in range(q):
  actual=abs(np.fft.fft2(signs[g][idx])/(r*r))**2
  predicted=np.zeros((r,r));one=abs(np.fft.fft(signs[g])/r)**2
  for u in range(r):predicted[u,2*u%r]=one[u]
  maxfft=max(maxfft,float(np.max(abs(actual-predicted))),float(abs(actual[0,0]-float(means[g]**2))))
 # Independent C(F_q) and C(F_q^2) counts.
 N1=1+sum(1+chi(sum(c*x**i for i,c in enumerate(f))) for x in range(q))
 nonsq=next(a for a in range(2,q) if chi(a)==-1)
 elems=list(product(range(q),repeat=2))
 def em(a,b):return ((a[0]*b[0]+nonsq*a[1]*b[1])%q,(a[0]*b[1]+a[1]*b[0])%q)
 def ef(x):
  out=(0,0)
  for c in f[::-1]:out=em(out,x);out=((out[0]+c)%q,out[1])
  return out
 squarecounts={x:0 for x in elems}
 for x in elems:squarecounts[em(x,x)]+=1
 N2=1+sum(squarecounts[ef(x)] for x in elems)
 assert (N1*N1+N2)//2-q==len(allclasses)
 row={'q':q,'subgroup_order':r,'J_order':len(allclasses),'N1':N1,'N2':N2,'lower_degree_count':e,'fiber_counts':m,'unshifted_success':str(success[0]),'mean_shift_success':str(avg),'V_G':str(V)}
 if q in (3,5,7):
  n=q.bit_length();ell=2+4*n
  def enc(D):
   u,v=D;d=len(u)-1
   words=[u[1] if d==2 else 0,u[0] if d else 0,v[1] if len(v)>1 else 0,v[0] if len(v)>0 else 0]
   return d+sum(w<<(2+i*n) for i,w in enumerate(words))
  encs=list(map(enc,group));assert len(set(encs))==r
  restricted={tuple((-1)**((seed&v).bit_count()%2) for v in encs) for seed in range(1<<ell)}
  phases=np.asarray(list(restricted),dtype=np.int64)
  cov=phases.T@phases
  assert np.array_equal(cov,len(phases)*np.eye(r,dtype=np.int64))
  # Uniform multiplicity follows from linear seed-to-sign map and is checked directly.
  from collections import Counter
  mult=Counter(tuple((-1)**((seed&v).bit_count()%2) for v in encs) for seed in range(1<<ell))
  assert len(set(mult.values()))==1
  ar,br=np.indices((8,4));ir=(ar+2*br)%r
  out=abs(np.fft.fft2(phases[:,ir],axes=(-2,-1))/32)**2
  avgdist=out.mean(axis=0)
  full=sum(abs(np.fft.fft2((ir==t).astype(float))/32)**2 for t in range(r))
  maxrect=max(maxrect,float(np.max(abs(avgdist-full))))
  row['encoding_bits']=ell;row['distinct_canonical_restrictions']=len(phases);row['seed_multiplicity']=next(iter(mult.values()));row['canonical_covariance_exact_identity']=True
 rows.append(row)
assert [r['mean_shift_success'] for r in rows]==['256/363','2192/2645','96/121','55128/58619']
assert maxfft<2e-12 and maxrect<2e-12
report={'scope':'Exact Cantor subgroup, point/fiber enumeration, canonical integer covariance; floating-point 2D FFT checks at tolerance2e-12. Not complete quantum circuit synthesis.','all_field_seeds_checked':sum(q for q,_,_,_ in fixtures),'max_exact_domain_FFT_discrepancy':maxfft,'max_rectangular_distribution_discrepancy':maxrect,'rows':rows}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
