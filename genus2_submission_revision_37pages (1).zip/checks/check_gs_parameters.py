#!/usr/bin/env python3
"""Check the displayed transformed curve and subgroup generator.

The displayed generator, subgroup primality, and full Jacobian cardinality
are certified using exact arithmetic. The source-model coordinate change
is not checked here. Requires audit_finite.py and the supplied recursive
primality certificate; Python standard library only.
"""
from pathlib import Path
import json
import math
from verify_subgroup_prime_certificate import verify as verify_subgroup_prime

here = Path(__file__).resolve().parent
# Reuse the independent polynomial/Cantor implementation without its test loop.
ns = {}
source = (here / 'audit_finite.py').read_text()
exec(compile(source.split('\nreports=[]')[0], 'audit_finite_definitions', 'exec'), ns)
q = 2**127 - 1
r = 2**250 - int('334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD', 16)
ns['p'] = q
f = [int(x, 16) for x in [
    '3AF79604317A895BB28139B4DDD66D56',
    '4761178EC206F6DB2E90B2BF4913BE47',
    '432B709D2D5801982F927BB531F0F535',
    '00D26A12F16AE9D00045BB92C5382A8E', '0', '1']]
P = ([int('384CB21DBD5E1F600F3FE0E336182F14',16),
      int('3CB88102BCDD5A7AAA402188B6783790',16),1],
     [int('4F4AB1A434DFCBE8FD26C203D18D54F4',16),
      int('444569AF177A9C1C721736D8F288C942',16)])
derivative = [j*f[j] for j in range(1,len(f))]
assert len(ns['xgcd'](f, derivative)[0]) == 1
assert not ns['div'](ns['sub'](f, ns['mul'](P[1], P[1])), P[0])[1]
identity = ([1], [])
assert P != identity
acc, multiple, scalar = identity, P, r
while scalar:
    if scalar & 1:
        acc = ns['cantor'](acc, multiple, f)
    scalar >>= 1
    if scalar:
        multiple = ns['cantor'](multiple, multiple, f)
assert acc == identity
# Lucas--Lehmer is a primality certificate for a Mersenne number of prime exponent.
assert all(127 % d for d in range(2, math.isqrt(127)+1))
ll = 4
for _ in range(125):
    ll = (ll*ll-2) % q
assert ll == 0

prime_certificate = verify_subgroup_prime()
assert int(prime_certificate['subgroup_order']) == r
assert prime_certificate['deterministic_primality_verified']
# P is nonidentity, [r]P = 0, and r is prime, so ord(P) = r.
# The genus-two Weil interval has exactly one multiple of r.
sqrt_upper = math.isqrt(q)+1
center = q*q+6*q+1
radius = 4*(q+1)*sqrt_upper
lower, upper = center-radius, center+radius
quotient_min = (lower+r-1)//r
quotient_max = upper//r
assert quotient_min == quotient_max == 16
jacobian_cardinality = 16*r
assert lower <= jacobian_cardinality <= upper

result = dict(q=str(q), r=str(r), field_bits=q.bit_length(),
              subgroup_bits=r.bit_length(), curve_squarefree=True,
              displayed_generator_membership=True, displayed_generator_nonidentity=True,
              r_times_generator_is_identity=True, exact_generator_order=str(r),
              lucas_lehmer_q_prime=True,
              r_primality_status='deterministically proved by recursive Pocklington certificate',
              r_primality_certificate_nodes=prime_certificate['certified_primes_including_leaves'],
              weil_interval_lower=str(lower), weil_interval_upper=str(upper),
              weil_interval_sqrt_upper=str(sqrt_upper),
              weil_interval_minimum_cofactor=quotient_min,
              weil_interval_maximum_cofactor=quotient_max,
              jacobian_cardinality=str(jacobian_cardinality),
              jacobian_cofactor=16,
              jacobian_cardinality_status='proved: r divides #J and the integer Weil interval contains only the multiple 16r', 
              coordinate_transformation_status='displayed transformed model checked; source-model transformation not independently checked')
(here/'gs_parameter_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
