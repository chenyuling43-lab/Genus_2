#!/usr/bin/env python3
"""Exact transcription of Appendix F MATLAB arithmetic; not MATLAB execution."""
from pathlib import Path
import json
import random

here = Path(__file__).resolve().parent
ns = {}
exec(compile((here/'audit_finite.py').read_text().split('\nreports=[]')[0],
             'cantor_definitions', 'exec'), ns)

def matlab_add(D,L,p,curve,method='a4'):
    a,c,s,t,z = D
    b,d,u,v,w = L
    m = lambda x:x%p
    z2,w2,z3,w3,z4 = m(z*z),m(w*w),m(z**3),m(w**3),m(z**4)
    A=m(z2*w2)
    du1,su1=m(b*z2-a*w2),m(b*z2+a*w2)
    du0,su0=m(d*z2-c*w2),m(d*z2+c*w2)
    dv1,dv0=m(u*z3-s*w3),m(v*z3-t*w3)
    E=m(su1*du1-A*du0)
    G=m(su1*du0+du1*su0)
    H=m((su1*du1-2*A*du0)*du0-du1**2*su0)
    if not z*w*H%p: return None
    K=m(z*w)
    C2=m(dv1*G-2*dv0*E)
    C3=m(2*K*K*(dv1*du0-dv0*du1))
    W=m(K*H)
    Lam=m(W*z4)
    B2,B3=m(C2*z4),m(C3*z4)
    if not B3:return None
    B1=m(s*W*z+C2*a*z2-C3*(a*a-c*z2))
    B0=m(t*W*z+C2*c*z2-C3*a*c)
    A5=m(2*B2*B3-Lam*Lam)
    Nq,Dq=m(A*A5-B3**2*su1),m(A*B3**2)
    if method=='a4':
        A4=m(B2**2+2*B1*B3)
        Nr=m(A*A*A4-A*B3**2*(su0+a*b)-su1*Nq)
        Dr=m(A*A*B3**2)
    else:
        if not c*d%p:return None
        A0=m(B0*B0-curve[0]*Lam*Lam)
        Nr,Dr=m(A*A0),m(B3*B3*c*d)
    Ns=m(-B1*Dq**2*Dr+B2*Nq*Dq*Dr-B3*Nq**2*Dr+B3*Nr*Dq**2)
    Nt=m(-B0*Dq*Dr+B2*Nr*Dq-B3*Nq*Nr)
    zout=m(Lam*Dq*Dr)
    if not zout:return None
    return [m(Nq*Lam**2*Dq*Dr**2),m(Nr*Lam**2*Dq**2*Dr),
            m(Ns*Lam**2*Dq*Dr**2),m(Nt*Lam**2*Dq**2*Dr**2),zout]

def recover(P,p):
    z=pow(P[4],-1,p)
    return [P[0]*z*z%p,P[1]*z*z%p,P[2]*z**3%p,P[3]*z**3%p]

p=101
ns['p']=p
f=[3,5,7,11,0,1]
D,L=[57,11,53,60,2],[49,42,94,99,3]
R=matlab_add(D,L,p,f)
R0=matlab_add(D,L,p,f,'a0')
assert R==[81,53,65,52,68]
assert recover(R,p)==recover(R0,p)==[56,94,30,24]
P1=([28,90,1],[58,95]);P2=([72,84,1],[71,97])
for P in [P1,P2]:
    assert not ns['div'](ns['sub'](f,ns['mul'](P[1],P[1])),P[0])[1]
assert len(ns['xgcd'](f,[i*f[i] for i in range(1,6)])[0])==1
ell=[19,54,76,11]
rhs=ns['sc'](ns['mul'](ns['mul'](P1[0],P2[0]),[94,56,1]),20)
assert ns['sub'](ns['mul'](ell,ell),f)==rhs
assert ns['cantor'](P1,P2,f)==([94,56,1],[24,30])
# Generate valid rational-support degree-two divisors independently.
points=[(x,y) for x in range(p) for y in range(p)
        if (y*y-sum(c*x**i for i,c in enumerate(f)))%p==0]
rng=random.Random(20260915)
def random_divisor():
    while True:
        x1,y1=rng.choice(points);x2,y2=rng.choice(points)
        if x1!=x2:break
    vv1=(y2-y1)*pow(x2-x1,-1,p)%p
    return ([(x1*x2)%p,(-x1-x2)%p,1],[(y1-vv1*x1)%p,vv1])
counts={'a4':0,'a0':0};skips={'a4':0,'a0':0}
for _ in range(1000):
    X,Y=random_divisor(),random_divisor()
    z1,z2=rng.randrange(1,p),rng.randrange(1,p)
    xd,yd=ns['coords'](X,z1),ns['coords'](Y,z2)
    expected=ns['cantor'](X,Y,f)
    for method in counts:
        answer=matlab_add(xd,yd,p,f,method)
        if answer is None:skips[method]+=1;continue
        u1,u0,v1,v0=recover(answer,p)
        got=(ns['tr']([u0,u1,1]),ns['tr']([v0,v1]))
        assert got==expected,(method,X,Y,got,expected)
        counts[method]+=1
result={'scope':'Exact Python transcription of MATLAB equations, not execution in MATLAB or Octave',
        'default_a4_projective_output':R,'default_a0_projective_output':R0,
        'default_affine_output':recover(R,p),'example_factorization_verified':True,
        'independent_cantor_comparisons':counts,'expected_generic_branch_rejections':skips,
        'random_seed':20260915,'failures':0}
(here/'matlab_algebra_results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
