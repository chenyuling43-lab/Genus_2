#!/usr/bin/env python3
"""Targeted fresh audit: compose cached word traces with actual gate primitives.
This resolves primitive-to-word wire aliasing, shared scratch, and scalar phase
integration; it is not a full sampler compilation or universal state test.
"""
import argparse,json,random
from pathlib import Path
from collections import Counter
HERE=Path(__file__).resolve().parent
import primitive_improvement as pg
import check_cached_evaluator as ce

def compiled(trace,p,b,scalar,gamma=0):
    words=list(range(10))+([10] if scalar else list(range(10,15)))+list(range(15,23))
    mapping={word:list(range(i*b,(i+1)*b)) for i,word in enumerate(words)}
    scratch=list(range(len(words)*b,len(words)*b+b+4))
    templates={'M':pg.multiply(p,b),'S':pg.multiply(p,b,True),'Cgamma':pg.constant_multiply(p,gamma,b)}
    result=[]
    for kind,target,sources,sign in trace:
        if kind=='PARITY':
            assert target==10
            result.append(('Zmask',mapping[target],sources[0]))
            continue
        assert target not in sources
        square=kind!='M'
        x,y,z,operand,high,flag,carry=pg.allocation(b,square)
        local={}
        for src,dst in [(x,mapping[sources[0]]),(z,mapping[target]),(operand+[high,flag,carry],scratch)]:local.update(zip(src,dst))
        if kind=='M':local.update(zip(y,mapping[sources[1]]))
        template=templates[kind]
        gates=[]
        for controls,target_mask in (template if sign==1 else reversed(template)):
            control_wires=[local[j] for j in range(controls.bit_length()) if controls>>j&1]
            gates.append(pg.gate(control_wires,local[target_mask.bit_length()-1]))
        result.extend(gates)
    return result,mapping,scratch

def state_from(words,mapping):
    return sum(pg.encode(mapping[i],v) for i,v in enumerate(words) if i in mapping)

def simulate(circuit,state,masks):
    phase=1
    for item in circuit:
        if item[0]=='Zmask':
            _,bits,index=item
            if (pg.extract(bits,state)&masks[index]).bit_count()%2:phase=-phase
        else:
            controls,target=item
            if state&controls==controls:state^=target
    return state,phase

def main():
    rng=random.Random(17092026)
    rows=[]
    for p,b in [(3,2),(9,5)]:
        inputs_cases=[[0]*10,[1]*10,[p-1]*10,[rng.randrange(p) for _ in range(10)]]
        for kind,sc,scalar in [('node',ce.build_node(),False),('terminal',ce.build_terminal(),True),('ghost',ce.build_ghost(),True)]:
            gamma=p-2
            circuit,mapping,scratch=compiled(sc.trace,p,b,scalar,gamma)
            for inputs in inputs_cases:
                targets=[rng.randrange(p) for _ in range(5)]
                initial=inputs+([0]*5 if kind=='ghost' else targets)+[0]*8
                masks=[rng.randrange(1<<b) for _ in range(5)]
                original=state_from(initial,mapping)
                actual,phase=simulate(circuit,original,masks)
                expected=initial.copy()
                if kind=='node':expected[10:15]=[(a+c)%p for a,c in zip(targets,ce.reference(inputs,p))]
                elif kind=='terminal':expected[10]=(targets[0]+ce.scalar_reference(inputs,p,gamma))%p
                else:
                    parity=sum((a&m).bit_count() for a,m in zip(ce.reference(inputs,p),masks))%2
                    assert phase==(-1 if parity else 1)
                assert actual==state_from(expected,mapping),(p,b,kind,inputs)
                if kind!='ghost':
                    recovered,_=simulate(list(reversed(circuit)),actual,masks)
                    assert recovered==original
            gate_types=Counter('Zmask' if g[0]=='Zmask' else str(g[0].bit_count()) for g in circuit)
            primitive_bound=(Counter(op[0] for op in sc.trace)['M']*(24*b*b-17*b+4)+Counter(op[0] for op in sc.trace)['S']*(24*b*b-23*b+4)+Counter(op[0] for op in sc.trace)['Cgamma']*(10*b*b-5*b))
            assert gate_types['2']<=primitive_bound
            assert len(scratch)==b+4
            rows.append(dict(p=p,b=b,interface=kind,basis_cases=len(inputs_cases),physical_residue_words=len(mapping),clean_primitive_scratch_bits=len(scratch),ordinary_toffoli=gate_types['2'],stated_bound=primitive_bound,phase_markers=gate_types['Zmask'],gate_entries=len(circuit)))
    result=dict(status='passed',purpose='Actual-gate composition of cached word traces, with padded odd composite modulus and measured scalar phase markers',gate_network_basis_cases=sum(row['basis_cases'] for row in rows),arbitrary_target_forward_and_inverse_cases=sum(row['basis_cases'] for row in rows if row['interface']!='ghost'),recorded_phase_cases=sum(row['basis_cases'] for row in rows if row['interface']=='ghost'),rows=rows)
    payload=json.dumps(result,indent=2)+'\n'
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,default=HERE/'cached_gate_integration_results.json')
    args=parser.parse_args()
    args.output.write_text(payload)
    print(payload,end='')


if __name__=='__main__':main()
