#!/usr/bin/env python3
"""Exhaustive small-group checks for the two-seed masking theorem."""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import json

checks = {"balanced_composite_histograms":0, "child_pair_histograms": 0, "translation_histograms": 0,
          "elliptic_bad_pair_counts": 0, "pointwise_tree_inputs": 0}

def nodes(lo, size):
    if size == 1:
        return []
    left = size // 2
    return [(lo, left, size-left)] + nodes(lo, left) + nodes(lo+left, size-left)

def mask_sum(U, V, start, length, p):
    return (length * U + (length * start + length * (length-1)//2) * V) % p

for p in (3, 5, 7, 11, 13):
    for L in range(2, min(p, 10)):
        # All interval starts and child splits, hence every internal node
        # of every ordered tree of at most L leaves.
        for start in range(L-1):
            for a in range(1, L-start):
                for b in range(1, L-start-a+1):
                    det = a * (b*(start+a)+b*(b-1)//2) - b*(a*start+a*(a-1)//2)
                    assert 2 * det == a*b*(a+b)
                    hist = Counter((mask_sum(U,V,start,a,p), mask_sum(U,V,start+a,b,p))
                                   for U in range(p) for V in range(p))
                    assert len(hist) == p*p and set(hist.values()) == {1}
                    checks["child_pair_histograms"] += 1
        th = Counter(mask_sum(U,V,0,L,p) for U in range(p) for V in range(p))
        assert len(th) == p and set(th.values()) == {p}
        checks["translation_histograms"] += 1
        B = {(a,b) for a in range(p) for b in range(p)
             if a == 0 or b == 0 or a == b or a == (-b) % p}
        assert len(B) == 4*p-3
        checks["elliptic_bad_pair_counts"] += 1
        for x in range(p):
            bad = 0
            A = [(i+1)*x % p for i in range(L)]
            for U in range(p):
                for V in range(p):
                    leaf = [(A[i]+U+i*V) % p for i in range(L)]
                    if any((sum(leaf[j:j+a]) % p, sum(leaf[j+a:j+a+b]) % p) in B
                           for j,a,b in nodes(0,L)):
                        bad += 1
            assert Fraction(bad,p*p) <= min(Fraction(1), (L-1)*Fraction(4*p-3,p*p))
            checks["pointwise_tree_inputs"] += 1
# Balanced cyclic groups, including composite odd order and L>|G|.
for p in (3, 5, 9, 15, 21):
    for L in (2,4,8,16,32):
        for j,a,b in nodes(0,L):
            hist = Counter((mask_sum(U,V,j,a,p),mask_sum(U,V,j+a,b,p))
                           for U in range(p) for V in range(p))
            assert len(hist) == p*p and set(hist.values()) == {1}
            checks["balanced_composite_histograms"] += 1
# Unbalanced exception over Z/3 at split (1,2): determinant 3.
p = 3
bad_hist = Counter((mask_sum(U,V,0,1,p),mask_sum(U,V,1,2,p))
                   for U in range(p) for V in range(p))
assert len(bad_hist) == 3 < p*p
# Conditional translation counterexample: the root sums must add to F+T.
p, L = 7, 4
conditional = Counter((mask_sum(U,V,0,2,p),mask_sum(U,V,2,2,p))
                      for U in range(p) for V in range(p)
                      if mask_sum(U,V,0,L,p) == 0)
assert len(conditional) == p < p*p
result = {"status":"passed", **checks,
          "conditional_translation_root_pairs":len(conditional),
          "independent_root_pairs":p*p,
          "scope":"Exhaustive finite checks support, but do not replace, the determinant and channel proofs."}
Path(__file__).with_name("affine_masks_results.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
