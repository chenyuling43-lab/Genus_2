#!/usr/bin/env python3
"""Independent exact sparse-polynomial audit; Python standard library only.

Run this script in any directory. Results are written beside the script.
Variables are (U1_1,U0_1,V1_1,V0_1,Z1,U1_2,U0_2,V1_2,V0_2,Z2).
"""
import json
from pathlib import Path
from collections import defaultdict
class Poly(dict):
 def __add__(self, other):
  if isinstance(other,int): other=Poly({(0,)*10:other}) if other else Poly()
  o=Poly(self)
  for e,c in other.items():
   o[e]=o.get(e,0)+c
   if not o[e]: del o[e]
  return o
 __radd__=__add__
 def __neg__(self): return Poly({e:-c for e,c in self.items()})
 def __sub__(self,other): return self+(-other)
 def __rsub__(self,other): return -self+other
 def __mul__(self,other):
  if isinstance(other,int): return Poly({e:c*other for e,c in self.items() if c*other})
  o=defaultdict(int)
  for e,c in self.items():
   for f,d in other.items(): o[tuple(x+y for x,y in zip(e,f))]+=c*d
  return Poly({e:c for e,c in o.items() if c})
 __rmul__=__mul__
 def __pow__(self,n):
  o=Poly({(0,)*10:1}); p=self
  while n:
   if n%2: o=o*p
   n//=2
   if n: p=p*p
  return o
vars=[Poly({tuple(int(i==j) for j in range(10)):1}) for i in range(10)]
a,c,s,u,z,b,d,t,v,w=vars
K=z*w; Asc=K*K
DU0=d*z*z-c*w*w; DU1=b*z*z-a*w*w
DV0=v*z**3-u*w**3; DV1=t*z**3-s*w**3
SU1=b*z*z+a*w*w; SU0=d*z*z+c*w*w
C=a*d-c*b; R=DU0**2-C*DU1; E=DV1*DU0-DV0*DU1; L=DU0*DV0-C*DV1
N=Asc*L**2+2*a*w*w*L*E+(a*b-DU0)*E**2-2*s*w**3*R*E+SU1*Asc*R**2
D=Asc*E**2
J=Asc*L+SU1*E
A=2*Asc*L*E+SU1*E**2-K**4*R**2
T=L*E-Asc*R**2
B1=s*w**3*R-a*w*w*L-(a*b+c*w*w)*E
B0=u*w**3*R-c*w*w*L-c*b*E
out=[A*R**2,N*R**2,R**2*(A*T-E**2*(B1*E+N)),R**2*(N*T-B0*E**3),K*R*E]
weights=[2,2,3,3,1]*2
results={}
expected_bounds={"U1":20480,"U0":40960,"V1":6291456,"V0":6029312,"Z":64}
for name,p in [('N',N),('D',D)]+list(zip(['U1','U0','V1','V0','Z'],out)):
 deg=max(sum(e) for e in p)
 norm=sum(abs(cc) for cc in p.values())
 bideg={(sum(e[i]*weights[i] for i in range(5)),sum(e[i]*weights[i] for i in range(5,10))) for e in p}
 results[name]={"monomial_count":len(p),"ordinary_total_degree":deg,"exact_coefficient_l1_norm":norm,"weighted_bidegrees":[list(x) for x in sorted(bideg)]}
 if name in expected_bounds:
  results[name]["manuscript_coefficient_norm_upper_bound"]=expected_bounds[name]
  results[name]["upper_bound_verified"]=norm<=expected_bounds[name]
  assert norm<=expected_bounds[name]
 print(name,'monomials',len(p),'degree',deg,'norm',norm,'bidegrees',bideg,flush=True)
# Expanded legacy denominator clearing, correctly using A_sc in C3 (manuscript eq 72 misprints mathcal A).
EE=SU1*DU1-Asc*DU0; GG=SU1*DU0+DU1*SU0
HH=(SU1*DU1-2*Asc*DU0)*DU0-DU1**2*SU0
C2=DV1*GG-2*DV0*EE; C3=2*Asc*(DV1*DU0-DV0*DU1)
WW=K*HH; lam=WW*z**4; BB2=C2*z**4; BB3=C3*z**4
BB1=s*WW*z+C2*a*z*z-C3*(a*a-c*z*z)
a5=2*BB2*BB3-lam**2; a4=BB2**2+2*BB1*BB3
Na=Asc*a5-BB3**2*SU1
Nb=Asc**2*a4-Asc*BB3**2*(SU0+a*b)-SU1*Na
Db=Asc**2*BB3**2
print('H=-2AscR',HH==-2*Asc*R)
print('N square cancellation',Nb==(2*z**7*w**3)**2*N)
print('D square cancellation',Db==(2*z**7*w**3)**2*D)

identities={
 "interpolation_determinant_equals_minus_two_A_sc_R":HH==-2*Asc*R,
 "legacy_N_beta_equals_square_factor_times_N_star":Nb==(2*z**7*w**3)**2*N,
 "legacy_D_beta_equals_square_factor_times_D_star":Db==(2*z**7*w**3)**2*D,
}
assert all(identities.values())
assert [results[x]["ordinary_total_degree"] for x in ["U1","U0","V1","V0","Z"]]==[32,31,48,47,15]
assert results["N"]["exact_coefficient_l1_norm"]==232
assert results["D"]["exact_coefficient_l1_norm"]==64
report={"method":"Exact sparse expansion over Z with integer coefficients; no external dependencies", "input_variables":["U1_1","U0_1","V1_1","V0_1","Z1","U1_2","U0_2","V1_2","V0_2","Z2"], "polynomials":results,"polynomial_identities":identities,"notes":["Legacy C3 uses the corrected scalar A_sc, not the five-output addition map mathcal A.","The displayed compact-map coefficient-norm constants are verified upper bounds, not exact coefficient norms.","The original factor 2^8 and tree growth factor 20 are retained."]}
Path(__file__).with_name("audit_arithmetic_results.json").write_text(json.dumps(report,indent=2)+"\n")
