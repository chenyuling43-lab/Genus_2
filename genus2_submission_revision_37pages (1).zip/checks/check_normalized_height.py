from pathlib import Path
from collections import defaultdict
import json,math
root=Path(__file__).resolve().parent
source=root/'audit_arithmetic.py'
ns={};exec(compile(source.read_text().split('weights=')[0],str(source),'exec'),ns)
rows=[]
for name,p,w in zip(['U1','U0','V1','V0','Z'],ns['out'],[2,2,3,3,1]):
 p0=defaultdict(int)
 for e,c in p.items():p0[e[:4]+e[5:9]]+=c
 p0={e:c for e,c in p0.items() if c}
 degree=max(map(sum,p0));norm=sum(map(abs,p0.values()))
 rows.append(dict(coordinate=name,degree=degree,weight=w,monomials=len(p0),norm=norm,weighted_degree_ratio=degree/w,log_constant=math.log2(norm)/w))
report={'normalized_leaf_polynomials':rows}
(root/'normalized_height_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
# Exact integer componentwise recurrence, including normalized leaf scales.
from decimal import Decimal,localcontext,ROUND_CEILING
norm_bits=lambda p:(sum(map(abs,p.values()))-1).bit_length()
def poly_bits(p,bits):
 return norm_bits(p)+max(sum(ei*bi for ei,bi in zip(e,bits)) for e in p)
params=[]
with localcontext() as ctx:
 ctx.prec=70
 ln2=Decimal(2).ln()
 for n,w,L in [(127,8,64),(127,16,32),(127,24,32),(127,32,16)]:
  h=L.bit_length()-1
  bits=[n,n,n,n,0];history=[bits]
  for j in range(1,h):
   bits=[poly_bits(p,bits*2) for p in ns['out']];history.append(bits)
  hn,hd=poly_bits(ns['N'],bits*2),poly_bits(ns['D'],bits*2)
  H=max(hn,n+hd)+1
  candidates=[]
  for b in range(22,35):
   x=Decimal(2)**b
   lower=x/ln2*(1-Decimal('.2')/(b*ln2)**2)-1-n
   if lower>H+2:
    k=int((x/(b*ln2-Decimal('1.1'))).to_integral_value(rounding=ROUND_CEILING))
    lk=(k-1).bit_length();af=2*lk+4
    peak=500+n+af+(5*(h+2)+11)*b+4
    candidates.append({'b':b,'K':k,'a_fp':af,'reconstruction_peak':peak,'margin':str(lower-H-2)})
  params.append({'window':w,'leaves':L,'height':h,'coordinate_bit_history':history,'N_bits':hn,'D_bits':hd,'H':H,'best':candidates[0]})
report['componentwise_height_parameters']=params
(root/'normalized_height_results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(params,indent=2))
