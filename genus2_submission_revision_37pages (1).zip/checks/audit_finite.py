#!/usr/bin/env python3
"""Independent small-prime Cantor/compact comparison, standard library only.

Exhausts input pairs for q=5,7 and samples 2000 pairs for q=11,13.
This is a finite check, not a general proof of group-law correctness.
"""
import json
from pathlib import Path
from itertools import product
import random
random.seed(23419)
p=5

def tr(a):
 a=[x%p for x in a]
 while a and a[-1]==0:a.pop()
 return a

def add(a,b):return tr([(a[i] if i<len(a) else 0)+(b[i] if i<len(b) else 0) for i in range(max(len(a),len(b)))])
def neg(a):return tr([-x for x in a])
def sub(a,b):return add(a,neg(b))
def mul(a,b):
 c=[0]*(len(a)+len(b)-1) if a and b else []
 for i,x in enumerate(a):
  for j,y in enumerate(b):c[i+j]+=x*y
 return tr(c)
def sc(a,c):return tr([x*c for x in a])
def div(a,b):
 a=tr(a);b=tr(b);assert b
 q=[0]*max(0,len(a)-len(b)+1);inv=pow(b[-1],-1,p)
 while len(a)>=len(b):
  d=len(a)-len(b);c=a[-1]*inv%p;q[d]=c
  a=sub(a,[0]*d+sc(b,c))
 return tr(q),a
def exdiv(a,b):
 q,r=div(a,b);assert not r,(a,b,r);return q
def monic(a):return sc(a,pow(a[-1],-1,p))
def xgcd(a,b):
 a=tr(a);b=tr(b)
 oa,ob=[1],[];na,nb=[],[1]
 while b:
  q,r=div(a,b);a,b=b,r;oa,na=na,sub(oa,mul(q,na));ob,nb=nb,sub(ob,mul(q,nb))
 z=pow(a[-1],-1,p);return sc(a,z),sc(oa,z),sc(ob,z)
def cantor(x,y,f):
 u1,v1=x;u2,v2=y;g,e1,e2=xgcd(u1,u2);d,c1,c2=xgcd(g,add(v1,v2))
 s1=mul(c1,e1);s2=mul(c1,e2)
 un=exdiv(mul(u1,u2),mul(d,d))
 vn=div(exdiv(add(add(mul(mul(s1,u1),v2),mul(mul(s2,u2),v1)),mul(c2,add(mul(v1,v2),f))),d),un)[1]
 if len(un)>3:un=monic(exdiv(sub(f,mul(vn,vn)),un));vn=div(neg(vn),un)[1]
 assert len(un)<=3 and len(vn)<len(un) and not div(sub(f,mul(vn,vn)),un)[1]
 return un,vn

def coords(x,z):
 uu,vv=x;return (uu[1]*z*z%p,uu[0]*z*z%p,(vv[1] if len(vv)>1 else 0)*z**3%p,(vv[0] if vv else 0)*z**3%p,z)
def compact(x,y):
 a,c,s,u,z=x;b,d,t,v,w=y;K=z*w
 du0=d*z*z-c*w*w;du1=b*z*z-a*w*w;dv0=v*z**3-u*w**3;dv1=t*z**3-s*w**3;su1=b*z*z+a*w*w
 cc=a*d-c*b;R=du0**2-cc*du1;E=dv1*du0-dv0*du1;L=du0*dv0-cc*dv1
 if K*R*E%p==0:return None
 N=K*K*L*L+2*a*w*w*L*E+(a*b-du0)*E*E-2*s*w**3*R*E+su1*K*K*R*R
 D=K*K*E*E;A=2*K*K*L*E+su1*E*E-K**4*R*R;T=L*E-K*K*R*R
 B1=s*w**3*R-a*w*w*L-(a*b+c*w*w)*E;B0=u*w**3*R-c*w*w*L-c*b*E
 out=[A*R*R,N*R*R,R*R*(A*T-E*E*(B1*E+N)),R*R*(N*T-B0*E**3),K*R*E]
 zi=pow(out[-1]%p,-1,p);dec=(tr([out[1]*zi**2,out[0]*zi**2,1]),tr([out[3]*zi**3,out[2]*zi**3]))
 assert dec[0][0]==N*pow(D%p,-1,p)%p
 return dec

reports=[]
for p in [5,7,11,13]:
 f=[1,1,0,0,0,1];der=[i*f[i] for i in range(1,6)]
 while len(xgcd(f,der)[0])!=1:f[0]+=1
 pairs=[([1],[])]
 for degree in [1,2]:
  for uc in product(range(p),repeat=degree):
   uu=list(uc)+[1]
   for vc in product(range(p),repeat=degree):
    vv=tr(vc)
    if not div(sub(f,mul(vv,vv)),uu)[1]:pairs.append((uu,vv))
 if p<10: cases=product(pairs,repeat=2)
 else:cases=[(random.choice(pairs),random.choice(pairs)) for _ in range(2000)]
 total=gen=0
 for xx,yy in cases:
  zz=cantor(xx,yy,f);total+=1
  if len(xx[0])==3 and len(yy[0])==3:
   out=compact(coords(xx,random.randrange(1,p)),coords(yy,random.randrange(1,p)))
   if out:
    gen+=1;assert out==zz,(p,xx,yy,out,zz)
 print('p',p,'Jac reduced classes',len(pairs),'Cantor outputs membership-checked',total,'generic compact equals Cantor',gen,flush=True)

 reports.append({"prime":p,"curve_coefficients_ascending":f,"reduced_divisor_count":len(pairs),"input_pairs_checked":total,"all_pairs_exhausted":p<10,"generic_compact_pairs_compared":gen,"failures":0})
Path(__file__).with_name("audit_finite_results.json").write_text(json.dumps({"random_seed":23419,"scope":"Independent complete Cantor output validity and compact generic-branch comparison with random nonzero weighted input scales", "tests":reports},indent=2)+"\n")
