#!/usr/bin/env python3
"""Compile with the supplied LLNCS class; require 27 body + 2 reference pages and at most 40 total."""
from pathlib import Path
import json
import re
import shutil
import subprocess
import tempfile

import fitz

root=Path(__file__).resolve().parent
with tempfile.TemporaryDirectory(prefix='genus2-llncs-enriched-') as temporary:
    work=Path(temporary)
    for name in ['manuscript.tex','llncs.cls']:
        shutil.copy2(root/name,work/name)
    for _ in range(3):
        result=subprocess.run(
            ['pdflatex','-interaction=nonstopmode','-halt-on-error','manuscript.tex'],
            cwd=work,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
        if result.returncode:
            print(result.stdout[-6000:])
            raise SystemExit(result.returncode)
    log=(work/'manuscript.log').read_text()
    aux=(work/'manuscript.aux').read_text()
    for problem in ['There were undefined references','There were multiply-defined labels',
                    'Overfull','destination with the same identifier']:
        if problem in log:
            print('\n'.join(line for line in log.splitlines() if problem in line))
            raise SystemExit('Compilation check failed: '+problem)
    def page(label):
        result=re.search(r'\\newlabel\{'+re.escape(label)+r'\}\{\{[^}]*\}\{(\d+)\}',aux)
        if not result:
            raise SystemExit('Missing page label: '+label)
        return int(result.group(1))
    body_end=page('page:last-body')
    article_end=page('page:last-main')
    if body_end!=27 or article_end!=29:
        raise SystemExit(f'Expected 27 body pages and 29 pages including references; '
                         f'found {body_end} and {article_end}.')
    source=work/'manuscript.pdf'
    if not source.read_bytes().rstrip().endswith(b'%%EOF'):
        raise SystemExit('Incomplete PDF')
    full=fitz.open(source)
    if len(full)>40:
        raise SystemExit(f'Complete document exceeds 40 pages: {len(full)}')
    article=fitz.open()
    article.insert_pdf(full,from_page=0,to_page=article_end-1,links=True)
    article.set_toc([item for item in full.get_toc() if 0<item[2]<=article_end])
    article.set_metadata({'title':'Low-Space Quantum Discrete Logarithms on Genus-Two Jacobians',
                          'author':'Yan Huang, Yulin Chen, Fangguo Zhang'})
    article.save(work/'article_with_references.pdf',garbage=3,deflate=True)
    article.close()
    count=dict(body_pages=body_end,reference_pages=article_end-body_end,
               article_and_references_pages=article_end,limit_including_references=29,
               appendices_start_page=article_end+1,appendix_pages=len(full)-article_end,
               complete_document_pages=len(full),complete_document_limit=40,class_version='LLNCS v2.13, supplied by the user',
               paper_size_points=list(full[0].rect)[2:])
    full.close()
    (work/'page_count.json').write_text(json.dumps(count,indent=2)+'\n')
    for name in ['manuscript.pdf','manuscript.aux','manuscript.log','manuscript.out',
                 'article_with_references.pdf','page_count.json']:
        staged=root/(name+'.tmp')
        shutil.copy2(work/name,staged)
        staged.replace(root/name)
print(json.dumps(count,indent=2))
