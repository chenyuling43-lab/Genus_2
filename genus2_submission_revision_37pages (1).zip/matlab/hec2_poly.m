function varargout = hec2_poly(operation, p, varargin)
%HEC2_POLY Exact polynomial helpers over F_p, ascending coefficients.
% Internal helper: callers validate p and integer data. Zero is sym([]).
    switch operation
        case 'trim'
            varargout{1} = trim(varargin{1}, p);
        case 'add'
            varargout{1} = add(varargin{1}, varargin{2}, p);
        case 'sub'
            varargout{1} = add(varargin{1}, -varargin{2}, p);
        case 'mul'
            varargout{1} = mul(varargin{1}, varargin{2}, p);
        case 'div'
            [varargout{1}, varargout{2}] = divide(varargin{1}, varargin{2}, p);
        case 'rem'
            [~, varargout{1}] = divide(varargin{1}, varargin{2}, p);
        case 'exactdiv'
            [q, r] = divide(varargin{1}, varargin{2}, p);
            if ~isempty(r)
                error('hec2:NonExactDivision', 'Polynomial division has nonzero remainder.');
            end
            varargout{1} = q;
        case 'monic'
            a = trim(varargin{1}, p);
            if isempty(a)
                error('hec2:ZeroPolynomial', 'Cannot make the zero polynomial monic.');
            end
            varargout{1} = trim(a * inverse(a(end), p), p);
        case 'xgcd'
            [varargout{1}, varargout{2}, varargout{3}] = xgcd(varargin{1}, varargin{2}, p);
        otherwise
            error('hec2:PolynomialOperation', 'Unknown polynomial operation.');
    end
end

function a = trim(a, p)
    a = mod(sym(a(:).'), p);
    while ~isempty(a) && isequal(a(end), sym(0))
        a(end) = [];
    end
end

function c = add(a, b, p)
    c = sym(zeros(1, max(numel(a), numel(b))));
    c(1:numel(a)) = a;
    c(1:numel(b)) = c(1:numel(b)) + b;
    c = trim(c, p);
end

function c = mul(a, b, p)
    if isempty(a) || isempty(b)
        c = sym([]);
        return;
    end
    c = sym(zeros(1, numel(a) + numel(b) - 1));
    for i = 1:numel(a)
        for j = 1:numel(b)
            c(i+j-1) = mod(c(i+j-1) + a(i)*b(j), p);
        end
    end
    c = trim(c, p);
end

function [q, r] = divide(a, b, p)
    r = trim(a, p);
    b = trim(b, p);
    if isempty(b)
        error('hec2:ZeroPolynomial', 'Cannot divide by the zero polynomial.');
    end
    q = sym(zeros(1, max(0, numel(r)-numel(b)+1)));
    leadingInverse = inverse(b(end), p);
    while ~isempty(r) && numel(r) >= numel(b)
        degree = numel(r) - numel(b);
        coefficient = mod(r(end)*leadingInverse, p);
        q(degree+1) = coefficient;
        r = add(r, -[sym(zeros(1, degree)), coefficient*b], p);
    end
    q = trim(q, p);
end

function [g, s, t] = xgcd(a, b, p)
    a = trim(a, p); b = trim(b, p);
    s = sym(1); t = sym([]);
    nextS = sym([]); nextT = sym(1);
    while ~isempty(b)
        [q, r] = divide(a, b, p);
        a = b; b = r;
        temp = add(s, -mul(q, nextS, p), p);
        s = nextS; nextS = temp;
        temp = add(t, -mul(q, nextT, p), p);
        t = nextT; nextT = temp;
    end
    if isempty(a)
        error('hec2:ZeroPolynomial', 'gcd(0,0) is not supported.');
    end
    scale = inverse(a(end), p);
    g = trim(a*scale, p);
    s = trim(s*scale, p);
    t = trim(t*scale, p);
end

function result = inverse(a, p)
    oldR = p; r = mod(a, p);
    oldS = sym(0); s = sym(1);
    while ~isequal(r, sym(0))
        quotient = floor(oldR/r);
        temp = oldR - quotient*r; oldR = r; r = temp;
        temp = oldS - quotient*s; oldS = s; s = temp;
    end
    if ~isequal(oldR, sym(1))
        error('hec2:NotInvertible', 'Coefficient is not invertible modulo p.');
    end
    result = mod(oldS, p);
end
