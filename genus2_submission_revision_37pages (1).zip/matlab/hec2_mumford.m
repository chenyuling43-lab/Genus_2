function D = hec2_mumford(input, p, f)
%HEC2_MUMFORD Validate a reduced divisor and normalize its representation.
% Internal helper: p and f must already have been checked.
% input: projective [U1 U0 V1 V0 Z], or struct('u',u,'v',v).
% u and v use ASCENDING coefficients; identity: u=1, v=[].
    if isstruct(input)
        if ~isscalar(input) || ~isfield(input, 'u') || ~isfield(input, 'v')
            error('hec2:InvalidDivisor', 'Use a scalar struct with fields u and v.');
        end
        u = hec2_exact_integers(input.u, 'u');
        v = hec2_exact_integers(input.v, 'v');
        if ~isvector(u) || (~isempty(v) && ~isvector(v))
            error('hec2:InvalidDivisor', 'u and v must be coefficient vectors.');
        end
        u = hec2_poly('trim', p, u);
        v = hec2_poly('trim', p, v);
    else
        affine = hec2_projective_recover(input, p);
        u = [affine(2), affine(1), sym(1)];
        v = hec2_poly('trim', p, [affine(4), affine(3)]);
    end
    if isempty(u) || numel(u) > 3 || ~isequal(u(end), sym(1)) ...
            || numel(v) >= numel(u)
        error('hec2:InvalidDivisor', ...
            'Require monic u, 0 <= degree(u) <= 2, and degree(v) < degree(u).');
    end
    remainder = hec2_poly('rem', p, ...
        hec2_poly('sub', p, f, hec2_poly('mul', p, v, v)), u);
    if ~isempty(remainder)
        error('hec2:DivisorNotOnCurve', 'Divisor must satisfy u | (f-v^2).');
    end
    D = struct('u', u, 'v', v, 'degree', numel(u)-1, ...
        'is_identity', numel(u) == 1, 'projective', sym([]));
    if D.degree == 2
        paddedV = sym([0, 0]);
        paddedV(1:numel(v)) = v;
        D.projective = [u(2), u(1), paddedV(2), paddedV(1), sym(1)];
    end
end
