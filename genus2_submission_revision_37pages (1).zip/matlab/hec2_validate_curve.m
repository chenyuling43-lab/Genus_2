function [curve, f] = hec2_validate_curve(curve, p)
%HEC2_VALIDATE_CURVE Check the normalized smooth model y^2=f(x).
% p must already have passed hec2_validate_prime.
    curve = hec2_exact_integers(curve, 'curve');
    if ~isvector(curve) || numel(curve) ~= 4
        error('hec2:InvalidCurve', 'curve must be [c0 c1 c2 c3].');
    end
    curve = mod(curve(:).', p);
    f = [curve, sym(0), sym(1)];
    derivative = mod(f(2:end) .* sym(1:5), p);
    [g, ~, ~] = hec2_poly('xgcd', p, f, derivative);
    if numel(g) ~= 1
        error('hec2:SingularCurve', 'f must be squarefree modulo p.');
    end
end
