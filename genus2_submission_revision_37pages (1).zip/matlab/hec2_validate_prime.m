function p = hec2_validate_prime(p)
%HEC2_VALIDATE_PRIME Validate an exact odd prime using Symbolic Math Toolbox.
% Cache only a successfully checked value; never convert large p to double.
    p = hec2_exact_integers(p, 'p');
    if ~isscalar(p) || ~isAlways(p > 2) || ~isAlways(mod(p, 2) == 1)
        error('hec2:InvalidModulus', 'p must be an odd prime scalar.');
    end
    persistent lastPrime
    if isempty(lastPrime) || ~isequal(p, lastPrime)
        if ~isprime(p)
            error('hec2:InvalidModulus', 'p must be prime, not composite.');
        end
        lastPrime = p;
    end
end
