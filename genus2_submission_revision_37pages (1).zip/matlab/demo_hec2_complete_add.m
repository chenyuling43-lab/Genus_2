function demo_hec2_complete_add()
%DEMO_HEC2_COMPLETE_ADD Generic addition, doubling, inverse and identity.
    p = sym(101);
    curve = sym([3 5 7 11]);
    D = sym([57 11 53 60 2]);
    L = sym([49 42 94 99 3]);
    O = struct('u', sym(1), 'v', sym([]));
    minusD = D; minusD(3:4) = mod(-D(3:4), p);
    [sumDL, sumInfo] = hec2_add(D, L, p, curve);
    [twiceD, doubleInfo] = hec2_add(D, D, p, curve);
    inverseSum = hec2_add(D, minusD, p, curve);
    identitySum = hec2_add(D, O, p, curve);
    assert(inverseSum.is_identity);
    disp('D+L (ascending u,v coefficients):'); disp(sumDL);
    disp(['Branch: ', sumInfo.branch]);
    disp('2D:'); disp(twiceD);
    disp(['Branch: ', doubleInfo.branch]);
    disp('D+(-D):'); disp(inverseSum);
    disp('D+O:'); disp(identitySum);
end
