# Genus-two classical reference arithmetic

Requires MATLAB with Symbolic Math Toolbox. Keep all MATLAB files and
`regression_fixtures.json` in this directory together.

## Quick start

Run in MATLAB from this directory:

```matlab
demo_hec2_projective_add  % original generic example, unchanged
demo_hec2_complete_add   % generic sum, doubling, inverse, identity
report = run_hec2_tests  % calls the actual .m implementations
```

The native tests have been supplied but have NOT been run in the preparation
environment, which has neither MATLAB nor Octave. The Python checks and
MATLAB syntax checks are not a substitute for this native test run.
Successful native execution writes `matlab_native_results.mat`; no purported
native-pass result is shipped. A failed run can leave an older result file,
so use the current invocation's output to judge success.

## General addition, including special cases

```matlab
p = sym(101);
curve = sym([3 5 7 11]);  % y^2=x^5+c3*x^3+c2*x^2+c1*x+c0
D = sym([57 11 53 60 2]);
L = sym([49 42 94 99 3]);
[R,info] = hec2_add(D,L,p,curve);
[twiceD,info2] = hec2_add(D,D,p,curve);
O = struct('u',sym(1),'v',sym([]));
sameD = hec2_add(D,O,p,curve);
```

`hec2_add` accepts either a five-coordinate weighted-projective vector or a
scalar struct with fields `u` and `v`. Polynomial coefficients are in
**ascending order**, e.g. `u=[94 56 1]` means `x^2+56*x+94`.

The result is ALWAYS a struct with:

| Field | Meaning |
| --- | --- |
| `u`, `v` | Reduced monic Mumford pair, ascending coefficients |
| `degree` | Degree of u: 0, 1 or 2 |
| `is_identity` | True exactly for u=1, v=0 |
| `projective` | Five-vector for degree two; empty for degree zero or one |

Do not use an all-zero vector or `Z=0` to encode the identity. The old
five-vector chart assumes a monic quadratic u and cannot represent all
lower-degree divisors. Struct results can be supplied to subsequent calls.

The generic formulas are tried for two degree-two inputs. H=0, B3=0,
the a0 zero-denominator condition, and a zero output chart trigger a classical
Cantor fallback. Degree-one inputs use Cantor directly; identity addition is
handled directly. Invalid input and unrelated programming errors are never
silently converted into fallback calls. `info.branch` and
`info.fallback_reason` identify the path taken. `hec2_cantor` can also be
called directly as an independent classical backend.

## Original generic interface

```matlab
[P,details] = hec2_projective_add(D,L,p,curve,'a4');
affine = hec2_projective_recover(P,p);
```

The original arithmetic expressions and default projective output
`[81 53 65 52 68]` are retained. The affine result is `[56 94 30 24]`.
`a0` and `a4` may choose different projective scales for the same divisor.

The old interface still returns a five-vector and deliberately reports an
identified error on exceptional inputs. Switch to `hec2_add` when those
inputs must be supported. The three-argument generic call is retained for
compatibility: it validates integer data and the modulus but cannot check
curve membership without a curve. Its `details.curve_membership_checked`
is false. Supplying the full curve enables smoothness and membership checks.

## Validation and exactness

- Check a concrete odd prime modulus with the symbolic `isprime` routine.
- Reject nonintegers, complex/nonfinite data, and symbolic variables.
- Reject unsafe single/double magnitudes at or beyond their `flintmax`.
- Require the four normalized curve coefficients and squarefree f.
- Require nonzero input scales for projective data.
- Require reduced monic u of degree at most two, degree(v)<degree(u), and
  u dividing f-v^2 for Mumford data. Valid repeated-root u is NOT rejected.

Construct large values as `sym('170141183460469231731687303715884105727')`
or `sym(2)^127-1`, not `sym(2^127-1)`. No validator can recover information
already lost before a sym object was created. See the
[MathWorks sym documentation](https://www.mathworks.com/help/symbolic/sym.html).

## Tests and scope

`run_hec2_tests.m` uses 75 independent Python-generated fixtures over six
prime fields, directly exercising the MATLAB generic and Cantor routines,
two recovery routes, projective scaling, doubling, inverse, shared support,
degree-one results, and identities. It also includes 21 expected-error tests
and a 127-bit exact affine-recovery test. Regenerate fixtures deliberately
with `python3 checks/check_matlab_extended.py --write-fixtures` from the
archive root; without that flag the checker verifies the existing fixtures.

The addition formulas remain inversion-free. Classical input validation,
affine output conversion, and Cantor arithmetic use modular inverses.
This wrapper/backend is NOT the optimized masked quantum sampler, is not
constant-time, and does not change or certify the manuscript's quantum
resource counts. The model remains the normalized odd-characteristic
genus-two curve above, not arbitrary hyperelliptic models.
