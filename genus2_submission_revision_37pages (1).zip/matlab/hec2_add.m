function [R, info] = hec2_add(D, L, p, curve, method)
%HEC2_ADD Validated general classical genus-two divisor addition.
% [R,info] = hec2_add(D,L,p,curve[,method]); method is a4 (default) or a0.
% Inputs: weighted-projective five-vectors OR structs with ascending u,v.
% Output ALWAYS a struct: u, v, degree, is_identity, projective.
% R.projective is present only for degree two; otherwise it is sym([]).
% Identity input: struct('u',sym(1),'v',sym([])). Z=0 is NOT an identity code.
% Generic formulas are tried first for two degree-two inputs. Only explicitly
% identified generic-branch exceptions trigger the classical Cantor fallback.
    if nargin < 4
        error('hec2:MissingInputs', 'Call hec2_add(D,L,p,curve[,method]).');
    end
    if nargin < 5 || isempty(method)
        method = 'a4';
    end
    if isstring(method) && isscalar(method)
        method = char(method);
    end
    if ~ischar(method) || ~isrow(method) || ~any(strcmpi(method, {'a4','a0'}))
        error('hec2:InvalidMethod', 'method must be a4 or a0.');
    end
    method = lower(method);
    p = hec2_validate_prime(p);
    [curve, f] = hec2_validate_curve(curve, p);
    X = hec2_mumford(D, p, f);
    Y = hec2_mumford(L, p, f);
    info = struct('branch', '', 'fallback_reason', '', 'generic_info', []);
    if X.is_identity
        R = Y; info.branch = 'identity'; return;
    elseif Y.is_identity
        R = X; info.branch = 'identity'; return;
    end
    if X.degree == 2 && Y.degree == 2
        if isstruct(D), D = X.projective; end
        if isstruct(L), L = Y.projective; end
        try
            % Membership has already been checked above. Preserve input scales.
            [P, details] = hec2_projective_add(D, L, p, curve, method);
            R = hec2_mumford(P, p, f);
            R.projective = P;
            info.branch = 'generic'; info.generic_info = details;
            return;
        catch exception
            allowed = {'hec2:GenericHZero', 'hec2:GenericB3Zero', ...
                'hec2:GenericA0Zero', 'hec2:GenericOutputChart'};
            if ~any(strcmp(exception.identifier, allowed))
                rethrow(exception);
            end
            info.fallback_reason = exception.identifier;
        end
    else
        info.fallback_reason = 'lower_degree_input';
    end
    R = hec2_cantor(X, Y, p, curve);
    info.branch = 'cantor';
end
