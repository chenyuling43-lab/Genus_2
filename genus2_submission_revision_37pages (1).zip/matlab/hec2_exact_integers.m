function value = hec2_exact_integers(value, name)
%HEC2_EXACT_INTEGERS Require concrete, finite, real integer data.
% Large integers must arrive as sym values or integer-class arrays, never
% through a rounded single/double. Empty vectors are allowed for v=0.
    if nargin < 2
        name = 'input';
    end
    if ~(isnumeric(value) || isa(value, 'sym'))
        error('hec2:IntegerInput', '%s must be numeric or symbolic integers.', name);
    end
    if isfloat(value)
        if ~isreal(value) || any(~isfinite(value(:))) ...
                || any(value(:) ~= fix(value(:)))
            error('hec2:IntegerInput', '%s must contain finite real integers.', name);
        end
        % Reject the boundary too: flintmax+1 may already have rounded to it.
        if any(abs(value(:)) >= flintmax(class(value)))
            error('hec2:InexactInput', ...
                '%s is too large for safe floating-point input; use sym(''integer'').', name);
        end
    end
    value = sym(value);
    if ~isempty(symvar(value))
        error('hec2:IntegerInput', '%s must not contain symbolic variables.', name);
    end
    for k = 1:numel(value)
        if ~isAlways(imag(value(k)) == 0) ...
                || ~isAlways(abs(value(k)) < sym(inf)) ...
                || ~isAlways(value(k) == floor(value(k)))
            error('hec2:IntegerInput', '%s must contain finite real integers.', name);
        end
    end
end
