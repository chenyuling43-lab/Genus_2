function [R, info] = hec2_projective_add(D, L, p, curve, rMethod)
%HEC2_PROJECTIVE_ADD  Generic genus-2 divisor addition in weighted-projective coordinates.
%
% Coordinates:
%   D = (U1_1 : U0_1 : V1_1 : V0_1 : Z_1)
%   L = (U1_2 : U0_2 : V1_2 : V0_2 : Z_2)
%
% The suffix _i identifies the i-th divisor; it is not an exponent.
% Here i=1,2 denotes the two inputs and i=3 denotes the output.
% The sum R = D+L is encoded as [U1_3 U0_3 V1_3 V0_3 Z_3].
% Affine recovery over F_p uses the weighted-projective decoding:
%   u1 = U1 / Z^2, u0 = U0 / Z^2
%   v1 = V1 / Z^3, v0 = V0 / Z^3
% Internal aliases in the derivation: q=u1, r=u0, s=v1, t=v0.
% All quotients here mean modular division, not real division.
% With curve supplied, smoothness and divisor membership are checked first.
% With curve omitted, membership is still the caller's responsibility.
% This remains a generic addition branch; use hec2_add for special cases.
%
% The underlying curve is the normalized genus-2 model
%   y^2 = x^5 + c3*x^3 + c2*x^2 + c1*x + c0.
%
% This routine follows a direct projective derivation:
%   (1) ell - v_D == 0 mod u_D and ell - v_L == 0 mod u_L
%   (2) Phi^2 - Lambda^2*h = B3^2*u_D*u_L*u_3
%   (3) v_3 == -ell mod u_3
%
% No modular inversion is used in the main addition formulas. The optional
% classical curve-membership validation uses affine recovery and inverses.
%
% INPUTS
%   D, L    : 1x5 vectors [U1 U0 V1 V0 Z]
%   p       : odd prime modulus
%   curve   : optional [c0 c1 c2 c3].
%             Required for 'a0'; also enables input validation for 'a4'.
%   rMethod : optional:
%             'a4' (default) -- recover r3 from the x^4 coefficient.
%                               This avoids division by r0*r1 and does not
%                               explicitly use curve coefficients because the
%                               normalized curve has zero x^4 coefficient.
%             'a0'           -- recover r3 from the constant coefficient,
%                               an alternative constant-coefficient recovery route;
%                               requires c0 and assumes U0_1*U0_2 ~= 0.
%
% OUTPUTS
%   R       : 1x5 weighted-projective output [U1 U0 V1 V0 Z]
%   info    : struct containing all intermediate variables.
%
% IMPORTANT
%   This is the generic branch. It does NOT handle H=0, B3=0, Z_1=0, Z_2=0,
%   doubling/special intersections, the unit divisor, or degenerate divisors.
%
% For cryptographic-size p, use Symbolic Math Toolbox. Inputs are converted
% to sym so products remain exact.

    if nargin < 3
        error('hec2_projective_add:MissingInputs', ...
              ['Run demo_hec2_projective_add, or call ', ...
               '[R,info] = hec2_projective_add(D,L,p,curve,''a4'').']);
    end

    if nargin < 4
        curve = [];
    end
    if nargin < 5 || isempty(rMethod)
        rMethod = 'a4';
    end

    p = hec2_validate_prime(p);
    D = hec2_exact_integers(D, 'D');
    L = hec2_exact_integers(L, 'L');
    if ~isvector(D) || ~isvector(L) || numel(D) ~= 5 || numel(L) ~= 5
        error('hec2:InvalidCoordinates', ...
            'D and L must each be a five-coordinate vector [U1 U0 V1 V0 Z].');
    end
    D = mod(D(:).', p);
    L = mod(L(:).', p);
    if isstring(rMethod) && isscalar(rMethod)
        rMethod = char(rMethod);
    end
    if ~ischar(rMethod) || ~isrow(rMethod) ...
            || ~any(strcmpi(rMethod, {'a4','a0'}))
        error('hec2:InvalidMethod', 'rMethod must be a4 or a0.');
    end
    rMethod = lower(rMethod);
    if isempty(curve) && strcmp(rMethod, 'a0')
        error('hec2:InvalidCurve', 'a0 requires curve=[c0 c1 c2 c3].');
    end
    if ~isempty(curve)
        [curve, f] = hec2_validate_curve(curve, p);
        hec2_mumford(D, p, f);
        hec2_mumford(L, p, f);
    end

    m = @(x) mod(x, p);

    U1_1 = D(1); U0_1 = D(2); V1_1 = D(3); V0_1 = D(4); Z_1 = D(5);
    U1_2 = L(1); U0_2 = L(2); V1_2 = L(3); V0_2 = L(4); Z_2 = L(5);

    if isequal(m(Z_1), sym(0)) || isequal(m(Z_2), sym(0))
        error('hec2:ZeroScale', 'Require nonzero Z_1 and Z_2; Z=0 does not encode the identity.');
    end

    %% ---------------------------------------------------------------
    % Step 1. Cross-scaled sums/differences.
    %
    % A = Z_1^2 Z_2^2
    % qL-qD = dU1/A, qL+qD = sU1/A
    % rL-rD = dU0/A, rL+rD = sU0/A
    % sL-sD = dV1/(Z_1^3 Z_2^3)
    % tL-tD = dV0/(Z_1^3 Z_2^3)
    %% ---------------------------------------------------------------

    Z_1_sq = m(Z_1^2);
    Z_2_sq = m(Z_2^2);
    Z_1_cu = m(Z_1_sq * Z_1);
    Z_2_cu = m(Z_2_sq * Z_2);
    Z_1_four = m(Z_1_sq^2);

    A = m(Z_1_sq * Z_2_sq);

    dU1 = m(U1_2 * Z_1_sq - U1_1 * Z_2_sq);
    sU1 = m(U1_2 * Z_1_sq + U1_1 * Z_2_sq);

    dU0 = m(U0_2 * Z_1_sq - U0_1 * Z_2_sq);
    sU0 = m(U0_2 * Z_1_sq + U0_1 * Z_2_sq);

    dV1 = m(V1_2 * Z_1_cu - V1_1 * Z_2_cu);
    dV0 = m(V0_2 * Z_1_cu - V0_1 * Z_2_cu);

    %% ---------------------------------------------------------------
    % Step 2. Solve directly for the cubic interpolation coefficients.
    %
    % Let ell(x) = Phi(x)/Lambda, where
    % Phi = B3*x^3 + B2*x^2 + B1*x + B0.
    %
    % From ell-v == 0 mod u for D and L, eliminate B0 and B1.
    %% ---------------------------------------------------------------

    E = m(sU1 * dU1 - A * dU0);
    G = m(sU1 * dU0 + dU1 * sU0);

    % Determinant factor of the 2x2 system.
    H = m((sU1 * dU1 - 2 * A * dU0) * dU0 ...
          - (dU1^2) * sU0);

    if isequal(H, sym(0))
        error('hec2:GenericHZero', ['Exceptional case: H = 0 mod p. ', ...
               'Use hec2_add(D,L,p,curve) for the Cantor fallback.']);
    end

    K = m(Z_1 * Z_2);

    % Numerators for b2 and b3 after clearing all projective denominators.
    C2 = m(dV1 * G - 2 * dV0 * E);
    C3 = m(2 * (K^2) * (dV1 * dU0 - dV0 * dU1));

    % Common denominator before the final Z_1^4 rescaling.
    W = m(K * H);

    % Choose a scale that lets B0 and B1 be formed without inversion.
    Lambda = m(W * Z_1_four);

    B2 = m(C2 * Z_1_four);
    B3 = m(C3 * Z_1_four);

    if isequal(B3, sym(0))
        error('hec2:GenericB3Zero', ['Exceptional case: B3 = 0 mod p. ', ...
               'Use hec2_add(D,L,p,curve) for the Cantor fallback.']);
    end

    % Multiply b1=v1+b2*u1-b3*(u1^2-u0) by Lambda=W*Z_1^4.
    % Substitute the first input coordinates and b2=C2/W, b3=C3/W.
    % The following expressions are B1=Lambda*b1 and B0=Lambda*b0.
    B1 = m(V1_1 * W * Z_1 ...
         + C2 * U1_1 * Z_1_sq ...
         - C3 * (U1_1^2 - U0_1 * Z_1_sq));

    B0 = m(V0_1 * W * Z_1 ...
         + C2 * U0_1 * Z_1_sq ...
         - C3 * U1_1 * U0_1);

    %% ---------------------------------------------------------------
    % Step 3. Recover the new u_3(x)=x^2+q3*x+r3 from
    %
    %   Psi = Phi^2 - Lambda^2*h
    %       = B3^2 * u_D * u_L * u_3.
    %
    % x^5 coefficient gives q3.
    %% ---------------------------------------------------------------

    A5 = m(2 * B2 * B3 - Lambda^2);

    Nq = m(A * A5 - (B3^2) * sU1);
    Dq = m(A * (B3^2));

    % Thus q3 = Nq/Dq in the affine chart, but we do not invert Dq.

    switch lower(rMethod)
        case 'a4'
            % x^4 coefficient of h is zero for
            % y^2 = x^5 + c3*x^3 + c2*x^2 + c1*x + c0.
            %
            % A4/B3^2 =
            % rD+rL+qD*qL + (qD+qL)q3 + r3.
            A4 = m(B2^2 + 2 * B1 * B3);

            Nr = m(A^2 * A4 ...
                 - A * (B3^2) * (sU0 + U1_1 * U1_2) ...
                 - sU1 * Nq);
            Dr = m(A^2 * (B3^2));

        case 'a0'
            if isempty(curve) || numel(curve) < 1
                error('rMethod=''a0'' requires curve=[c0 c1 c2 c3].');
            end
            curve = mod(sym(curve(:).'), p);
            c0 = curve(1);

            if isequal(m(U0_1 * U0_2), sym(0))
                error('hec2:GenericA0Zero', ['rMethod=''a0'' requires U0_1*U0_2 ~= 0 mod p. ', ...
                       'Use rMethod=''a4'' instead.']);
            end

            A0 = m(B0^2 - c0 * Lambda^2);
            Nr = m(A * A0);
            Dr = m((B3^2) * U0_1 * U0_2);

        otherwise
            error('Unknown rMethod. Use ''a4'' or ''a0''.');
    end

    % Thus r3 = Nr/Dr, again without inversion.

    %% ---------------------------------------------------------------
    % Step 4. Recover v_3 from v_3 == -ell mod u_3.
    %
    % s3 = -b1 + b2*q3 - b3*(q3^2-r3)
    % t3 = -b0 + b2*r3 - b3*q3*r3
    %
    % Keep everything as numerator/denominator pairs.
    %% ---------------------------------------------------------------

    Ns = m(-B1 * (Dq^2) * Dr ...
         + B2 * Nq * Dq * Dr ...
         - B3 * (Nq^2) * Dr ...
         + B3 * Nr * (Dq^2));

    Nt = m(-B0 * Dq * Dr ...
         + B2 * Nr * Dq ...
         - B3 * Nq * Nr);

    % Affinely:
    %   s3 = Ns / (Lambda*Dq^2*Dr)
    %   t3 = Nt / (Lambda*Dq*Dr)

    %% ---------------------------------------------------------------
    % Step 5. Choose one weighted-projective scale Z_3 so that
    %
    % q3 = U1_3/Z_3^2, r3 = U0_3/Z_3^2,
    % s3 = V1_3/Z_3^3, t3 = V0_3/Z_3^3.
    %% ---------------------------------------------------------------

    Z_3 = m(Lambda * Dq * Dr);

    if isequal(Z_3, sym(0))
        error('hec2:GenericOutputChart', ['The chosen output chart has Z_3 = 0 mod p. ', ...
               'This is outside the current generic branch.']);
    end

    Lambda2 = m(Lambda^2);
    Dq2 = m(Dq^2);
    Dr2 = m(Dr^2);

    U1_3 = m(Nq * Lambda2 * Dq * Dr2);
    U0_3 = m(Nr * Lambda2 * Dq2 * Dr);

    V1_3 = m(Ns * Lambda2 * Dq * Dr2);
    V0_3 = m(Nt * Lambda2 * Dq2 * Dr2);

    R = [U1_3, U0_3, V1_3, V0_3, Z_3];

    %% Return intermediate variables for inspection/debugging.
    info = struct();
    info.A = A;
    info.dU1 = dU1; info.sU1 = sU1;
    info.dU0 = dU0; info.sU0 = sU0;
    info.dV1 = dV1; info.dV0 = dV0;

    info.E = E; info.G = G; info.H = H;
    info.C2 = C2; info.C3 = C3;
    info.W = W;

    info.Lambda = Lambda;
    info.B0 = B0; info.B1 = B1; info.B2 = B2; info.B3 = B3;

    info.A5 = A5;
    info.Nq = Nq; info.Dq = Dq;

    if exist('A4','var')
        info.A4 = A4;
    end
    if exist('A0','var')
        info.A0 = A0;
    end

    info.Nr = Nr; info.Dr = Dr;
    info.Ns = Ns; info.Nt = Nt;
    info.rMethod = rMethod;
    info.curve_membership_checked = ~isempty(curve);
end
