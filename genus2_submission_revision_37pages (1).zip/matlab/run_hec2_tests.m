function report = run_hec2_tests()
%RUN_HEC2_TESTS Native regression tests calling the actual MATLAB files.
% Requires MATLAB with Symbolic Math Toolbox. Run from this directory.
% Results are saved only after all assertions pass. On failure no old result
% is overwritten. Printed pass status applies to this invocation only.
    here = fileparts(mfilename('fullpath'));
    fixture = jsondecode(fileread(fullfile(here, 'regression_fixtures.json')));
    p = sym(101); curve = sym([3 5 7 11]);
    D = sym([57 11 53 60 2]); L = sym([49 42 94 99 3]);
    [P, details] = hec2_projective_add(D, L, p, curve, 'a4');
    assert(isequal(P, sym([81 53 65 52 68])));
    assert(details.curve_membership_checked);
    assert(isequal(hec2_projective_recover(P, p), sym([56 94 30 24])));
    P0 = hec2_projective_add(D, L, p, curve, 'a0');
    assert(isequal(hec2_projective_recover(P0, p), hec2_projective_recover(P, p)));
    [raw, unchecked] = hec2_projective_add(D, L, p);
    assert(isequal(raw, P) && ~unchecked.curve_membership_checked);
    [R, info] = hec2_add(D, L, p, curve);
    assert(strcmp(info.branch, 'generic') && isequal(R.projective, P));
    nativeCalls = 4;
    branchCounts = struct('generic', 0, 'cantor', 0, 'identity', 0);
    for i = 1:numel(fixture.cases)
        row = fixture.cases(i);
        modulus = sym(row.p); coefficients = sym(row.curve(:).');
        X = input_divisor(row.left); Y = input_divisor(row.right);
        expected = input_divisor(row.expected);
        C = hec2_cantor(X, Y, modulus, coefficients);
        equal_divisors(C, expected, modulus);
        for method = {'a4', 'a0'}
            [actual, trace] = hec2_add(X, Y, modulus, coefficients, method{1});
            equal_divisors(actual, expected, modulus);
            branchCounts.(trace.branch) = branchCounts.(trace.branch) + 1;
            if strcmp(row.label, 'b3_zero')
                assert(strcmp(trace.fallback_reason, 'hec2:GenericB3Zero'));
            elseif strcmp(row.label, 'a0_zero') && strcmp(method{1}, 'a0')
                assert(strcmp(trace.fallback_reason, 'hec2:GenericA0Zero'));
            elseif strcmp(row.label, 'doubling') || strcmp(row.label, 'shared_support')
                assert(strcmp(trace.fallback_reason, 'hec2:GenericHZero'));
            end
            if actual.degree < 2
                assert(isempty(actual.projective));
            else
                [~, f] = hec2_validate_curve(coefficients, modulus);
                equal_divisors(hec2_mumford(actual.projective, modulus, f), actual, modulus);
            end
            nativeCalls = nativeCalls + 1;
        end
        if numel(X.u) == 3 && numel(Y.u) == 3
            scaledX = scaled_projective(X, sym(2), modulus);
            scaledY = scaled_projective(Y, modulus-1, modulus);
            actual = hec2_add(scaledX, scaledY, modulus, coefficients);
            equal_divisors(actual, expected, modulus);
            nativeCalls = nativeCalls + 1;
        end
        nativeCalls = nativeCalls + 1;
    end
    assert(all(structfun(@(x) x > 0, branchCounts)));
    bad = D; bad(3) = mod(bad(3)+1, p);
    must_error(@() hec2_add(bad, L, p, curve), 'hec2:DivisorNotOnCurve');
    must_error(@() hec2_projective_add(bad, L, p, curve), 'hec2:DivisorNotOnCurve');
    must_error(@() hec2_add(D, L, 9, curve), 'hec2:InvalidModulus');
    must_error(@() hec2_projective_recover(D, 4), 'hec2:InvalidModulus');
    must_error(@() hec2_add(D, L, sym(7)/2, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add(D, L, [3 5], curve), 'hec2:InvalidModulus');
    must_error(@() hec2_add(D, L, p, [1 2 3]), 'hec2:InvalidCurve');
    must_error(@() hec2_add(D, L, p, [0 0 0 0]), 'hec2:SingularCurve');
    must_error(@() hec2_add([1 2 3 4], L, p, curve), 'hec2:InvalidCoordinates');
    must_error(@() hec2_add([1 2 3 4 0], L, p, curve), 'hec2:ZeroScale');
    must_error(@() hec2_add([1 2 3 4 0.5], L, p, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add([1 2 3 4 NaN], L, p, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add([1 2 3 4 Inf], L, p, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add([1 2 3 4 1i], L, p, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add([1 2 3 4 flintmax], L, p, curve), 'hec2:InexactInput');
    must_error(@() hec2_add([D(1:4), sym('z')], L, p, curve), 'hec2:IntegerInput');
    must_error(@() hec2_add(D, L, p, curve, 'typo'), 'hec2:InvalidMethod');
    must_error(@() hec2_projective_add(D, L, p, [], 'a0'), 'hec2:InvalidCurve');
    must_error(@() hec2_projective_add(D, D, p, curve), 'hec2:GenericHZero');
    invalid = struct('u', sym([1 0 2]), 'v', sym([]));
    must_error(@() hec2_add(invalid, L, p, curve), 'hec2:InvalidDivisor');
    invalid = struct('u', sym([1 0 0 1]), 'v', sym([]));
    must_error(@() hec2_add(invalid, L, p, curve), 'hec2:InvalidDivisor');
    % Exact large modulus and large signed representatives, not doubles.
    largeP = sym(2)^127-1;
    exact = [largeP+3, 2*largeP+4, 5-largeP, sym(6), sym(1)];
    assert(isequal(hec2_projective_recover(exact, largeP), sym([3 4 5 6])));
    report = struct('status', 'passed', 'matlab_version', version, ...
        'symbolic_toolbox', ver('symbolic'), 'fixture_cases', numel(fixture.cases), ...
        'native_addition_calls', nativeCalls, 'branch_counts', branchCounts, ...
        'negative_tests', 21, 'large_integer_recovery', true);
    save(fullfile(here, 'matlab_native_results.mat'), 'report');
    disp(report);
    disp('All native MATLAB regression tests passed.');
end

function D = input_divisor(record)
    D = struct('u', sym(record.u(:).'), 'v', sym(record.v(:).'));
end

function equal_divisors(actual, expected, p)
    assert(isequal(hec2_poly('trim', p, actual.u), hec2_poly('trim', p, expected.u)));
    assert(isequal(hec2_poly('trim', p, actual.v), hec2_poly('trim', p, expected.v)));
end

function P = scaled_projective(D, z, p)
    v = sym([0 0]); v(1:numel(D.v)) = D.v;
    P = mod([D.u(2)*z^2, D.u(1)*z^2, v(2)*z^3, v(1)*z^3, z], p);
end

function must_error(action, identifier)
    try
        action();
    catch exception
        assert(strcmp(exception.identifier, identifier), ...
            'Expected %s but got %s: %s', identifier, exception.identifier, exception.message);
        return;
    end
    error('hec2:TestFailure', 'Expected error %s was not raised.', identifier);
end
