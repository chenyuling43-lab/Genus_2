function R = hec2_cantor(D, L, p, curve)
%HEC2_CANTOR Complete classical addition of reduced genus-two divisors.
% Uses modular inverses. NOT an inversion-free or reversible quantum circuit.
% Inputs/outputs follow hec2_add; coefficient vectors are ascending.
    p = hec2_validate_prime(p);
    [~, f] = hec2_validate_curve(curve, p);
    D = hec2_mumford(D, p, f);
    L = hec2_mumford(L, p, f);
    op = @(kind, a, b) hec2_poly(kind, p, a, b);
    [g, e1, e2] = hec2_poly('xgcd', p, D.u, L.u);
    [d, c1, c2] = hec2_poly('xgcd', p, g, op('add', D.v, L.v));
    s1 = op('mul', c1, e1);
    s2 = op('mul', c1, e2);
    u = op('exactdiv', op('mul', D.u, L.u), op('mul', d, d));
    numerator = op('add', ...
        op('add', op('mul', op('mul', s1, D.u), L.v), ...
                  op('mul', op('mul', s2, L.u), D.v)), ...
        op('mul', c2, op('add', op('mul', D.v, L.v), f)));
    v = op('rem', op('exactdiv', numerator, d), u);
    while numel(u) > 3
        oldDegree = numel(u)-1;
        u = hec2_poly('monic', p, ...
            op('exactdiv', op('sub', f, op('mul', v, v)), u));
        v = op('rem', -v, u);
        if numel(u)-1 >= oldDegree
            error('hec2:ReductionFailure', 'Cantor reduction did not lower the degree.');
        end
    end
    R = hec2_mumford(struct('u', u, 'v', v), p, f);
end
