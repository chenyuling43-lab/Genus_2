# 代码改进说明

本次在原提交包基础上增加输入校验、特殊情形的经典加法后备实现和
MATLAB 原生回归测试。没有改写一般加法核心公式，没有改动论文正文、
PDF、量子资源数值或原演示算例。

## 1. 哪些文件进行了修改

| 文件 | 改进内容 |
| --- | --- |
| `matlab/hec2_projective_add.m` | 增加整数、奇素数、输入形状、方法名校验；提供曲线时检查光滑性和除子归属；为特殊分支增加稳定错误标识；在 info 中报告是否检查了曲线归属 |
| `matlab/hec2_projective_recover.m` | 在模运算和求逆之前检查模数、坐标类型、向量长度和非零 Z |
| `checks/verify_local_evaluator.py` | 默认也写入旁边的 local_evaluator_results.json，避免全量检查只打印结果却保留旧文件 |
| `README.md`、`matlab/README.md` | 更新接口、完整目录依赖、运行方式和实际验证范围 |
| `artifact_manifest.json` | 更新文件列表、大小和 SHA-256 校验值 |

一般加法函数中的输入校验在 Step 1 之前。H=0、B3=0、a0 零分母及输出
Z=0 分支增加了错误标识，但相应数学判断没有改变。Step 1–5 中抽取的
46 条算术赋值与原文件一致。原 demo_hec2_projective_add.m 字节不变。

## 2. 新增文件及用途

| 文件 | 用途 |
| --- | --- |
| `matlab/hec2_add.m` | 推荐的通用经典加法入口；有效一般输入走原公式，特殊输入走 Cantor |
| `matlab/hec2_cantor.m` | 支持约化 Mumford 除子的经典 Cantor 组合与约化算法 |
| `matlab/hec2_poly.m` | 精确有限域多项式运算、带余除法、整除、首一化及扩展欧几里得算法 |
| `matlab/hec2_exact_integers.m` | 拒绝非整数、非有限/复数、带变量的符号式及不安全的浮点大整数 |
| `matlab/hec2_validate_prime.m` | 对精确符号整数调用素性检查；只缓存已检查的模数 |
| `matlab/hec2_validate_curve.m` | 检查四个曲线系数及 gcd(f,f')=1 |
| `matlab/hec2_mumford.m` | 解码和检查除子，统一输出表示，检验 u 整除 f-v^2 |
| `matlab/demo_hec2_complete_add.m` | 演示 D+L、2D、D+(-D)、D+O |
| `matlab/run_hec2_tests.m` | 直接运行实际 .m 文件的 MATLAB 回归测试入口 |
| `matlab/regression_fixtures.json` | 75 组独立 Python Cantor 实现生成的输入与预期输出 |
| `checks/check_matlab_extended.py` | 重算并核对测试数据，扩大小有限域一般公式的检查覆盖 |
| `checks/matlab_extended_results.json` | 新增 Python 检查的实际运行结果 |
| `checks/code_revision_validation.json` | 本次所有 Python 检查及 MATLAB 语法检查的实际状态 |

`hec2_poly`、`hec2_mumford` 和曲线校验辅助函数由入口传入已经检查的
模数，不建议脱离入口直接调用它们进行未校验计算。

## 3. 特殊情形如何处理

旧函数 `hec2_projective_add` 继续保持五元组返回类型和一般分支语义。
要计算倍点等情形，应改用新入口 `hec2_add`：

```matlab
p = sym(101);
curve = sym([3 5 7 11]);
D = sym([57 11 53 60 2]);
L = sym([49 42 94 99 3]);

[R, info] = hec2_add(D, L, p, curve);
[twiceD, doubleInfo] = hec2_add(D, D, p, curve);

minusD = D;
minusD(3:4) = mod(-D(3:4), p);
zero = hec2_add(D, minusD, p, curve);
assert(zero.is_identity);

O = struct('u', sym(1), 'v', sym([]));
sameD = hec2_add(D, O, p, curve);
```

新入口统一返回结构体，不会有时返回向量、有时返回结构体：

- `R.u`、`R.v`：按常数项到最高次项排列的系数。
- `R.degree`：u 的次数，可能为 0、1、2。
- `R.is_identity`：是否为单位元。
- `R.projective`：仅在二次除子时给出五元射影坐标，其余情况为空。
- `info.branch`：generic、cantor 或 identity。
- `info.fallback_reason`：进入 Cantor 的原因。

例如默认结果的 `R.u=[94 56 1]`、`R.v=[24 30]`，表示
u=x^2+56x+94、v=30x+24。结构体可以继续作为下一次加法的输入。

这是必要的接口区分：原五元组固定表示首一二次 u，不能正确表达所有
一次除子和单位元。禁止用全零五元组或 Z=0 冒充单位元。

通用入口只捕获已知的一般分支异常；非法输入和其他运行错误仍直接报错，
不会被静默忽略。支持的模型仍是奇素数域上的光滑曲线
y^2=x^5+c3*x^3+c2*x^2+c1*x+c0，不扩展到任意曲线模型。

## 4. 输入校验的兼容性

原来的三参数 `hec2_projective_add(D,L,p)` 保留，但由于没有提供曲线，
只能校验数值和坐标格式，不能检查曲线归属。此时
`info.curve_membership_checked=false`。建议实际使用时提供完整曲线。
新通用入口要求提供曲线。

大整数请使用 `sym('整数')` 或 `sym(2)^127-1`，不要先用 double 计算再
转换为 sym。已在创建 sym 前发生的精度损失无法由校验函数恢复。
新增校验可能拒绝以前被默许的非法输入，这是有意的行为变化。

## 5. 如何运行新增测试

解压后，将 MATLAB 当前目录切换到 matlab 文件夹，保持该目录下文件齐全：

```matlab
demo_hec2_projective_add
demo_hec2_complete_add
report = run_hec2_tests;
```

需要 Symbolic Math Toolbox。测试覆盖 6 个素数域、75 组独立预期结果、
两个计算路线、倍点、相反元、单位元、共同支撑、一次除子、射影缩放、
21 项错误输入及 127 位精确坐标恢复。测试失败时抛出错误；全部通过后
才保存 matlab_native_results.mat。若已有旧结果，失败不会覆盖它，
因此应以当前运行的终端输出为准。

## 6. 本次验证结论与限制

- 21 个 Python 检查脚本已经重新运行，状态见 code_revision_validation.json。
- 新增测试数据来自原包的独立 Python Cantor 实现，并检查交换性及加法消去。
- 扩展的一般公式检查穷举了 F3、F5、F7 上二次除子输入对，并在
  F11、F13、F101 上增加确定性样本；接受的结果均与 Cantor 一致。
- MATLAB 文件使用 MISS_HIT 的 MATLAB 2021a 语法规则进行静态解析。
- 当前准备环境没有 MATLAB 或 Octave，所以新增 MATLAB 程序和原生测试
  尚未原生执行；不能把 Python 或语法检查通过称为 MATLAB 运行通过。
- 论文源文件、两份 PDF、类文件和 build.py 保持原始字节不变。

特别注意：Cantor 后备算法、经典输入校验和仿射恢复使用模逆。
它们不是论文中的无逆量子电路，不能把这个通用经典入口的运算直接计入
原来的量子比特或 Toffoli 资源数值。原一般加法公式仍然无逆。
