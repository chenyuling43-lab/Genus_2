#!/usr/bin/env python3
"""Run all independent Python checks from any working directory.

No installation or network access is performed. Source files and known-answer
inputs are staged in a temporary directory so verification cannot overwrite
the distributed code or its fixtures. Each run gets its own results folder.
"""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--standard-library-only', action='store_true',
                        help='Run 19 checks; explicitly skip the NumPy FFT check.')
    parser.add_argument('--output-dir', type=Path,
                        help='Parent directory for the new per-run results folder.')
    args = parser.parse_args()
    if sys.version_info < (3, 10):
        print('Python 3.10 or newer is required.', file=sys.stderr)
        return 2
    if sys.flags.optimize:
        print('Do not use -O/-OO or PYTHONOPTIMIZE: checks require assertions.', file=sys.stderr)
        return 2
    if not args.standard_library_only and importlib.util.find_spec('numpy') is None:
        print('NumPy is required for the full suite. Install requirements.txt, or run\n'
              '  python RUN_PYTHON.py --standard-library-only\n'
              'to run 19 checks without NumPy.', file=sys.stderr)
        return 2
    scripts = sorted((ROOT/'Verification'/'Python').glob('*.py'))
    if len(scripts) != 20:
        print('Incomplete archive: expected 20 verification scripts.', file=sys.stderr)
        return 2
    outputRoot = args.output_dir.resolve() if args.output_dir else ROOT/'results'/'python'
    outputRoot.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix='run-', dir=outputRoot))
    print('Genus-two independent Python verification', flush=True)
    print('Results: '+str(output), flush=True)
    rows = []
    environment = os.environ.copy()
    environment.pop('PYTHONOPTIMIZE', None)
    environment['PYTHONUTF8'] = '1'
    environment['PYTHONIOENCODING'] = 'utf-8'
    environment['PYTHONDONTWRITEBYTECODE'] = '1'
    started = time.perf_counter()
    try:
        with tempfile.TemporaryDirectory(prefix='genus2-checks-') as temporary:
            work = Path(temporary)
            staged = work/'Verification'/'Python'
            shutil.copytree(ROOT/'Verification'/'Python', staged,
                            ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '*.json'))
            shutil.copytree(ROOT/'KAT', work/'KAT')
            shutil.copy2(ROOT/'KAT'/'subgroup_prime_certificate.json',
                         staged/'subgroup_prime_certificate.json')
            for i, script in enumerate(scripts, 1):
                if args.standard_library_only and script.name == 'check_sampling.py':
                    print(f'[{i}/20] SKIP {script.name} (NumPy FFT)', flush=True)
                    rows.append({'script': script.name, 'status': 'skipped'})
                    continue
                print(f'[{i}/20] RUN  {script.name}', flush=True)
                before = time.perf_counter()
                log = output/(script.stem+'.log')
                command = [sys.executable, '-u', str(staged/script.name)]
                if script.name == 'verify_local_evaluator.py':
                    command += ['--output', str(staged/'local_evaluator_results.json')]
                with log.open('w', encoding='utf-8') as handle:
                    process = subprocess.run(command,
                                             cwd=work, env=environment, stdout=handle,
                                             stderr=subprocess.STDOUT)
                status = 'passed' if process.returncode == 0 else 'failed'
                rows.append({'script': script.name, 'status': status,
                             'returncode': process.returncode,
                             'seconds': round(time.perf_counter()-before, 3)})
                print(f'        {status.upper()}', flush=True)
                if process.returncode:
                    print(log.read_text(encoding='utf-8')[-3000:], flush=True)
                    break
            for result in staged.glob('*.json'):
                if result.name != 'subgroup_prime_certificate.json':
                    shutil.copy2(result, output/result.name)
    except KeyboardInterrupt:
        rows.append({'script': 'runner', 'status': 'interrupted'})
    except Exception as error:
        rows.append({'script': 'runner', 'status': 'failed', 'error': str(error)})
    passed = sum(row['status'] == 'passed' for row in rows)
    skipped = sum(row['status'] == 'skipped' for row in rows)
    required = 19 if args.standard_library_only else 20
    success = passed == required and passed+skipped == len(scripts)
    summary = {'status': ('passed_subset' if skipped else 'passed') if success else 'failed',
               'python_version': platform.python_version(), 'platform': platform.platform(),
               'passed': passed, 'skipped': skipped, 'total': len(scripts),
               'seconds': round(time.perf_counter()-started, 3), 'checks': rows,
               'scope': 'Independent Python checks; not execution of MATLAB or compilation of a full quantum sampler.'}
    if not args.standard_library_only:
        from importlib.metadata import version
        summary['numpy_version'] = version('numpy')
    (output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n', encoding='utf-8')
    print(f'\n{summary["status"].upper()}: {passed}/{len(scripts)} checks passed; {skipped} skipped.')
    print('Summary: '+str(output/'summary.json'))
    return 0 if success else 1


if __name__ == '__main__':
    raise SystemExit(main())
