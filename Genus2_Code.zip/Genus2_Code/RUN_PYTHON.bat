@echo off
setlocal
where py >nul 2>nul
if not errorlevel 1 (
    py -3 "%~dp0RUN_PYTHON.py" %*
) else (
    python "%~dp0RUN_PYTHON.py" %*
)
set "GENUS2_EXIT_CODE=%ERRORLEVEL%"
echo.
if not "%GENUS2_EXIT_CODE%"=="0" echo Verification did not complete successfully. See the message above.
pause
exit /b %GENUS2_EXIT_CODE%
