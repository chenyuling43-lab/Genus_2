function RUN_MATLAB()
%RUN_MATLAB Run the supplied projective-addition example without editing paths.
% Open this file in MATLAB and click Run, or type RUN_MATLAB at the root.
% Requires Symbolic Math Toolbox. No Python installation is needed here.
    root = fileparts(mfilename('fullpath'));
    if isempty(ver('symbolic')) || ~license('test', 'Symbolic_Toolbox')
        error('genus2:MissingToolbox', ...
            ['MATLAB with Symbolic Math Toolbox is required. ', ...
             'For independent Python verification, use RUN_PYTHON.py instead.']);
    end
    oldPath = path;
    restorePath = onCleanup(@() path(oldPath)); %#ok<NASGU>
    addpath(fullfile(root, 'Reference_Implementation', 'MATLAB'), '-begin');
    fprintf('Running the supplied genus-two projective-addition example...\n');
    run_original_demo();
    fprintf('\nPASS: the supplied MATLAB example completed its assertions.\n');
    fprintf('Expected projective result: [81 53 65 52 68]\n');
    fprintf('Expected affine result:     [56 94 30 24]\n');
    fprintf('For the 20 independent Python checks, run RUN_PYTHON.py.\n');
end

function run_original_demo()
% The original script calls clear; isolate it from the runner's onCleanup.
    demo_hec2_projective_add;
end
