function affine = hec2_projective_recover(P, p)
%HEC2_PROJECTIVE_RECOVER Recover [u1 u0 v1 v0] from [U1 U0 V1 V0 Z].
%
%   u1 = U1/Z^2, u0 = U0/Z^2, v1 = V1/Z^3, v0 = V0/Z^3 mod p.
%
% This function DOES use one modular inversion. It is intended for
% validation/debugging, not for the inversion-free projective addition.

    if nargin < 2
        error('Call affine = hec2_projective_recover(P,p).');
    end

    p = sym(p);
    P = mod(sym(P(:).'), p);

    if numel(P) ~= 5
        error('P must contain [U1 U0 V1 V0 Z].');
    end

    Z = P(5);
    if isequal(Z, sym(0))
        error('Cannot recover affine coordinates when Z = 0 mod p.');
    end

    zInv = invmod_exact(Z, p);
    zInv2 = mod(zInv^2, p);
    zInv3 = mod(zInv2 * zInv, p);

    u1 = mod(P(1) * zInv2, p);
    u0 = mod(P(2) * zInv2, p);
    v1 = mod(P(3) * zInv3, p);
    v0 = mod(P(4) * zInv3, p);

    affine = [u1 u0 v1 v0];
end

function aInv = invmod_exact(a, p)
% Exact extended-Euclidean modular inverse for symbolic integers.

    a = mod(sym(a), p);
    p = sym(p);

    old_r = p; r = a;
    old_s = sym(0); s = sym(1);

    while ~isequal(r, sym(0))
        q = floor(old_r / r);

        tmp = old_r - q * r;
        old_r = r;
        r = tmp;

        tmp = old_s - q * s;
        old_s = s;
        s = tmp;
    end

    if ~isequal(old_r, sym(1))
        error('Element is not invertible modulo p.');
    end

    aInv = mod(old_s, p);
end
