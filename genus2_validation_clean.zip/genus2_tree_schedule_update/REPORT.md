# Genus-two addition verification

Executed with Python 3 using only its standard library. No MATLAB execution,
quantum circuit compilation, or Toffoli gate simulation was performed.

## Independent generic-addition check

`python3 audit.py`

The 60 temporary-register assignments and five retained output assignments
are independently checked against a 4 by 4 finite-field interpolation solve,
polynomial quotient computation, and reduction of the negated interpolant.
Inputs are exhaustively enumerated valid degree-two Mumford pairs for the
first four fields, including irreducible and repeated-root input polynomials.
The two larger-field rows use deterministic random split degree-two inputs.

| Prime | Degree-two inputs | Ordered pairs | Generic correct | Common support | Degree-one quotient |
|---|---:|---:|---:|---:|---:|
| 3 | 16 | 256 | 88 | 128 | 40 |
| 5 | 18 | 324 | 192 | 76 | 56 |
| 7 | 46 | 2116 | 1156 | 716 | 244 |
| 11 | 132 | 17424 | 12584 | 3432 | 1408 |
| 101 | sampled | 2000 | 1815 | 171 | 14 |
| 127 | sampled | 2000 | 1863 | 128 | 9 |
| Total | | 24120 | 17698 | 4651 | 1771 |

All cases passed. All curves were checked square-free. The increasing-order
curve coefficients for q=3,5,7,11 are respectively:

- `[1,2,1,2,0,1]`
- `[3,0,2,1,0,1]`
- `[6,5,0,4,0,1]`
- `[3,5,7,0,0,1]`

The two larger primes use `[3,5,7,11,0,1]`. All generic cases also check
independent nonzero rescaling of both operands. The a0 and a4 beta-coordinate
recoveries agree whenever both are defined. Common support is detected by
H=0; non-common-support degree-one outputs have B3=0 and Z3=0 in the
generic schedule, so no complete group meaning is assigned to that tuple.

The example over the field of order 101 gives:

`(57,11,53,60,2) + (49,42,94,99,3) -> (81,53,65,52,68)` modulo 101,
with affine recovery `(56,94,30,24)`.

An additional 900 arbitrary input/target cases check the modular additive
oracle and restoration of all 60 temporaries. Moduli include composites and
2, so this checks a polynomial arithmetic map, not only curve-domain inputs.
An additional 270 cases verify that evaluating the same integer expression
then reducing agrees with evaluating its reductions, without per-modulus
branch selection. These checks do not extend its generic group-law domain.

## Complete canonical Cantor reference

`python3 cantor_complete.py`

The implementation uses two polynomial extended gcds, exact
composition quotients, and at most one reduction for genus-two inputs.
Degree-zero, degree-one and degree-two canonical reduced pairs are included.

| Prime | All reduced classes | Ordered additions | Associativity triples |
|---|---:|---:|---:|
| 3 | 22 | 484 | 10648 |
| 5 | 23 | 529 | 12167 |
| 7 | 55 | 3025 | 166375 |
| 11 | 146 | 21316 | 3112136 |
| Total | | 25354 | 3301326 |

All additions have valid reduced canonical outputs in the enumerated set.
Identity, inverse, canonical encode/decode, commutativity and every ordered
associativity triple pass. The generic schedule agrees with the complete
Cantor result for all 14020 generic pairs over these four fields.

These finite tests support, and do not replace, the symbolic group-law proof.
The complete reference is base-field arithmetic using inversion; it is not
a low-degree fixed integer program suitable for direct auxiliary-modulus
CRT evaluation.

## Conservative polynomial bounds for the generic map

Propagating total-degree upper bounds through the literal arithmetic DAG
gives `(178,177,267,266,88)` in output coordinate order U1,U0,V1,V0,Z.
Propagating coefficient l1-norm upper bounds by the triangle inequality gives

`(22883585753088, 98337571209216, 400622208452369842176,`
`1224564767479056826368, 1572864)`.

Thus generic-only safe bounds are Delta <= 267 and A < 2^71. They are
conservative bounds, not optimized or claimed exact after cancellation.
They do not establish any complete residue-tree bounds.

## Verified optional optimized output scale

The generic suite also checks the smaller-scale schedule with
Zhat=Lambda*Dbeta and its five output formulas. All 24120 pair classifications, 17698 generic affine sums,
900 arbitrary-target cleanup cases, and 270 integer/modulus commutation
cases passed for the optimized schedule as well. The exact relation to
the baseline output is multiplication by Dalpha to the corresponding
coordinate weight; this identity was checked over the integers too.

The optimized example is `(37,8,87,9,77)` modulo 101, with the same affine
recovery `(56,94,30,24)`. Here Dalpha=14 and 77*14=68 modulo 101.

The literal optimized schedule uses 58 temporary registers, t0 through t57,
with a compute/write/uncompute structure. Its retained t43=Dbeta^2 is unused
by the optimized outputs and can optionally be omitted without changing
any remaining expression. The reported counts include this unused register.

Conservative optimized output degree bounds are `(110,109,165,164,54)`;
the corresponding coefficient l1-norm bounds are
`(349175808,1500512256,23878944423936,72989747970048,6144)`.
Thus generic-only safe bounds improve to Delta <= 165 and A < 2^47.
