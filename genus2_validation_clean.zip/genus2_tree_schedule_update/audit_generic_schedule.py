"""Static audit of the t_0,...,t_59 genus-two a4 program.

No field-operation cost is confused with a Toffoli count.  Products with
coefficient two are charged twice, as specified by the schedule.
Degree and coefficient-norm results are rigorous upper bounds propagated
over the arithmetic DAG; they are not asserted to be reduced-polynomial
exact values.
"""

import ast
from collections import Counter
from dataclasses import dataclass
import json
import math


INPUTS = ("u11", "u01", "v11", "v01", "z1",
          "u12", "u02", "v12", "v02", "z2")

PROGRAM = [
    "z1**2", "z2**2", "t0*z1", "t1*z2", "t0**2", "t0*t1",
    "z1*z2", "u12*t0-u11*t1", "u12*t0+u11*t1",
    "u02*t0-u01*t1", "u02*t0+u01*t1", "v12*t2-v11*t3",
    "v02*t2-v01*t3", "t8*t7-t5*t9", "t8*t9+t7*t10",
    "t8*t7-2*t5*t9", "t7**2", "t15*t9-t16*t10",
    "t11*t14-2*t12*t13", "t11*t9-t12*t7", "2*t5*t19",
    "t6*t17", "t21*t4", "t18*t4", "t20*t4", "t21*z1",
    "t18*t0", "u11**2-u01*t0", "v11*t25+u11*t26-t20*t27",
    "u11*u01", "v01*t25+u01*t26-t20*t29", "t22**2", "t24**2",
    "2*t23*t24-t31", "t23**2+2*t28*t24", "t5*t33-t32*t8",
    "t5*t32", "t5**2", "t10+u11*u12", "t36*t38",
    "t37*t34-t39-t8*t35", "t37*t32", "t36**2", "t41**2",
    "t35**2", "t42*t41", "t35*t36", "t46*t41", "t44*t41",
    "t40*t42", "-t28*t45+t23*t47-t24*t48+t24*t49",
    "t36*t41", "t40*t36", "t35*t40", "-t30*t51+t23*t52-t24*t53",
    "t31*t36", "t55*t43", "t31*t42", "t57*t41", "t57*t43",
]

OUTPUTS = {
    "U1": "t35*t56", "U0": "t40*t58", "V1": "t50*t56",
    "V0": "t54*t59", "Z": "t22*t51",
}


@dataclass(frozen=True)
class Bound:
    degree: int
    norm: int


def bound(node, known):
    if isinstance(node, ast.Name):
        return known[node.id]
    if isinstance(node, ast.Constant):
        return Bound(0, abs(node.value))
    if isinstance(node, ast.UnaryOp):
        return bound(node.operand, known)
    if isinstance(node, ast.BinOp):
        a = bound(node.left, known)
        b = bound(node.right, known)
        if isinstance(node.op, (ast.Add, ast.Sub)):
            return Bound(max(a.degree, b.degree), a.norm+b.norm)
        if isinstance(node.op, ast.Mult):
            return Bound(a.degree+b.degree, a.norm*b.norm)
        if isinstance(node.op, ast.Pow):
            power = ast.literal_eval(node.right)
            return Bound(a.degree*power, a.norm**power)
    raise ValueError(ast.dump(node))


def terms(node, weight=1):
    if isinstance(node, ast.UnaryOp):
        yield from terms(node.operand, weight)
    elif isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Sub)):
        yield from terms(node.left, weight)
        yield from terms(node.right, weight)
    else:
        yield node, weight


def factors(node):
    if isinstance(node, ast.UnaryOp):
        return factors(node.operand)
    if isinstance(node, ast.BinOp) and isinstance(node.op, ast.Mult):
        return factors(node.left)+factors(node.right)
    return [node]


def primitives(node):
    result = Counter()
    for monomial, weight in terms(node):
        facs = factors(monomial)
        constants = [a.value for a in facs if isinstance(a, ast.Constant)]
        facs = [a for a in facs if not isinstance(a, ast.Constant)]
        weight *= math.prod(map(abs, constants))
        if len(facs) == 2 and all(isinstance(a, ast.Name) for a in facs):
            result["multiply_accumulate"] += weight
        elif len(facs) == 1 and isinstance(facs[0], ast.Name):
            result["linear_accumulate"] += weight
        elif (len(facs) == 1 and isinstance(facs[0], ast.BinOp)
              and isinstance(facs[0].op, ast.Pow)
              and ast.literal_eval(facs[0].right) == 2):
            result["square_accumulate"] += weight
        else:
            raise ValueError(ast.dump(monomial))
    return result


def main():
    assert len(PROGRAM) == 60
    known = {s: Bound(1, 1) for s in INPUTS}
    forward = Counter()
    for i, expr in enumerate(PROGRAM):
        parsed = ast.parse(expr, mode="eval").body
        known[f"t{i}"] = bound(parsed, known)
        forward.update(primitives(parsed))
    outcounts = Counter()
    outs = {}
    for name, expr in OUTPUTS.items():
        parsed = ast.parse(expr, mode="eval").body
        b = bound(parsed, known)
        known[name] = b
        outs[name] = {"degree_upper": b.degree,
                      "l1_upper": b.norm,
                      "log2_l1_upper": math.log2(b.norm),
                      "ceil_log2_l1_upper": (b.norm-1).bit_length()}
        outcounts.update(primitives(parsed))
    clean = forward+forward+outcounts
    print(json.dumps({"temporary_forward": dict(forward),
                      "output_writes": dict(outcounts),
                      "clean_node": dict(clean),
                      "outputs": outs,
                      "selected_temporary_bounds": {
                          name: {"degree_upper": known[name].degree,
                                 "l1_upper": known[name].norm}
                          for name in ("t17", "t22", "t23", "t24", "t28",
                                       "t30", "t35", "t36", "t40", "t41",
                                       "t50", "t54")}}, indent=2))


if __name__ == "__main__":
    main()
