"""Finite analytic RNS/space ledger and exact fixed-point digit audit.

Prime-product and prime-count inequalities use Dusart, arXiv:1002.0442,
page 2: theta(x)>=x(1-.2/log(x)^2) for x>=3,594,641, and
pi(x)<=x/(log(x)-1.1) for x>=60,184.  No enormous prime list is generated.
"""
from decimal import Decimal, localcontext, ROUND_CEILING
from math import ceil, log2
from collections import Counter
import json
from residue_tree_schedule import certify_tree_schedule
from reversible_crt import smoke_check as crt_reconstruction_smoke_check

def doubled_circuit(t,p):
    b=p.bit_length()
    modulus=1<<(b+1)
    # h starts at zero; cyclic rotation of b+1 bits therefore gives 2t.
    register=2*t
    register=(register-p)%modulus
    f=(register>>b)&1
    register=(register+f*p)%modulus
    assert register>>b==0
    f^=1
    f^=register&1
    assert f==0
    return register

def fixed_digit(t,p,tau):
    y=t
    ans=0
    for j in range(1,tau+1):
        y=doubled_circuit(y,p)
        ans+=(y&1)*(1<<(tau-j))
    assert y==pow(2,tau,p)*t%p
    y=y*pow(pow(2,tau,p),-1,p)%p
    assert y==t
    return ans

def bitceil(x):
    return (x-1).bit_length()

def finite(n=127,N=500,w=16):
    assert N % 2 == 0
    mr=N//2
    leaves=2*((mr+w-1)//w)
    h=bitceil(leaves)
    L=1<<h
    # Bind the published conservative ledger to an executable full-tree trace.
    schedule=certify_tree_schedule(h)
    assert schedule['all_workspace_clean']
    assert schedule['peak_vector_pebbles'] <= h+2
    assert schedule['macro_moves'] <= 8*(h+1)*L
    j=h-1
    twice_weight_height=n*20**j+16*((20**j-1)//19)
    H=n+10+12*twice_weight_height
    with localcontext() as ctx:
        ctx.prec=80
        ln2=Decimal(2).ln()
        for b in range(22,1000):
            x=Decimal(1<<b)
            lx=Decimal(b)*ln2
            lower=x*(1-Decimal('.2')/(lx*lx))/ln2-1-n
            if lower>H+2:
                break
        K=int((x/(lx-Decimal('1.1'))).to_integral_value(rounding=ROUND_CEILING))
        prime_product_log_lower=str(lower)
    # Equality-selector lookup/correction reuses the idle local-word pool.
    assert w <= 8*b, 'leaf selector scratch exceeds the reserved local pool'
    ell=bitceil(K)
    tau=ell+3
    afp=2*ell+4
    # h+2 vector pebbles,8 local words,1 parity word,1 external XOR target.
    tree_words=5*schedule['vector_pebble_bound']+10
    # Conservative b+10 primitive scratch allocation.
    recon=N+n+afp+tree_words*b+(b+10)
    phase=N+afp+6*n+12
    fourier=3*mr+5
    update=N+n+afp+n+2*b+20
    prim=20*b*b*(b+1)
    load=4*w*(1<<w)
    move=2*max(load,35506*prim)
    root=schedule['macro_move_bound']*move
    double=40*(b+1)+2
    per_digit=(2*root+40*b*(b+1)+tau*(2*double+20*(afp+1))
               +20*b*(n+1))
    forward=K*per_digit+40*(afp+1)+20*(ell+1)*(n+1)
    chen=20*n+2*bitceil(n)+10+(N-1)
    return dict(n=n,input=N,window=w,actual_leaves=leaves,padded_leaves=L,
                height=h,integer_bit_bound=H,prime_bits=b,prime_count_upper=K,
                prime_product_log_lower=prime_product_log_lower,
                fp_precision=tau,fp_register=afp,
                recon_qubits=recon,
                jacobi_qubits=phase,crt_update_qubits=update,
                preparation_fourier_qubits=fourier,
                peak=max(recon,phase,update,fourier),
                chen_matched_qubits=chen,
                reduction_percent=100*(1-max(recon,phase,update,fourier)/chen),
                clean_CRT_phase_Toffoli_upper=2*forward,
                log2_clean_CRT_phase_Toffoli_upper=log2(2*forward),
                table_entries=L*(1<<w))

def main():
    # Check complete CRT reconstruction and workspace cleanup.
    # Full boundary, phase, polynomial and elementary-gate coverage is provided
    # by validate_reversible_crt.py.
    assert crt_reconstruction_smoke_check() == 21
    checked=0
    for p in range(3,129,2):
        for t in range(p):
            assert doubled_circuit(t,p)==2*t%p
            for tau in range(1,9):
                assert fixed_digit(t,p,tau)==((1<<tau)*t)//p
                checked+=1
    print(json.dumps(dict(fixed_digit_tests=checked,
                         parameter_ledgers=[finite(w=w) for w in (8,16,24,32)]),indent=2))

if __name__=='__main__': main()
