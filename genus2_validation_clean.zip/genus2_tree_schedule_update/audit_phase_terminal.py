"""Pruned genus-two terminal Legendre phase: algebra and field tests.

The script imports the independent interpolation/polynomial-
division oracle and the literal arithmetic DAG. It does not model a
Toffoli circuit and does not certify a complete DLP resource advantage.
"""
import ast
from collections import Counter
import json
from pathlib import Path
import random
import sys

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tmp/resource_audit'))
sys.path.insert(0, str(ROOT / 'tmp/addition_audit'))
import audit_generic_schedule as dag
import audit as addition


def dependency_closure(names):
    needed = set()
    def visit(name):
        if name.startswith('t') and name[1:].isdigit() and name not in needed:
            needed.add(name)
            expression = dag.PROGRAM[int(name[1:])]
            for node in ast.walk(ast.parse(expression, mode='eval')):
                if isinstance(node, ast.Name):
                    visit(node.id)
    for name in names:
        visit(name)
    return sorted(needed, key=lambda name: int(name[1:]))


NEEDED = dependency_closure(['t40', 't41'])
CODES = {name: compile(dag.PROGRAM[int(name[1:])], '<terminal DAG>', 'eval')
         for name in NEEDED}

SMALL_PROGRAM = [
    'z1**2', 'z2**2', 's0*z1', 's1*z2', 's0*s1',
    'u12*s0-u11*s1', 'u12*s0+u11*s1', 'u02*s0-u01*s1',
    'v12*s2-v11*s3', 'v02*s2-v01*s3', 'u11*u02-u01*u12',
    's7**2-s5*s10', 's8*s7-s9*s5', 's7*s9-s10*s8',
    's13**2', 's12**2', 's11**2', 'u11*s1', 's17*s13',
    'u11*u12-s7', 'v11*s3', 's20*s11', 's6*s4',
    's4*s14+2*s18*s12+s19*s15-2*s21*s12+s22*s16', 's4*s15',
]
SMALL_CODES = [compile(p, '<square-factor terminal>', 'eval') for p in SMALL_PROGRAM]


def terminal(D, E, gamma, q):
    env = dict(zip(dag.INPUTS, D + E))
    for name in NEEDED:
        env[name] = eval(CODES[name], {'__builtins__': {}}, env) % q
    scalar = (env['t40'] + gamma * env['t41']) % q
    generic = env['t17'] != 0 and env['t24'] != 0 and D[4] * E[4] % q != 0
    phase = completed_character(scalar, q)
    before = env.copy()
    # The scalar accumulator is uncomputed before the DAG.
    scalar = (scalar - gamma * env['t41'] - env['t40']) % q
    assert scalar == 0
    for name in reversed(NEEDED):
        env[name] = (env[name] - eval(CODES[name], {'__builtins__': {}}, env)) % q
        assert env[name] == 0
    assert tuple(env[k] for k in dag.INPUTS) == D + E
    return phase, generic, before


def terminal_small(D, E, gamma, q):
    env = dict(zip(dag.INPUTS, D + E))
    for i, code in enumerate(SMALL_CODES):
        env[f's{i}'] = eval(code, {'__builtins__': {}}, env) % q
    generic = env['s11'] != 0 and env['s12'] != 0 and D[4] * E[4] % q != 0
    before = env.copy()
    env['s23'] = (env['s23'] + gamma * env['s24']) % q
    phase = completed_character(env['s23'], q)
    env['s23'] = (env['s23'] - gamma * env['s24']) % q
    for i in reversed(range(len(SMALL_CODES))):
        name = f's{i}'
        env[name] = (env[name] - eval(SMALL_CODES[i], {'__builtins__': {}}, env)) % q
        assert env[name] == 0
    assert tuple(env[k] for k in dag.INPUTS) == D + E
    return phase, generic, before


def completed_character(x, q):
    if x % q == 0:
        return 1
    return 1 if pow(x % q, (q - 1) // 2, q) == 1 else -1


def static_certificate():
    bounds = {s: dag.Bound(1, 1) for s in dag.INPUTS}
    forward = Counter()
    for name in NEEDED:
        tree = ast.parse(dag.PROGRAM[int(name[1:])], mode='eval').body
        bounds[name] = dag.bound(tree, bounds)
        forward.update(dag.primitives(tree))
    small_bounds = {s: dag.Bound(1, 1) for s in dag.INPUTS}
    small_forward = Counter()
    for i, p in enumerate(SMALL_PROGRAM):
        tree = ast.parse(p, mode='eval').body
        small_bounds[f's{i}'] = dag.bound(tree, small_bounds)
        small_forward.update(dag.primitives(tree))
    return {
        'temporaries': len(NEEDED), 'retained_labels': NEEDED,
        'forward_DAG': dict(forward),
        'clean_DAG_arithmetic': dict(forward + forward),
        'scalar_accumulator_forward': {'linear_accumulate': 1,
                                       'classical_constant_multiply_accumulate': 1},
        'N_beta': vars(bounds['t40']), 'D_beta': vars(bounds['t41']),
        'gamma_as_variable': {'degree_upper': 39, 'l1_upper': 10432},
        'gamma_as_coefficient': 'degree <= 39; norm <= 10176 + 256*abs(gamma)',
        'square_factor_cancelled': {
            'temporaries': len(SMALL_PROGRAM),
            'forward_DAG': dict(small_forward),
            'clean_DAG': dict(small_forward + small_forward),
            'N_beta': vars(small_bounds['s23']), 'D_beta': vars(small_bounds['s24']),
        },
    }


def point_divisors_large(q, rng, count):
    # q = 3 mod 4, so square roots need no external number-theory package.
    f = addition.curve(q)
    points = []
    while len(points) < 2 * count:
        x = rng.randrange(q)
        fx = sum(c * pow(x, i, q) for i, c in enumerate(f)) % q
        y = pow(fx, (q + 1) // 4, q)
        if y * y % q == fx:
            points.append((x, y if rng.randrange(2) else -y % q))
    result = []
    for i in range(count):
        x1, y1 = points[2 * i]
        x2, y2 = points[2 * i + 1]
        if x1 == x2:
            continue
        s = (y2 - y1) * pow((x2 - x1) % q, -1, q) % q
        result.append(((-x1 - x2) % q, x1 * x2 % q, s, (y1 - s * x1) % q))
    return f, result


def check_pair(D, E, f, q, rng, counts, all_gamma=False):
    kind, R = addition.reference(D, E, f, q)
    counts[kind] += 1
    encD = addition.encode(D, rng.randrange(1, q), q)
    encE = addition.encode(E, rng.randrange(1, q), q)
    phase, generic, before = terminal(encD, encE, 0, q)
    small_phase, small_generic, small = terminal_small(encD, encE, 0, q)
    square = (2 * pow(encD[4], 7, q) * pow(encE[4], 3, q)) ** 2 % q
    assert before['t40'] == square * small['s23'] % q
    assert before['t41'] == square * small['s24'] % q
    assert generic == small_generic
    assert phase == small_phase
    assert generic == (kind == 'generic')
    if not generic:
        return
    assert before['t40'] * pow(before['t41'], -1, q) % q == R[1]
    assert completed_character(before['t41'], q) == 1
    gammas = list(range(q)) if all_gamma else [0, 1, rng.randrange(q), (-R[1]) % q]
    for gamma in gammas:
        expected = completed_character(R[1] + gamma, q)
        phase, generic, _ = terminal(encD, encE, gamma, q)
        small_phase, small_generic, _ = terminal_small(encD, encE, gamma, q)
        assert generic and phase == expected
        assert small_generic and small_phase == expected
        counts['phase_tests'] += 1
        # A second independently chosen weighted representative.
        d = addition.encode(D, rng.randrange(1, q), q)
        e = addition.encode(E, rng.randrange(1, q), q)
        assert terminal(d, e, gamma, q)[0] == expected
        assert terminal_small(d, e, gamma, q)[0] == expected
        counts['independent_scale_tests'] += 1
        if (R[1] + gamma) % q == 0:
            assert phase == 1
            counts['completed_zero_tests'] += 1


def main():
    rng = random.Random(20260911)
    report = {'static': static_certificate(), 'fields': {}}
    for q in (3, 5, 7, 11):
        f = addition.curve(q)
        divisors = addition.all_divisors(f, q)
        counts = Counter()
        for D in divisors:
            for E in divisors:
                check_pair(D, E, f, q, rng, counts, all_gamma=True)
        report['fields'][str(q)] = dict(curve=f, **counts)
    for q in (101, 127):
        f = addition.curve(q)
        divisors = addition.random_split_divisor(f, q, rng)
        counts = Counter()
        for _ in range(2000):
            check_pair(rng.choice(divisors), rng.choice(divisors), f, q, rng, counts)
        report['fields'][str(q)] = dict(curve=f, **counts)
    q = 2 ** 127 - 1
    f, divisors = point_divisors_large(q, rng, 240)
    counts = Counter()
    for i in range(100):
        check_pair(divisors[2 * i], divisors[2 * i + 1], f, q, rng, counts)
    report['fields'][str(q)] = dict(curve=f, **counts)
    report['cryptographic_field_scope'] = ('Arithmetic tests at a 127-bit field; '
        'neither the curve group order nor a cryptographic subgroup was certified.')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
