# CRT 可逆重构与验证

本说明介绍流式 CRT 重构、任意目标 XOR 接口和字符相位清理，
包括寄存器语义、运行命令及已记录的验证范围。

## 1. 文件与功能

| 文件 | 功能 |
|---|---|
| `reversible_crt.py` | 参数检查、重构轨迹、逆过程、XOR 与相位清理接口 |
| `crt_gate_backend.py` | 小实例 X/CNOT/Toffoli 网络及辅助寄存器分配 |
| `validate_reversible_crt.py` | 独立整数参照、边界、实际多项式、门网络及故障测试 |
| `audit_streaming_ledger.py` | 21 个完整 CRT 检查、固定点数字测试与资源统计 |
| `reversible_crt_validation_report.json` | 验证结果及参考电路资源数据 |
| `crt_reconstruction_trace.json` | 小实例逐步骤寄存器状态 |
| `crt_small_gate_network.json` | 小实例 XOR 门网络与寄存器映射 |

## 2. 如何运行

在解压后的代码目录运行，使用 Python 3.10+，完整验证需要 NumPy。

```sh
python3 reversible_crt.py --trace crt_reconstruction_trace.json
python3 validate_reversible_crt.py
python3 crt_gate_backend.py --netlist crt_small_gate_network.json
python3 audit_streaming_ledger.py
python3 validate_residue_tree_schedule.py
```

前四个命令检查 CRT 重构和资源统计，最后一个检查全树调度。不要使用 `python -O`，审计依赖 assert 检查。

最小调用示例：

```python
from reversible_crt import CRTParameters, clean_xor_trace, execute, zero_registers

params = CRTParameters(q=7, moduli=(3, 5), bound=3)
regs = zero_registers(O=5)
execute(clean_xor_trace(params), regs, params, -1, lambda X, p: X % p)
assert regs == dict(Y=0, A=0, r=0, t=0, O=3)
```

其中 `lambda X,p:X%p` 仅为整数测试的根 oracle。接入实际算法时，应传入同一个固定整数树多项式在各 p 下的清理后 XOR 接口。验证器中的 `integer_and_modular_tree()` 已检查真实四叶多项式与辅助剩余数的对应关系；逐门后端为小实例使用显式真值表 XOR 电路。

## 3. 完整寄存器过程

固定输入 x 的整数树输出记为 X(x)。参数必须有一个对整个输入域有效的界 `|X(x)| <= B`，辅助模数乘积 `M > 4B`。不能对每个叠加分支单独选择 B 或模数。

保留寄存器为：

| 寄存器 | 含义 | 正向 R 完成后 |
|---|---|---|
| Y | 模 q 的输出累加器，n 位 | 从零开始时为 X mod q |
| A | 固定点累加器，a_fp 位 | 保留完整固定点和，不能丢弃 |
| r | 当前辅助模数的根剩余数 | 0 |
| t | 当前加权 CRT 数字 | 0 |
| O | 外部任意 n 位 XOR 目标 | R 本身不改它；完整 XOR 接口会更新它 |

没有单独的 `z_i` 数字字或 `eta` 商字。量子输入 x 始终保留。高位、比较标志、进位、常数工作字由逐门后端另行分配并检查。

每个模数 p_i 的过程是：

1. 用 clean root XOR 将 `x_i=X mod p_i` 写入 r。
2. 以 r 为源，把 `t_i=a_i r mod p_i` 计算到初始为零的 t，其中 `a_i=(M/p_i)^(-1) mod p_i`。
3. 重复 tau 次模加倍 t；每次用新 t 的最低位控制向 A 加入 `2^(tau-j)`。
4. 逆序撤销这 tau 次加倍，使 t 恢复为 t_i；A 保留所累加的固定点数字。
5. 逐位控制模 q 常数加法，执行 `Y += t_i (M_i mod q)`。
6. 撤销 t 的计算；再次调用 clean root XOR 将 r 清零。检查 r=t=0，然后进入下一个模数。

全部模数结束后：

1. `A += 2^(tau-1)`。
2. 直接用 A 从第 tau 位开始的高位作为 eta 的二进制控制，执行 `Y -= eta (M mod q)`。
3. `A -= 2^(tau-1)`，恢复未偏移的固定点和。

逆过程由静态轨迹自动反向遍历，每项使用逆操作，以恢复工作寄存器。

如果 root XOR 内部使用全树测量方案，逆过程中的 root XOR 表示一次使用新测量结果、完成全部相位纠正的正向调用。它不表示反转测量。逐门真值表 XOR 的新调用与逐门反向列表可以有不同门顺序；验证器检查两者的实际作用均正确。

## 4. 小例子：为什么要保留 A

取 `X=-1, q=7, (p_1,p_2)=(3,5), B=3`。此时 M=15>12，tau=4，a_fp=6。

| 项目 | p=3 | p=5 |
|---|---:|---:|
| M_i | 5 | 3 |
| a_i | 2 | 2 |
| x_i | 2 | 4 |
| t_i | 1 | 3 |
| floor(16 t_i/p_i) | 5 | 9 |

所以 A=14，未修正的 Y=(1×5+3×3) mod 7=0。

`eta=(14+8)>>4=1`，修正后 Y=(0−15) mod 7=6，正好是 −1 mod 7。

若外部目标 O=5，复制结果后 O=5 XOR 6=3。再执行 R 的逆过程，最终：

`Y=0, A=0, r=0, t=0, O=3`。

如果改为相位接口，在 Y=6 时施加所需字符相位，再逆序执行 R，则包括 A 在内的工作寄存器全部归零，逻辑输入只获得应有相位。

## 5. 两种最终接口与正确性范围

正向 R 在 A、r、t 初始为零且 Y 为规范剩余数时满足：

`(Y,0,0,0) -> ((Y+X) mod q, A_fp(X),0,0)`。

- `clean_xor_trace()` 使用零 Y，执行 `R; O ^= Y; R^-1`。O 可以是任意 n 位状态，含非规范剩余数编码以及与输入或参考系统纠缠的状态。
- `clean_phase()` 使用零 Y，执行 `R; Phi(Y); R^-1`。固定点和一直保留到 Phi 之后再清除。

这两种接口需要分别检查：恢复输入与工作区不等于输出值必然正确；仅检查输出值也不能说明工作区清理和相位正确。

`completed_character()` 提供零点取 +1 的 Legendre 字符参照，要求输出模数 q 为素数。CRT 本身允许这里明示的互素奇合数辅助模数；`CRTParameters` 检查互素性而不证明素性。

## 6. 验证覆盖

详尽计数以 `reversible_crt_validation_report.json` 为准：

- 3,143 个小范围有符号整数全枚举案例，包含 1,569 个负数与零；每例检查正向重构、固定点和、逆过程、任意目标 XOR 和字符相位。
- 224 个额外保护区间/K 边界案例，包括 K=1、2、3、4、5、7、8、9 及互素奇合数辅助模数。
- 32 个 q=2^127−1、|X|≤2^256 的完整字级重构案例。
- 128 个非零 A 初值的正反向恢复案例。这仅检验可逆性；非零 A 的输出不用于验证 CRT 重构正确性。
- 16 个真实四叶多项式案例，含正、负、零整数提升。模数使用论文保守高度界选择，而不是按单个结果量身选择。
- 两套完整小实例 CRT 算术门网络：q=7、辅助模数 3/5，以及 q=5、辅助模数 3/7。
- 192 个门级输入/任意目标基态案例；1,968 个宏操作边界检查，逐项比较字级执行与门级执行，检查进位、标志、常数字及借用位恢复。
- 对含参考系统的随机复振幅状态，XOR 与 R^-1 Phi R 的振幅误差均为 0。
- 拒绝保护区间不足、固定点精度不足、模数不互素及偶辅助模数。
- 故意删除舍入偏移后，X=−1 案例输出 0，正确值为 6；故意漏掉 A 的反算后，留下 A=16。测试能检测这两类错误。

逐门网络通过 X/CNOT/Toffoli 执行 R、复制和 R 的逆过程；Phi 在组合验证中作为指定的对角字符操作插入。Jacobi 字符电路由 `validate_jacobi_gates.py` 单独验证。密码学规模的 root、CRT 和 Jacobi 组合尚未编译为完整容错电路。

参考逐门后端为便于审计显式保留辅助位：两例分别分配 39 和 40 位（含输入、外部目标和额外借用工作区）。完整 XOR 网络分别为 8,103 和 9,007 个 X/CNOT/Toffoli 门。这些是小实例参考实现数据，不构成论文 1977/1667 位实例的门级综合验证，Toffoli 上界仍由资源公式给出。
