# Baseline arithmetic and phase validation

Extract this archive into one directory and run the commands below there.
Python 3.10 or later is required. Only `validate_sampling.py` needs NumPy;
the other scripts use the standard library.

```sh
python3 audit.py
python3 cantor_complete.py
python3 validate_binary_backend.py
python3 audit_binary_jacobi.py
python3 audit_generic_schedule.py
python3 audit_optimized_certificate.py
python3 audit_phase_terminal.py
python3 sparse_certificate.py
python3 validate_sampling.py
```

The arithmetic checks cover the full-scale and smaller-scale generic
addition formulas, arbitrary-target cleanup, integer/reduction
compatibility, complete small-field Cantor addition, fixed binary
inversion/Jacobi traces, and static register/degree certificates.
`REPORT.md` records arithmetic coverage. Run the scripts from the
package directory so that local imports resolve.

The direct terminal oracle has 25 temporary field words and exact
local phase cost `68 Macc + 12 Sacc + 2 Add + 2 C_gamma + G_chi`.
`audit_phase_terminal.py` checks the phase against an independent affine
interpolation oracle, including zero completion and independently scaled
weighted inputs. Its tests include the 127-bit base field `2^127-1`, but
do not certify a cryptographic subgroup or a complete attack benchmark.
`TERMINAL_VALIDATION.md` explains the test scope and precise totals.
`sparse_certificate.py` checks the square-factor cancellation as an exact
integer polynomial identity, and certifies numerator degree 19 and norm
232, denominator degree 18 and norm 64. The associated JSON reports record
the expected results.

`validate_sampling.py` verifies abstract Fourier sampling on four complete
small-field instances, canonical-phase covariance on exact and rectangular
domains, and the explicit field-shift rectangle obstruction. Group orders
are independently checked by counting curve points over the prime field
and its quadratic extension. Sign counts use exact integers and fractions;
NumPy transforms use complex128 with the stated numerical tolerance.

MATLAB listings are outside the reported validation. The baseline scripts
listed here test algebraic identities, register semantics, and sampling
laws; they do not synthesize or simulate a gate-level quantum circuit.
Local terminal savings alone do not establish a whole-algorithm width
reduction. The exact arbitrary-input CRT route still requires a complete
low-degree CRT-compatible exceptional-case program and concrete canonical
circuit costs. The approximate masked sampler and its component gate
checks are described in `README.md`.
