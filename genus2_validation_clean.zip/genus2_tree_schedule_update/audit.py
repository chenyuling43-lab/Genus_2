"""Independent finite-field audit of the generic genus-two addition.

Uses the literal 60-register schedule, and independently derives the answer
by solving four interpolation equations and polynomial division.  No Sage,
MATLAB, or non-standard dependency is required.  Deterministic seed.
"""
import json
import random
from collections import Counter


TEMP = [
    'z1*z1', 'z2*z2', 't[0]*z1', 't[1]*z2', 't[0]*t[0]',
    't[0]*t[1]', 'z1*z2', 'a2*t[0]-a1*t[1]',
    'a2*t[0]+a1*t[1]', 'b2*t[0]-b1*t[1]', 'b2*t[0]+b1*t[1]',
    's2*t[2]-s1*t[3]', 'r2*t[2]-r1*t[3]',
    't[8]*t[7]-t[5]*t[9]', 't[8]*t[9]+t[7]*t[10]',
    't[8]*t[7]-2*t[5]*t[9]', 't[7]*t[7]',
    't[15]*t[9]-t[16]*t[10]', 't[11]*t[14]-2*t[12]*t[13]',
    't[11]*t[9]-t[12]*t[7]', '2*t[5]*t[19]', 't[6]*t[17]',
    't[21]*t[4]', 't[18]*t[4]', 't[20]*t[4]', 't[21]*z1',
    't[18]*t[0]', 'a1*a1-b1*t[0]',
    's1*t[25]+a1*t[26]-t[20]*t[27]', 'a1*b1',
    'r1*t[25]+b1*t[26]-t[20]*t[29]', 't[22]*t[22]',
    't[24]*t[24]', '2*t[23]*t[24]-t[31]',
    't[23]*t[23]+2*t[28]*t[24]', 't[5]*t[33]-t[32]*t[8]',
    't[5]*t[32]', 't[5]*t[5]', 't[10]+a1*a2',
    't[36]*t[38]', 't[37]*t[34]-t[39]-t[8]*t[35]',
    't[37]*t[32]', 't[36]*t[36]', 't[41]*t[41]',
    't[35]*t[35]', 't[42]*t[41]', 't[35]*t[36]',
    't[46]*t[41]', 't[44]*t[41]', 't[40]*t[42]',
    '-t[28]*t[45]+t[23]*t[47]-t[24]*t[48]+t[24]*t[49]',
    't[36]*t[41]', 't[40]*t[36]', 't[35]*t[40]',
    '-t[30]*t[51]+t[23]*t[52]-t[24]*t[53]',
    't[31]*t[36]', 't[55]*t[43]', 't[31]*t[42]',
    't[57]*t[41]', 't[57]*t[43]',
]
OUTPUT = ['t[35]*t[56]', 't[40]*t[58]', 't[50]*t[56]',
          't[54]*t[59]', 't[22]*t[51]']
TCODE = [compile(s, '<schedule>', 'eval') for s in TEMP]
OCODE = [compile(s, '<schedule>', 'eval') for s in OUTPUT]
OPT_TEMP = TEMP[:55] + ['t[31]*t[41]', 't[55]*t[5]', 't[31]*t[37]']
OPT_OUTPUT = ['t[35]*t[56]', 't[40]*t[55]', 't[50]*t[57]',
              't[54]*t[56]', 't[22]*t[41]']
OPT_TCODE = [compile(s, '<optimized schedule>', 'eval') for s in OPT_TEMP]
OPT_OCODE = [compile(s, '<optimized schedule>', 'eval') for s in OPT_OUTPUT]


def schedule(D, L, modulus=None, y=None, cleanup=False):
    a1, b1, s1, r1, z1 = D
    a2, b2, s2, r2, z2 = L
    t = [0]*60
    env = dict(a1=a1, b1=b1, s1=s1, r1=r1, z1=z1,
               a2=a2, b2=b2, s2=s2, r2=r2, z2=z2, t=t)
    reduce = (lambda x: x % modulus) if modulus else (lambda x: x)
    for i, code in enumerate(TCODE):
        t[i] = reduce(t[i] + eval(code, {'__builtins__': {}}, env))
    frozen = t.copy()
    raw = [reduce(eval(code, {'__builtins__': {}}, env)) for code in OCODE]
    out = [reduce(z + x) for z, x in zip(y or [0]*5, raw)]
    if cleanup:
        for i in range(59, -1, -1):
            t[i] = reduce(t[i] - eval(TCODE[i], {'__builtins__': {}}, env))
        assert t == [0]*60
    return out, frozen


def schedule_optimized(D, L, modulus=None, y=None, cleanup=False):
    a1, b1, s1, r1, z1 = D
    a2, b2, s2, r2, z2 = L
    t = [0]*58
    env = dict(a1=a1, b1=b1, s1=s1, r1=r1, z1=z1,
               a2=a2, b2=b2, s2=s2, r2=r2, z2=z2, t=t)
    reduce = (lambda x: x % modulus) if modulus else (lambda x: x)
    for i, code in enumerate(OPT_TCODE):
        t[i] = reduce(t[i] + eval(code, {'__builtins__': {}}, env))
    frozen = t.copy()
    raw = [reduce(eval(code, {'__builtins__': {}}, env)) for code in OPT_OCODE]
    out = [reduce(z + x) for z, x in zip(y or [0]*5, raw)]
    if cleanup:
        for i in range(57, -1, -1):
            t[i] = reduce(t[i] - eval(OPT_TCODE[i], {'__builtins__': {}}, env))
        assert t == [0]*58
    return out, frozen


def trim(a):
    while len(a) > 1 and not a[-1]:
        a.pop()
    return a


def psub(a, b, p):
    return trim([((a[i] if i < len(a) else 0) -
                  (b[i] if i < len(b) else 0)) % p
                 for i in range(max(len(a), len(b)))])


def pmul(a, b, p):
    c = [0]*(len(a)+len(b)-1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            c[i+j] = (c[i+j]+x*y) % p
    return trim(c)


def pdiv(a, b, p):
    a, b = trim(a.copy()), trim(b.copy())
    assert b != [0]
    q = [0]*max(1, len(a)-len(b)+1)
    inv = pow(b[-1], -1, p)
    while a != [0] and len(a) >= len(b):
        pos = len(a)-len(b)
        factor = a[-1]*inv % p
        q[pos] = factor
        for j, x in enumerate(b):
            a[pos+j] = (a[pos+j]-factor*x) % p
        trim(a)
    return trim(q), trim(a)


def pgcd(a, b, p):
    while b != [0]:
        a, b = b, pdiv(a, b, p)[1]
    inv = pow(a[-1], -1, p)
    return [x*inv % p for x in a]


def solve4(matrix, rhs, p):
    m = [[x % p for x in row]+[y % p] for row, y in zip(matrix, rhs)]
    for col in range(4):
        pivot = next((i for i in range(col, 4) if m[i][col]), None)
        if pivot is None:
            return None
        m[col], m[pivot] = m[pivot], m[col]
        inv = pow(m[col][col], -1, p)
        m[col] = [x*inv % p for x in m[col]]
        for i in range(4):
            if i != col:
                fac = m[i][col]
                m[i] = [(a-fac*b) % p for a, b in zip(m[i], m[col])]
    return [m[i][-1] for i in range(4)]


def reference(D, L, f, p):
    a, b, s, r = D
    c, d, t, w = L
    # Cubic interpolation uses coefficients in increasing order.
    ell = solve4([[1, 0, -b, a*b], [0, 1, -a, a*a-b],
                  [1, 0, -d, c*d], [0, 1, -c, c*c-d]],
                 [r, s, w, t], p)
    if ell is None:
        return 'common_support', None
    numerator = psub(pmul(ell, ell, p), f, p)
    quotient, rem = pdiv(numerator, pmul([b, a, 1], [d, c, 1], p), p)
    assert rem == [0]
    if ell[3] == 0:
        assert len(quotient) == 2
        return 'degree_one_output', None
    assert len(quotient) == 3
    inv = pow(quotient[-1], -1, p)
    u = [x*inv % p for x in quotient]
    v = pdiv([(-x) % p for x in ell], u, p)[1]
    v += [0]*(2-len(v))
    assert pdiv(psub(f, pmul(v, v, p), p), u, p)[1] == [0]
    return 'generic', (u[1], u[0], v[1], v[0])


def encode(D, z, p):
    a, b, s, r = D
    return (a*z*z % p, b*z*z % p, s*z**3 % p, r*z**3 % p, z)


def recover(P, p):
    a, b, s, r, z = P
    zi = pow(z, -1, p)
    return (a*zi**2 % p, b*zi**2 % p, s*zi**3 % p, r*zi**3 % p)


def all_divisors(f, p):
    result = []
    for a in range(p):
        for b in range(p):
            rem = pdiv(f, [b, a, 1], p)[1]
            rem += [0]*(2-len(rem))
            for s in range(p):
                for r in range(p):
                    if ((r*r-b*s*s) % p == rem[0] and
                            (2*r*s-a*s*s) % p == rem[1]):
                        result.append((a, b, s, r))
    return result


def curve(p):
    f = [3 % p, 5 % p, 7 % p, 11 % p, 0, 1]
    while pgcd(f, [(i*f[i]) % p for i in range(1, 6)], p) != [1]:
        f[0] = (f[0]+1) % p
    return f


def check_pair(D, L, f, p, rng, counts):
    z1, z2 = rng.randrange(1, p), rng.randrange(1, p)
    d, l = encode(D, z1, p), encode(L, z2, p)
    got, t = schedule(d, l, p, cleanup=True)
    optimized, ot = schedule_optimized(d, l, p, cleanup=True)
    assert t[:55] == ot[:55]
    assert got == [x*pow(t[36], w, p) % p
                   for x,w in zip(optimized, (2,2,3,3,1))]
    kind, expected = reference(D, L, f, p)
    counts[kind] += 1
    assert (t[17] == 0) == (kind == 'common_support')
    if kind == 'generic':
        assert t[24] != 0 and got[-1] != 0
        assert recover(got, p) == expected
        assert recover(optimized, p) == expected
        # Independent rescaling of both inputs must preserve the affine sum.
        rescaled, _ = schedule(encode(D, rng.randrange(1, p), p),
                              encode(L, rng.randrange(1, p), p), p)
        assert recover(rescaled, p) == expected
        if D[1] == 0 or L[1] == 0:
            counts['generic_with_zero_u0'] += 1
        if (D[0]*D[0]-4*D[1]) % p == 0 or (L[0]*L[0]-4*L[1]) % p == 0:
            counts['generic_with_repeated_root'] += 1
        if D[1] and L[1]:
            # Constant-coefficient quotient identity is independent of a4.
            beta_a0 = (t[5]*(t[30]**2-f[0]*t[22]**2) *
                       pow((t[24]**2*d[1]*l[1]) % p, -1, p)) % p
            assert beta_a0 == expected[1]
            counts['a0_a4_agreement'] += 1
    elif kind == 'degree_one_output':
        assert t[24] == 0 and got[-1] == 0


def random_split_divisor(f, p, rng):
    points = []
    for x in range(p):
        val = sum(c*pow(x, i, p) for i, c in enumerate(f)) % p
        for y in range(p):
            if y*y % p == val:
                points.append((x, y))
    result = []
    for _ in range(300):
        x1, y1 = rng.choice(points)
        x2, y2 = rng.choice(points)
        if x1 == x2:
            continue
        s = (y2-y1)*pow((x2-x1) % p, -1, p) % p
        r = (y1-s*x1) % p
        result.append(((-x1-x2) % p, x1*x2 % p, s, r))
    return result


def main():
    rng = random.Random(20260911)
    report = {}
    for p in (3, 5, 7, 11):
        f = curve(p)
        ds = all_divisors(f, p)
        counts = Counter()
        for D in ds:
            for L in ds:
                check_pair(D, L, f, p, rng, counts)
        report[str(p)] = dict(curve_coefficients=f, divisors=len(ds),
                              ordered_pairs=len(ds)**2, counts=dict(counts))
    for p in (101, 127):
        f = curve(p)
        ds = random_split_divisor(f, p, rng)
        counts = Counter()
        for _ in range(2000):
            check_pair(rng.choice(ds), rng.choice(ds), f, p, rng, counts)
        report[str(p)] = dict(curve_coefficients=f, ordered_pairs=2000,
                              counts=dict(counts))
    D, L = (57, 11, 53, 60, 2), (49, 42, 94, 99, 3)
    P, t = schedule(D, L, 101, cleanup=True)
    assert P == [81, 53, 65, 52, 68]
    report['provided_example'] = dict(projective=P, affine=recover(P, 101))
    OP, ot = schedule_optimized(D, L, 101, cleanup=True)
    assert recover(OP, 101) == recover(P, 101)
    report['optimized_example'] = dict(projective=OP, affine=recover(OP, 101),
                                       old_to_new_scale=ot[36])
    # All inputs are allowed in the polynomial oracle even where the curve
    # interpretation fails. Addition to nonzero targets is tested explicitly.
    count = 0
    for modulus in (2, 3, 4, 5, 6, 9, 15, 101, 127):
        for _ in range(100):
            D = tuple(rng.randrange(modulus) for _ in range(5))
            L = tuple(rng.randrange(modulus) for _ in range(5))
            target = [rng.randrange(modulus) for _ in range(5)]
            raw, _ = schedule(D, L, modulus)
            got, _ = schedule(D, L, modulus, y=target, cleanup=True)
            assert got == [(a+b) % modulus for a, b in zip(target, raw)]
            oraw, ot = schedule_optimized(D, L, modulus, cleanup=True)
            ogot, _ = schedule_optimized(D,L,modulus,y=target,cleanup=True)
            assert ogot == [(a+b) % modulus for a,b in zip(target,oraw)]
            assert raw == [x*pow(ot[36],w,modulus) % modulus
                           for x,w in zip(oraw,(2,2,3,3,1))]
            count += 1
    report['arbitrary_target_cleanup_cases'] = count
    count = 0
    for _ in range(30):
        D = tuple(rng.randrange(-3, 4) for _ in range(5))
        L = tuple(rng.randrange(-3, 4) for _ in range(5))
        integer, _ = schedule(D, L, cleanup=True)
        ointeger, ot = schedule_optimized(D, L, cleanup=True)
        assert integer == [x*ot[36]**w
                           for x,w in zip(ointeger,(2,2,3,3,1))]
        for modulus in (2, 3, 4, 5, 6, 9, 15, 101, 127):
            modular, _ = schedule(D, L, modulus, cleanup=True)
            assert [v % modulus for v in integer] == modular
            omodular, _ = schedule_optimized(D,L,modulus,cleanup=True)
            assert [v % modulus for v in ointeger] == omodular
            count += 1
    report['integer_reduction_commutation_cases'] = count
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
