# Terminal phase validation

The implemented local phase takes two weighted degree-two input tuples,
retains both, computes the 25-word cancelled program, changes its numerator
word by gamma times its denominator word, applies the completed Legendre
sign, restores the numerator, and uncomputes all 25 words.

`audit_phase_terminal.py` checked 24,220 input pairs: 17,778 generic,
4,663 shared-support exclusions, and 1,779 degree-one-output exclusions.
It passed 162,772 shifted-phase tests and the same number of independent
weighted-rescaling tests. These include 17,841 zero-completion cases.

Fields 3, 5, 7, 11 exhaust all ordered degree-two divisor pairs on the
listed curves and all field shifts on each generic pair. Fields 101 and
127 use 2,000 sampled input pairs each and shifts 0, 1, random, and minus
the output constant coefficient. The 127-bit field 2^127-1 uses 100 pairs
and those four shifts: 400 phase checks and 400 independent scale checks.
The curve polynomial is x^5+11x^3+7x^2+5x+3 in the three largest fields.
No curve-group order or cryptographic subgroup is certified by these tests.

An independent cubic-interpolation and polynomial-division oracle supplies
the affine sum for the phase comparison. All temporary words are checked
to return to zero, with inputs unchanged. These are algebraic and register-
semantic tests, not execution of a compiled quantum circuit.

`sparse_certificate.py` checks exact integer polynomial identities using
sparse dictionaries and exact integers, with no external symbolic library.
It proves the original numerator and denominator share the removable
square (2 Z1^7 Z2^3)^2. The cancelled numerator has 115 monomials, degree 19,
and l1 norm 232; its denominator has 34 monomials, degree 18, norm 64.

The arithmetic DAG gives 34 multiply-accumulates, 6 square-accumulates,
and 1 linear accumulation in one direction. Thus the clean phase costs
68 Macc + 12 Sacc + 2 Add + 2 C_gamma + G_chi, where C_gamma is a charged
classical-constant multiply-accumulate. Its width is bounded by
max(35n+A_prim(n), 34n+W_chi(n)) + O(1), counting both inputs.

These tests cover the local terminal circuit. Complete CRT fallback,
compiled gate counts, global DLP resources, and optimality are outside
this validation scope.
