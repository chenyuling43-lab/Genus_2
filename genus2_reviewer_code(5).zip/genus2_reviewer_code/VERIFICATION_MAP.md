# Verification map

This map refers to the accompanying 37-page manuscript: 27 body pages,
2 reference pages, and 8 appendix pages. Section and proposition numbers
are taken from that version. The checks support different kinds of claims;
a finite example, a symbolic identity, and a compiled gate permutation are
not interchangeable forms of evidence.

There are 20 checkers. Shared support modules are not additional checkers.
Result files contain the individual case counts; fixed pseudorandom seeds
are stated in the scripts and, where recorded, their JSON reports.
The supplied JSON files are reference outputs, not evidence that a local
rerun has succeeded; the runner produces a separate verification report.

## Arithmetic and parameter certificates

| Checker | Manuscript connection | What is checked and how to interpret it |
|---|---|---|
| `audit_arithmetic.py` | Sections 4.3, 5.1–5.2, and 6.6; Table 3; Appendix A | Exact sparse expansion over the integers of the five output polynomials and the terminal polynomials `N` and `D`: monomial counts, degrees, coefficient norms, weighted bidegrees, and denominator-clearing identities. These are symbolic polynomial checks, including comparison with the stated conservative norm bounds. |
| `audit_finite.py` | Sections 2.2, 5.1, and 6.6 | Complete Cantor addition on every ordered input pair for the chosen curves over fields of orders 5 and 7, and 2,000 sampled pairs for each of 11 and 13. Compares the compact map only where its generic branch applies, with nonzero random projective scales. This finite test does not prove completeness of the compact branch. |
| `check_arithmetic_proofs.py` | Lemma 2.1; Sections 4.3 and 5.1; Appendix A | Exhaustive inversion invariants, terminal values, and history reversal for 277,048 canonical inputs over odd primes below 2,000; separate integer-polynomial checks of the resultant, interpolation remainders, and reduction identities. It does not synthesize the complete reversible Cantor backend. |
| `check_normalized_height.py` | Section 5.2, equation (37); Section 6.4; Appendix D.3 | Normalizes the leaf scales, computes coefficient norms and support maxima, and propagates the coordinatewise integer bit bounds. Writes the height parameters consumed by the resource ledger. Its decimal prime estimates are cross-checked by the rational certificate below. |
| `check_height_certificate_independent.py` | Section 5.2; Section 6.4; Appendix D.3 | Recomputes norm ceilings, support maxima, height recurrences, and the prime-product margin using exact integers and rational bounds for `ln(2)`. It uses the same declared polynomial model but a separate recurrence and allocation calculation. It does not enumerate the auxiliary primes or improve the asymptotic tree exponent. |
| `verify_subgroup_prime_certificate.py` | Section 6.3; Lemma D.1 | Verifies the supplied recursive Pocklington certificate for the displayed 250-bit subgroup order. All 35 certified primes, including trial-division leaves, are verified deterministically. The verifier uses no probable-prime test and does not generate the certificate. |
| `check_gs_parameters.py` | Section 6.3, Table 1; Lemma D.1 | Certifies the field prime, checks the displayed curve and generator, verifies `[r]P = 0` and `P != 0`, and identifies `#J = 16r` using the certified order and an integer Weil interval. The coordinate transformation from the source publication's model is not independently checked. |
| `check_matlab_algebra.py` | Sections 4.3 and 5.1; Appendix A; companion MATLAB reference | Exact Python transcription of both MATLAB recovery routes, with the fixed example and seeded Cantor comparisons. Each route has 905 generic comparisons and 95 rejected pairs among 1,000 trials. This verifies the transcribed equations, not MATLAB or Octave execution. The checker binds the reviewed MATLAB source by SHA-256 and records both source identities; see `matlab/SOURCE_CORRESPONDENCE.md`. |

## Phases, sampling, and masks

| Checker | Manuscript connection | What is checked and how to interpret it |
|---|---|---|
| `check_phase.py` | Lemma 4.2; Proposition 4.7; Appendices B and D.1 | Completed Jacobi/Legendre signs on 277,048 canonical inputs, forward/inverse branch permutations on binary words, dirty-ancilla ladders, two-bit arithmetic, and exact shifted-character correlations. Also checks the collision-probability counterexample in Appendix B. These are local arithmetic and permutation checks, not the full quantum sampler. |
| `check_sampling.py` | Theorems 3.1 and 3.3; Section 4.2; Appendix D.3 | Enumerates four small Cantor subgroups and their fibers, checks canonical-sign covariance exactly, and compares exact-domain and rectangular Fourier distributions numerically. All 26 field-shift seeds are tested. NumPy FFT discrepancies must be below `2e-12`; the group, fiber, and covariance calculations are exact. |
| `rectangular_example_check.py` | Supports the domain distinction in Sections 3.1–3.2 and 5.6 | Additional exact fixture over the field of order 5, including point counts, Jacobian enumeration, fiber counts, and a two-by-two rectangular distribution. Its total variation `5/8` demonstrates why an exact-domain Legendre statement cannot be transferred to rectangles without an additional argument. This fixture is supplied in the artifact; it is not a numbered table in the current manuscript. |
| `check_affine_masks.py` | Proposition 5.4; Theorem 5.6; Appendix B | Exhaustive small cyclic-group histograms for two-seed masks, balanced trees over odd composite orders, translation, and pointwise union bounds. Includes unbalanced-tree and conditional-translation counterexamples. The elliptic bad-pair fixture illustrates the masking argument; it is not an exhaustive genus-two bad-pair test. |

## Local circuits and resource accounting

Here `M`, `S`, and `Cgamma` denote clean modular multiply-, square-, and
constant-multiply accumulation calls. They are not single gates. `b` is the
auxiliary residue-word width, and `h` is the binary-tree height.

| Checker | Manuscript connection | What is checked and how to interpret it |
|---|---|---|
| `primitive_improvement.py` | Section 5.3, equations (38)–(39); Appendix D.1 | Constructs explicit NOT/CNOT/Toffoli networks for clean modular addition, doubling, multiply-, square-, and constant-multiply accumulation. Checks arbitrary canonical targets, inverse action, preserved sources, and scratch cleanup on the declared finite cases. These networks certify the local primitive conventions; a full sampler circuit is not constructed. |
| `verify_local_evaluator.py` | Reference evaluation for Sections 5.1 and 5.3; association rule in Appendix D.2 | Builds the uncached expression-tree schedule, checks modular values and reversal on 96 arbitrary-target cases, and records its word counts. Its 34,205 operations and attached reference ledgers are comparison data, not the cached schedule or current headline resource allocation. |
| `check_terminal_trace.py` | Section 4.3; reference schedule for Appendix D.2 | Checks the uncached `N + gamma*D` terminal trace: 985 multiply calls, 1,292 square calls, one constant-multiply call, six local words, and 96 arbitrary-target reversal cases. These are reference word-operation counts, not Toffoli counts or the cached terminal's cost. |
| `check_cached_evaluator.py` | Proposition 5.1; Appendix D.2 | Constructs the eight-word cached schedules and checks their costs: node `274M + 262S`, terminal `130M + 138S + Cgamma`, and scalar correction `638M + 776S` with five parity operations. Runs 120 arbitrary-target/reversal cases for each value interface and 120 recorded-phase cases. |
| `check_cached_symbolic.py` | Proposition 5.1; Appendix D.2 | Propagates every cached word operation as a sparse polynomial over the integers. Checks all five node outputs, the terminal at `gamma = 0, 1` with a linear extension to general `gamma`, five scalar-correction identities, preserved inputs, and zero scratch. This establishes identities for the recorded word traces without enumerating field values. |
| `check_cached_gate_integration.py` | Proposition 5.1; Appendix D.3 | Composes the cached word traces with the explicit gate primitives in 24 targeted basis cases at `(p,b) = (3,2)` and `(9,5)`. Checks wire allocation, padded words, arbitrary targets, inverse action, and scalar phase markers. The composite modulus 9 is deliberate. This is a local composition check, not exhaustive gate verification at cryptographic size. |
| `check_spooky_schedule.py` | Section 5.3, equation (42); Appendix C.1 | Simulates dependencies, vector allocation, and descending ghost elimination for tree heights 1–10. Checks `(4h-2)*2^h+3` moves, the stated upper move bound, and no remaining ghosts. Ghost phases are symbolic records; this program does not simulate quantum amplitudes. |
| `check_resource_ledger.py` | Sections 6.1 and 6.4–6.5; Table 2; Appendix E.1 | Recomputes the declared integer resource formulas from a freshly generated height result, including stage maxima, primitive costs, classical table counts, preparation, Fourier, character, and CRT accounting. Prime-count estimates use high-precision decimal arithmetic, checked separately by the rational height certificate. Results are analytic upper allocations; they are not empirical runtime measurements or a physical layout. |

## Main numerical checkpoints

These values identify the current construction, rather than the reference
schedules retained for comparison.

| Claim | Expected value | Primary output |
|---|---|---|
| Polynomial coefficient norms `(U1,U0,V1,V0,Z)` | `(7512, 9816, 577524, 621964, 60)` | `audit_arithmetic_results.json` |
| Terminal coefficient norms `(N,D)` | `(232, 64)` | `audit_arithmetic_results.json` |
| Coordinatewise root height for 16, 32, and 64 leaves | `7001373`, `140029735`, `2800596977` | `height_certificate_independent_results.json` |
| Cached local workspace | 8 residue words | `cached_evaluator_results.json` |
| Current whole-sampler logical-qubit allocations, windows 16 and 32 | `1923`, `1618` | `check_resource_ledger.json` |
| Matched Chen-derived logical-qubit allocation | `3063` | `check_resource_ledger.json` |
| Current window-16 Toffoli upper allocation | `1128039642233455592` | `check_resource_ledger.json` |

The Toffoli upper allocation excludes single-qubit rotation synthesis,
which the manuscript accounts for separately. The resource ledger retains
explicitly labeled reference data; those entries must not be substituted
for the current allocations above.

## MATLAB execution evidence

Separately from the Python checkers, the author supplied a MATLAB R2026a
Update 5 diary showing the fixed example passing through both a4 and a0
routes with Symbolic Math Toolbox 26.1. The recorded affine result is
[56,94,30,24] for both routes. See `verification/MATLAB_VALIDATION.md` and
`verification/MATLAB_validation_log.txt`. The 1,000 seeded pairs remain
Python tests. The diary contains no runtime source hashes and does not
extend the execution claim to Octave or the complete sampler.

## Coverage boundaries

The artifact does not contain a complete cryptographic-size sampler circuit,
a full gate-level implementation of Cantor arithmetic, a fault-tolerant
layout, or a generated list of the millions of auxiliary primes used by
the allocation estimate. It also does not include an end-to-end executable
of streaming CRT reconstruction and quotient-digit generation: the
current checks cover their height and allocation inputs, while Sections
5.4–5.5 and Appendix C supply the mathematical arguments.

The Legendre success guarantee concerns the exact uniform Fourier domain.
Canonical random-phase covariance is also checked on small rectangular
domains, but that is a different phase family. None of the finite fixtures
establishes a general Legendre guarantee for short rectangles.
