% demo_hec2_projective_add.m
% Weighted-projective Mumford coordinate convention:
% D   = (U1^(1) : U0^(1) : V1^(1) : V0^(1) : Z^(1))
% L   = (U1^(2) : U0^(2) : V1^(2) : V0^(2) : Z^(2))
% R=D+L = (U1^(3) : U0^(3) : V1^(3) : V0^(3) : Z^(3))
% In MATLAB variable names, the suffix _i denotes the divisor index i;
% it does not denote exponentiation.
% Requires Symbolic Math Toolbox. Run demo_hec2_projective_add from MATLAB.

clear;
clc;

%% 1. Field and curve
% y^2 = x^5 + c3*x^3 + c2*x^2 + c1*x + c0 over F_p.
% Construct large integers from strings before doing arithmetic.
p = sym('101');
c0 = sym('3');
c1 = sym('5');
c2 = sym('7');
c3 = sym('11');
curve = [c0 c1 c2 c3];

%% 2. Weighted-projective input D
U1_1 = sym('57');
U0_1 = sym('11');
V1_1 = sym('53');
V0_1 = sym('60');
Z_1  = sym('2');
D = [U1_1 U0_1 V1_1 V0_1 Z_1];

%% 3. Weighted-projective input L
U1_2 = sym('49');
U0_2 = sym('42');
V1_2 = sym('94');
V0_2 = sym('99');
Z_2  = sym('3');
L = [U1_2 U0_2 V1_2 V0_2 Z_2];

%% 4. Projective sum D + L
% Generic branch only: Z_1*Z_2*H*B3 must be nonzero modulo p.
[R, info] = hec2_projective_add(D, L, p, curve, 'a4');

U1_3 = R(1);
U0_3 = R(2);
V1_3 = R(3);
V0_3 = R(4);
Z_3 = R(5);
D_plus_L = [U1_3 U0_3 V1_3 V0_3 Z_3];

disp('D   = [U1_1 U0_1 V1_1 V0_1 Z_1]:');
disp(D);
disp('L   = [U1_2 U0_2 V1_2 V0_2 Z_2]:');
disp(L);
disp('D+L = [U1_3 U0_3 V1_3 V0_3 Z_3]:');
disp(D_plus_L);

%% 5. Affine recovery for inspecting the result
% u1^(3) = U1^(3)/(Z^(3))^2, u0^(3) = U0^(3)/(Z^(3))^2
% v1^(3) = V1^(3)/(Z^(3))^3, v0^(3) = V0^(3)/(Z^(3))^3
% Division means multiplication by the modular inverse in F_p.
affineR = hec2_projective_recover(R, p);
u1_3 = affineR(1);
u0_3 = affineR(2);
v1_3 = affineR(3);
v0_3 = affineR(4);
disp('Affine recovery [u1_3 u0_3 v1_3 v0_3]:');
disp(affineR);

%% 6. Check the supplied example
isOriginalExample = isequal(p, sym(101)) ...
    && isequal(curve, sym([3 5 7 11])) ...
    && isequal(D, sym([57 11 53 60 2])) ...
    && isequal(L, sym([49 42 94 99 3]));
if isOriginalExample
    assert(isequal(R, sym([81 53 65 52 68])));
    assert(isequal(affineR, sym([56 94 30 24])));
    disp('Reference example passed.');
else
    disp('Custom inputs: inspect the output or compare with a complete group law.');
end
