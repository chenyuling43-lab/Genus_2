# MATLAB source identity and Python correspondence

The final MATLAB source for this release is `matlab/hec2_projective_add.m`,
retained byte-for-byte from the supplied `genus2_reviewer_code(2)(3).zip`.
It is also byte-identical to the inspected `genus2_reviewer_code_fixed.zip`.
SHA-256: `b11edfe3833023e9e4185b59ee845e9f20f696dbc0adb0a71c076e0b1459b517`.

The manuscript archive's MATLAB file has different comments, formatting and
error-message splitting; the arithmetic formulas agree. This release does
not replace the baseline projective scale with the alternative optimized scale.

## Reviewed formula correspondence

`checks/check_matlab_algebra.py:matlab_add` uses the following aliases:

| MATLAB | Python |
|---|---|
| U1_1,U0_1,V1_1,V0_1,Z_1 | a,c,s,t,z |
| U1_2,U0_2,V1_2,V0_2,Z_2 | b,d,u,v,w |
| Z_1_sq,Z_2_sq,Z_1_cu,Z_2_cu,Z_1_four | z2,w2,z3,w3,z4 |
| dU1,sU1,dU0,sU0,dV1,dV0 | du1,su1,du0,su0,dv1,dv0 |
| Lambda,Z_3 | Lam,zout |

A,E,G,H,K,C2,C3,W,B0,B1,B2,B3,A5,Nq,Dq retain their mathematical meanings.
The a4 route uses A4=B2^2+2*B1*B3, the same Nr numerator and Dr=A^2*B3^2.
The a0 route uses A0=B0^2-c0*Lambda^2, Nr=A*A0 and Dr=B3^2*U0_1*U0_2.
Ns, Nt and all five final output formulas agree after the aliases above.
MATLAB caches Lambda2,Dq2,Dr2; Python expands those squares inline.

The MATLAB file uses four curve coefficients [c0,c1,c2,c3]; the test fixture
uses six [c0,c1,c2,c3,0,1]. Both a0 paths use only the constant coefficient.
MATLAB raises errors on exceptional cases; Python returns None for those
arithmetic-domain rejections. The transcription is not a complete clone of
MATLAB input validation: callers must supply valid inputs and a4/a0 methods.
It also does not emulate the MATLAB `info` structure or Symbolic Toolbox.

## Verification and identity

The checker verifies the source digest before running its calculations.
Its JSON records both the MATLAB and transcription SHA-256 digests; the
runner compares this metadata as well as the mathematical outputs against
expected/. The runner report also hashes all MATLAB .m inputs.
These checks prevent an unnoticed source-version mismatch, but a hash alone
does not prove formula equivalence. Any source edit requires renewed review,
a deliberate digest update and fresh mathematical verification.

The fixed a4 output is [81,53,65,52,68] over F_101; both routes decode to
[56,94,30,24]. The seeded suite checks 1000 input pairs, comparing each
accepted route against the independent Cantor reference. The expected counts
are 905 accepted and 95 generic-branch rejections per route.
The seeded results establish Python transcription checks. A separate
author-supplied diary now records successful MATLAB execution of the fixed
example through a4 and a0 on R2026a Update 5; see
`verification/MATLAB_VALIDATION.md` at the package root for scope and provenance.
MATLAB/Octave was not available in the review environment; Octave is untested.

## Manifest

artifact_manifest.json is regenerated from all actual packaged regular files,
excluding itself. Removed CHANGELOG.md and code_revision_notes.md are not
invented or restored. Paths, byte sizes and SHA-256 digests describe this
release. Stored MATLAB results and the full-suite report are refreshed.
