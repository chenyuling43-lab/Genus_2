# MATLAB arithmetic reference

The three files illustrate generic divisor addition in weighted-projective
coordinates. They implement the direct interpolation construction associated
with Sections 4.3 and 5.1 and Appendix A. The cached evaluation schedule and
its resource counts are checked separately by the Python programs.

## Run the example

MATLAB with Symbolic Math Toolbox is required. Put these three files on the
MATLAB path, or open this directory as the working directory, and run:

```matlab
demo_hec2_projective_add
```

The demo uses the curve
`y^2 = x^5 + 11*x^3 + 7*x^2 + 5*x + 3` over the field of order 101.
Its assertions check the following results:

| Quantity | Expected value |
|---|---|
| Input `D` | `[57 11 53 60 2]` |
| Input `L` | `[49 42 94 99 3]` |
| Projective sum, default `a4` route | `[81 53 65 52 68]` |
| Affine coefficients `[u1 u0 v1 v0]` | `[56 94 30 24]` |

The projective tuple depends on the chosen scale. Compare affine
coefficients when comparing the two recovery routes or another implementation.
Large integer inputs must be constructed from strings, such as
`sym('170141183460469231731687303715884105727')`, before any arithmetic.
Converting a rounded double to `sym` cannot recover discarded digits.

## Interfaces and domain

- `hec2_projective_add(D, L, p, curve, rMethod)` returns `[U1 U0 V1 V0 Z]`
  and an `info` structure containing selected intermediate values. The
  coordinate weights are `(2,2,3,3,1)`. Curve coefficients are supplied in
  ascending order as `[c0 c1 c2 c3]`; the quartic coefficient is zero.
- `rMethod = 'a4'` is the default. It recovers the constant coefficient of
  the output Mumford polynomial from the quartic coefficient identity.
  `rMethod = 'a0'` uses the constant coefficient identity and additionally
  requires `U0_1*U0_2` to be nonzero modulo `p`.
- `hec2_projective_recover(P, p)` returns `[u1 u0 v1 v0]` using
  `u_i = U_i/Z^2` and `v_i = V_i/Z^3` in the finite field. It performs
  one modular inversion for result inspection.

The caller must supply an odd prime modulus and valid degree-two divisors
on one smooth curve. The addition routine does not test these assumptions.
It rejects zero input scales and singular generic interpolation branches;
it does not implement the complete Cantor case distinction. In particular,
its arithmetic is not the full masked quantum sampler, and its intermediate
storage does not justify the eight-word bound in Proposition 5.1.

## Verification status

`checks/check_matlab_algebra.py` is an exact Python transcription of these
equations. It checks both recovery routes against independent Cantor
arithmetic on the fixed example and on 1,000 seeded input pairs over the
field of order 101. For each route, 905 generic pairs are compared and 95
singular pairs are rejected. Its JSON output records those counts.

The author-supplied MATLAB diary records successful execution of the fixed
example through both a4 and a0 routes on MATLAB R2026a Update 5 with Symbolic
Math Toolbox 26.1. See `verification/MATLAB_VALIDATION.md` and
`verification/MATLAB_validation_log.txt` (paths relative to the package root).
The 1,000-pair comparisons above were run in Python, not MATLAB. The diary
supports fixed-example execution only; Octave has not been tested.
