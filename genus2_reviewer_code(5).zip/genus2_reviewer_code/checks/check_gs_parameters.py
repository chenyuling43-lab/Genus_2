#!/usr/bin/env python3
"""Certify the displayed transformed curve and subgroup parameters.

The subgroup order is checked using the supplied Pocklington certificate.
Cantor arithmetic checks generator membership and annihilation. The genus-two
Weil interval then determines the full Jacobian cardinality. The source-model
coordinate transformation is outside this check's scope.
"""

import math

import cantor_reference as reference
from artifact_io import run_check
from verify_subgroup_prime_certificate import verify as verify_subgroup_prime


def check():
    """Certify the displayed curve, generator, subgroup order, and cardinality."""
    q = 2**127 - 1
    r = 2**250 - int("334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD", 16)
    reference.p = q
    f = [
        int(x, 16)
        for x in [
            "3AF79604317A895BB28139B4DDD66D56",
            "4761178EC206F6DB2E90B2BF4913BE47",
            "432B709D2D5801982F927BB531F0F535",
            "00D26A12F16AE9D00045BB92C5382A8E",
            "0",
            "1",
        ]
    ]
    P = (
        [
            int("384CB21DBD5E1F600F3FE0E336182F14", 16),
            int("3CB88102BCDD5A7AAA402188B6783790", 16),
            1,
        ],
        [
            int("4F4AB1A434DFCBE8FD26C203D18D54F4", 16),
            int("444569AF177A9C1C721736D8F288C942", 16),
        ],
    )
    derivative = [j * f[j] for j in range(1, len(f))]
    assert len(reference.xgcd(f, derivative)[0]) == 1
    assert not reference.div(reference.sub(f, reference.mul(P[1], P[1])), P[0])[1]
    identity = ([1], [])
    assert P != identity
    acc, multiple, scalar = (identity, P, r)
    while scalar:
        if scalar & 1:
            acc = reference.cantor(acc, multiple, f)
        scalar >>= 1
        if scalar:
            multiple = reference.cantor(multiple, multiple, f)
    assert acc == identity
    # Lucas--Lehmer applies because the Mersenne exponent 127 is prime.
    assert all((127 % d for d in range(2, math.isqrt(127) + 1)))
    ll = 4
    for _ in range(125):
        ll = (ll * ll - 2) % q
    assert ll == 0
    prime_certificate = verify_subgroup_prime()
    assert int(prime_certificate["subgroup_order"]) == r
    assert prime_certificate["deterministic_primality_verified"]
    # A nonidentity generator killed by prime r has exact order r.
    # The conservative Weil interval contains exactly one multiple of r.
    sqrt_upper = math.isqrt(q) + 1
    center = q * q + 6 * q + 1
    radius = 4 * (q + 1) * sqrt_upper
    lower, upper = (center - radius, center + radius)
    quotient_min = (lower + r - 1) // r
    quotient_max = upper // r
    assert quotient_min == quotient_max == 16
    jacobian_cardinality = 16 * r
    assert lower <= jacobian_cardinality <= upper
    result = dict(
        q=str(q),
        r=str(r),
        field_bits=q.bit_length(),
        subgroup_bits=r.bit_length(),
        curve_squarefree=True,
        displayed_generator_membership=True,
        displayed_generator_nonidentity=True,
        r_times_generator_is_identity=True,
        exact_generator_order=str(r),
        lucas_lehmer_q_prime=True,
        r_primality_status="deterministically proved by recursive Pocklington certificate",
        r_primality_certificate_nodes=prime_certificate[
            "certified_primes_including_leaves"
        ],
        weil_interval_lower=str(lower),
        weil_interval_upper=str(upper),
        weil_interval_sqrt_upper=str(sqrt_upper),
        weil_interval_minimum_cofactor=quotient_min,
        weil_interval_maximum_cofactor=quotient_max,
        jacobian_cardinality=str(jacobian_cardinality),
        jacobian_cofactor=16,
        jacobian_cardinality_status="proved: r divides #J and the integer Weil interval contains only the multiple 16r",
        coordinate_transformation_status="displayed transformed model checked; source-model transformation not independently checked",
    )
    return result


if __name__ == "__main__":
    run_check(check, "gs_parameter_results.json")
