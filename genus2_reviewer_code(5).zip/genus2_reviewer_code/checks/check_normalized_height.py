#!/usr/bin/env python3
"""Compute normalized-leaf degrees and componentwise integer height bounds.

The first calculation substitutes Z1 = Z2 = 1 into the exact sparse model.
The second propagates coefficient bounds through the addition tree and
reports the original Decimal-based prime-allocation estimates. The separate
height-certificate check certifies those allocations using rational bounds.
"""

from collections import defaultdict
from decimal import Decimal, ROUND_CEILING, localcontext
import math

from artifact_io import run_check
from polynomial_model import D, N, out


def norm_bits(polynomial):
    """Return the ceiling of log2 of the coefficient l1 norm, exactly."""
    return (sum(map(abs, polynomial.values())) - 1).bit_length()


def poly_bits(polynomial, bits):
    """Bound log2 |P| for a pointwise vector of input bit bounds."""
    return norm_bits(polynomial) + max(
        sum(exponent * bound for exponent, bound in zip(exponents, bits))
        for exponents in polynomial
    )


def normalized_leaf_rows():
    """Report exact norms and degrees after setting both input scales to one."""
    rows = []
    for name, polynomial, weight in zip(
        ["U1", "U0", "V1", "V0", "Z"], out, [2, 2, 3, 3, 1]
    ):
        coefficients = defaultdict(int)
        for exponents, coefficient in polynomial.items():
            coefficients[exponents[:4] + exponents[5:9]] += coefficient
        coefficients = {
            exponents: coefficient
            for exponents, coefficient in coefficients.items()
            if coefficient
        }
        degree = max(map(sum, coefficients))
        norm = sum(map(abs, coefficients.values()))
        rows.append(
            dict(
                coordinate=name,
                degree=degree,
                weight=weight,
                monomials=len(coefficients),
                norm=norm,
                weighted_degree_ratio=degree / weight,
                log_constant=math.log2(norm) / weight,
            )
        )
    return rows


def componentwise_parameters():
    """Evaluate the four published window sizes with 70-digit arithmetic."""
    parameters = []
    with localcontext() as context:
        context.prec = 70
        ln2 = Decimal(2).ln()
        for n, window, leaves in [
            (127, 8, 64),
            (127, 16, 32),
            (127, 24, 32),
            (127, 32, 16),
        ]:
            height = leaves.bit_length() - 1
            bits = [n, n, n, n, 0]
            history = [bits]
            for _ in range(1, height):
                bits = [poly_bits(polynomial, bits * 2) for polynomial in out]
                history.append(bits)
            numerator_bits = poly_bits(N, bits * 2)
            denominator_bits = poly_bits(D, bits * 2)
            H = max(numerator_bits, n + denominator_bits) + 1
            candidates = []
            for b in range(22, 35):
                x = Decimal(2) ** b
                lower = x / ln2 * (1 - Decimal(".2") / (b * ln2) ** 2) - 1 - n
                if lower > H + 2:
                    k = int(
                        (x / (b * ln2 - Decimal("1.1"))).to_integral_value(
                            rounding=ROUND_CEILING
                        )
                    )
                    log_k = (k - 1).bit_length()
                    accumulator_bits = 2 * log_k + 4
                    peak = 500 + n + accumulator_bits + (5 * (height + 2) + 11) * b + 4
                    candidates.append(
                        {
                            "b": b,
                            "K": k,
                            "a_fp": accumulator_bits,
                            "reconstruction_peak": peak,
                            "margin": str(lower - H - 2),
                        }
                    )
            parameters.append(
                {
                    "window": window,
                    "leaves": leaves,
                    "height": height,
                    "coordinate_bit_history": history,
                    "N_bits": numerator_bits,
                    "D_bits": denominator_bits,
                    "H": H,
                    "best": candidates[0],
                }
            )
    return parameters


def check():
    """Return both normalized-leaf and componentwise-height calculations."""
    return {
        "normalized_leaf_polynomials": normalized_leaf_rows(),
        "componentwise_height_parameters": componentwise_parameters(),
    }


if __name__ == "__main__":
    run_check(check, "normalized_height_results.json")
