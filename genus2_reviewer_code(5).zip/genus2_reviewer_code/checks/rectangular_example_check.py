"""Verify the F_5 rectangular-domain example with exact arithmetic.

Polynomial and extension-field operations are implemented here independently
of the Cantor reference module. Coefficients are in ascending degree order.
"""

from fractions import Fraction
from itertools import product

from artifact_io import run_check

Q = 5
CURVE = [3, 0, 2, 1, 0, 1]


def trim(coefficients):
    result = [value % Q for value in coefficients]
    while result and result[-1] == 0:
        result.pop()
    return result


def multiply(a, b):
    result = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            result[i + j] += x * y
    return trim(result)


def subtract(a, b):
    return trim(
        [
            (a[i] if i < len(a) else 0) - (b[i] if i < len(b) else 0)
            for i in range(max(len(a), len(b)))
        ]
    )


def remainder(a, b):
    a, b = trim(a), trim(b)
    while len(a) >= len(b):
        shift = len(a) - len(b)
        leading_ratio = a[-1] * pow(b[-1], -1, Q) % Q
        a = subtract(a, [0] * shift + [leading_ratio * value for value in b])
    return a


def polynomial_gcd(a, b):
    while b:
        a, b = b, remainder(a, b)
    return trim(a)


# F_25 = F_5[t]/(t^2 - 2); 2 is a nonsquare in F_5.
def extension_add(x, y):
    return ((x[0] + y[0]) % Q, (x[1] + y[1]) % Q)


def extension_multiply(x, y):
    return (
        (x[0] * y[0] + 2 * x[1] * y[1]) % Q,
        (x[0] * y[1] + x[1] * y[0]) % Q,
    )


def extension_evaluate(x):
    result, power = (0, 0), (1, 0)
    for coefficient in CURVE:
        result = extension_add(result, extension_multiply((coefficient, 0), power))
        power = extension_multiply(power, x)
    return result


def check():
    derivative = [i * CURVE[i] for i in range(1, len(CURVE))]
    assert len(polynomial_gcd(CURVE, derivative)) == 1

    # Enumerate all reduced Mumford pairs, including the identity.
    classes = [([1], [])]
    for degree in (1, 2):
        for u_coefficients in product(range(Q), repeat=degree):
            u = list(u_coefficients) + [1]
            for v_coefficients in product(range(Q), repeat=degree):
                v = trim(v_coefficients)
                if not remainder(subtract(CURVE, multiply(v, v)), u):
                    classes.append((u, v))
    lower_degree_count = sum(len(u) < 3 for u, v in classes)
    fiber_counts = [
        sum(len(u) == 3 and u[0] == a for u, v in classes) for a in range(Q)
    ]
    assert ([3, 1], [1]) in classes and ([3, 1], [4]) in classes

    n1 = 1 + sum(
        1
        for x, y in product(range(Q), repeat=2)
        if (y * y - sum(c * x**i for i, c in enumerate(CURVE))) % Q == 0
    )
    extension_elements = list(product(range(Q), repeat=2))
    n2 = 1 + sum(
        extension_multiply(y, y) == extension_evaluate(x)
        for x, y in product(extension_elements, repeat=2)
    )
    jacobian_order = (n1 * n1 + n2) // 2 - Q
    assert jacobian_order == len(classes) == 23
    assert all(jacobian_order % divisor for divisor in range(2, 5))

    # Lexicographic input order: (0,0), (0,1), (1,0), (1,1).
    inputs = list(product((0, 1), repeat=2))
    values = ("O", "-P", "P", "O")
    full_distribution = {}
    for u, v in inputs:
        amplitude_sums = {
            value: sum(
                (-1) ** (u * a + v * b)
                for (a, b), output in zip(inputs, values)
                if output == value
            )
            for value in set(values)
        }
        full_distribution[str((u, v))] = Fraction(
            sum(amplitude**2 for amplitude in amplitude_sums.values()), 16
        )
    variation = (
        sum(
            abs((1 if frequency == (0, 0) else 0) - full_distribution[str(frequency)])
            for frequency in inputs
        )
        / 2
    )

    nonzero_squares = {x * x % Q for x in range(1, Q)}

    def sign(value):
        return 1 if value % Q == 0 or value % Q in nonzero_squares else -1

    means = [
        Fraction(
            lower_degree_count
            + sum(fiber_counts[a] * sign(a + shift) for a in range(Q)),
            jacobian_order,
        )
        for shift in range(Q)
    ]
    average_success = sum(1 - mean * mean for mean in means) / Q
    assert (n1, n2, lower_degree_count, fiber_counts) == (5, 31, 5, [0, 4, 4, 2, 8])
    assert list(full_distribution.values()) == [
        Fraction(3, 8),
        Fraction(1, 8),
        Fraction(1, 8),
        Fraction(3, 8),
    ]
    assert variation == Fraction(5, 8) and average_success == Fraction(2192, 2645)
    return {
        "curve_coefficients_ascending": CURVE,
        "squarefree": True,
        "C_F5": n1,
        "C_F25": n2,
        "J_F5": jacobian_order,
        "lower_degree_count": lower_degree_count,
        "fiber_counts_u0": fiber_counts,
        "full_output_rectangular_distribution": {
            k: str(v) for k, v in full_distribution.items()
        },
        "rectangular_total_variation": str(variation),
        "exact_domain_shift_means": [str(mean) for mean in means],
        "exact_domain_average_success": str(average_success),
        "scope": "Exhaustive finite-field and Mumford enumeration, exact rational distributions; not a quantum gate simulation.",
    }


if __name__ == "__main__":
    run_check(check, "rectangular_example_check.json")
