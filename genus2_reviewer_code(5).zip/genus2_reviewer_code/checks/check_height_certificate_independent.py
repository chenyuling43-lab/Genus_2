#!/usr/bin/env python3
"""Certify componentwise heights and prime allocation by exact arithmetic.

This check recomputes coefficient-norm ceilings and support maxima from the
sparse integer model. Rational bounds enclose ln(2), so the finite prime
allocations use neither floating-point arithmetic nor probable-prime tests.
"""

from fractions import Fraction
from math import prod

from artifact_io import run_check
from polynomial_model import D, N, out


def ceil_log2(value):
    """Return the least exponent e for which value <= 2**e."""
    assert isinstance(value, int) and value >= 1
    exponent = 0
    power = 1
    while power < value:
        power *= 2
        exponent += 1
    return exponent


def bound_for_polynomial(polynomial, vector):
    """Prove |P(x)| <= 2**result under |x_i| <= 2**vector[i]."""
    assert polynomial and all(coefficient != 0 for coefficient in polynomial.values())
    assert len(vector) == 10 and all(value >= 0 for value in vector)
    norm = sum(abs(coefficient) for coefficient in polynomial.values())
    monomial_bounds = []
    for exponents in polynomial:
        assert len(exponents) == 10
        degree_bound = 0
        for position in range(10):
            degree_bound += exponents[position] * vector[position]
        monomial_bounds.append(degree_bound)
    return ceil_log2(norm) + max(monomial_bounds)


def logarithm_enclosure():
    """Enclose ln(2) using 100 terms of 2*sum(3**(-2k-1)/(2k+1))."""
    terms = 100
    lower = sum(
        (Fraction(2, (2 * k + 1) * 3 ** (2 * k + 1)) for k in range(terms)),
        Fraction(0),
    )
    # Replace each tail denominator by 2*terms+1, then sum the geometric tail.
    upper = lower + Fraction(2, (2 * terms + 1) * 3 ** (2 * terms + 1)) / (
        1 - Fraction(1, 9)
    )
    assert 0 < upper - lower < Fraction(1, 10**96)
    return lower, upper


def fraction_ceil(value):
    """Return the exact ceiling of a Fraction."""
    return -((-value.numerator) // value.denominator)


def allocation(n, height, H, b, ln2_lower, ln2_upper):
    """Certify a candidate modulus width and bound its reconstruction workspace."""
    x = 2**b
    # Dusart's theta(x) lower bound, in bits, with 2 and q removed.
    # Each rational factor is a lower bound for its positive counterpart.
    prime_bits_lower = (
        Fraction(x, 1) / ln2_upper * (1 - Fraction(1, 5) / (b * b * ln2_lower**2))
        - 1
        - n
    )
    valid = x >= 3594641 and prime_bits_lower > H + 2
    k_upper = fraction_ceil(Fraction(x, 1) / (b * ln2_lower - Fraction(11, 10)))
    ell = ceil_log2(k_upper)
    accumulator_bits = 2 * ell + 4
    width = 500 + n + accumulator_bits + (5 * (height + 2) + 11) * b + 4
    return dict(
        b=b,
        K=k_upper,
        a_fp=accumulator_bits,
        reconstruction_peak=width,
        certified=valid,
        prime_bits_margin_floor=(prime_bits_lower - H - 2).__floor__(),
    )


def check():
    """Verify all three published allocations and the exceptional dummy tuple."""
    polynomials = out
    terminal = [N, D]
    ln2_lower, ln2_upper = logarithm_enclosure()
    expected = {
        64: (2800596977, 31, 105333026, 58, 2270),
        32: (140029735, 27, 7619525, 50, 1923),
        16: (7001373, 23, 565180, 44, 1618),
    }
    records = []
    for leaves, (
        expected_H,
        expected_b,
        expected_K,
        expected_afp,
        expected_width,
    ) in expected.items():
        height = ceil_log2(leaves)
        assert 2**height == leaves
        vector = [127, 127, 127, 127, 0]
        history = [vector]
        for _ in range(1, height):
            vector = [
                bound_for_polynomial(polynomial, vector + vector)
                for polynomial in polynomials
            ]
            history.append(vector)
        numerator_bits, denominator_bits = [
            bound_for_polynomial(polynomial, vector + vector) for polynomial in terminal
        ]
        H = 1 + max(numerator_bits, 127 + denominator_bits)
        assert H == expected_H
        candidates = [
            allocation(127, height, H, b, ln2_lower, ln2_upper) for b in range(22, 35)
        ]
        chosen = next(record for record in candidates if record["certified"])
        assert (
            chosen["b"],
            chosen["K"],
            chosen["a_fp"],
            chosen["reconstruction_peak"],
        ) == (expected_b, expected_K, expected_afp, expected_width)
        b = chosen["b"]
        accumulator_bits = chosen["a_fp"]
        width = chosen["reconstruction_peak"]
        competitors = {
            "large_modulus_update": 500 + 2 * 127 + accumulator_bits + 2 * b + 20,
            "completed_character": 500 + accumulator_bits + 6 * 127 + 12,
            "input_preparation_and_fourier": 3 * 250 + 5,
        }
        assert all(value <= width for value in competitors.values())
        records.append(
            dict(
                leaves=leaves,
                height=height,
                coordinate_bit_history=history,
                N_bits=numerator_bits,
                D_bits=denominator_bits,
                H=H,
                allocation=chosen,
                competing_stage_widths=competitors,
                excluded_previous_b=allocation(
                    127, height, H, b - 1, ln2_lower, ln2_upper
                ),
            )
        )

    # This pointwise integer test does not use a curve equation or generic branch.
    dummy = (0, 0, 0, 0, 1) * 2
    for polynomial in polynomials + terminal:
        result = sum(
            coefficient
            * prod(value**exponent for value, exponent in zip(dummy, exponents))
            for exponents, coefficient in polynomial.items()
        )
        assert result == 0

    return {
        "method": "Exact sparse integer coefficients; independent support/norm recurrence; rational ln(2) enclosure from 100 positive series terms",
        "primitive_workspace_assumption": "A_prim(b)<=b+4, independently certified by the separate gate-level primitive verification",
        "coordinate_norm_bits": [
            ceil_log2(sum(abs(c) for c in polynomial.values()))
            for polynomial in polynomials
        ],
        "terminal_norm_bits": [
            ceil_log2(sum(abs(c) for c in polynomial.values()))
            for polynomial in terminal
        ],
        "leaf_bound": "|U1|,|U0|,|V1|,|V0|<2^n, Z=1; recurrence uses weak bounds <=2^v",
        "root_strictness": "|N|<=2^BN and |gamma D|<2^(n+BD); hence |N+gamma D|<2^(1+max(BN,n+BD))",
        "dummy_check": True,
        "scope": "Every integer tuple in the coordinate box, including exceptional and dummy values; gamma is any canonical integer in [0,q). This is not an improvement to the tree asymptotic exponent.",
        "records": records,
    }


if __name__ == "__main__":
    run_check(check, "height_certificate_independent_results.json")
