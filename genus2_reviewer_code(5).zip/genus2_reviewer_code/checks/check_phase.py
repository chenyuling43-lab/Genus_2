"""Exact checks of Jacobi branches, reversible permutations, and correlations."""

from itertools import product
from fractions import Fraction
from artifact_io import run_check
import math


def primes(n):
    """Return the odd primes at most n for the finite test domain."""
    return [
        p for p in range(3, n + 1, 2) if all(p % d for d in range(2, math.isqrt(p) + 1))
    ]


def e2(b):
    """Return the sign bit of the supplementary law for (2/b)."""
    return int(b % 8 in (3, 5))


def step(a, b, j):
    """Advance the Jacobi state and return the branch code used for reversal."""
    if not a:
        return a, b, j, 0
    if a % 2 == 0:
        return a // 2, b, j ^ e2(b), 1
    if a >= b:
        return (a - b) // 2, b, j ^ e2(b), 2
    return (b - a) // 2, a, j ^ int(a % 4 == b % 4 == 3) ^ e2(a), 3


def perm(a, b, j, code, n, reverse=False):
    """Apply a fixed branch as a permutation of the full n-bit word space."""
    mask = (1 << n) - 1
    rrot = lambda a: (a >> 1) | ((a & 1) << (n - 1))
    lrot = lambda a: ((a << 1) & mask) | (a >> (n - 1))

    def sign(a, b):
        return (
            e2(b)
            if code in (1, 2)
            else (int(a % 4 == b % 4 == 3) ^ e2(a) if code == 3 else 0)
        )

    if reverse:
        if code:
            a = lrot(a)
        if code == 2:
            a = (a + b) & mask
        if code == 3:
            a, b = b, a
            b = (b + a) & mask
        j ^= sign(a, b)
    else:
        j ^= sign(a, b)
        if code == 2:
            a = (a - b) & mask
        if code == 3:
            b = (b - a) & mask
            a, b = b, a
        if code:
            a = rrot(a)
    return a, b, j


def check():
    """Exhaust finite Jacobi, permutation, and ancillary-bit cases at stated sizes."""
    count = 0
    maxsteps = {}
    for q in primes(2000):
        n = q.bit_length()
        maxact = 0
        for Y in range(q):
            a, b, j = Y, q, 0
            trace = []
            for _ in range(2 * n + 1):
                aa, bb, jj, code = step(a, b, j)
                assert perm(a, b, j, code, n) == (aa, bb, jj)
                if aa:
                    assert aa * bb <= a * b / 2
                trace.append(code)
                a, b, j = aa, bb, jj
            assert a == 0 and (b == 1 or Y == 0)
            assert (-1) ** j == (
                1 if Y == 0 else (1 if pow(Y, (q - 1) // 2, q) == 1 else -1)
            ), (q, Y)
            maxact = max(maxact, sum(c != 0 for c in trace))
            for code in trace[::-1]:
                a, b, j = perm(a, b, j, code, n, True)
                assert step(a, b, j)[3] == code
            assert (a, b, j) == (Y, q, 0)
            count += 1
        maxsteps[str(q)] = maxact
    # Arithmetic controlled-permutation forward/reverse is a full-binary-space identity.
    perms = 0
    for n in range(2, 6):
        for a, b, j, c in product(range(1 << n), range(1 << n), range(2), range(4)):
            out = perm(a, b, j, c, n)
            assert perm(*out, c, n, True) == (a, b, j)
            perms += 1
    # Dirty ladder: all controls, target bits, and dirty assignments through n=7.
    ladder_cases = 0
    for n in range(3, 8):
        for ctl in product((0, 1), repeat=n):
            for dirty in product((0, 1), repeat=n - 2):
                for target in (0, 1):
                    d = list(dirty)
                    t = target
                    for omit in (False, True):
                        if not omit:
                            d[0] ^= ctl[0] & ctl[1]
                        for i in range(1, n - 2):
                            d[i] ^= d[i - 1] & ctl[i + 1]
                        t ^= d[n - 3] & ctl[n - 1]
                        for i in range(n - 3, 0, -1):
                            d[i] ^= d[i - 1] & ctl[i + 1]
                        if not omit:
                            d[0] ^= ctl[0] & ctl[1]
                    assert d == list(dirty) and t == (target ^ int(all(ctl)))
                    ladder_cases += 1
    # Two-bit explicit controlled modular-adder and comparator constructions.
    small_cases = 0
    for a, b, d, t in product(range(4), range(4), (0, 1), (0, 1)):
        a0, a1 = a & 1, a >> 1
        b0, b1 = b & 1, b >> 1
        # Controlled add b+=d*a mod4: one CCCNOT and two Toffolis.
        out0 = b0 ^ (d & a0)
        out1 = b1 ^ (d & a1) ^ (d & a0 & b0)
        assert out0 + 2 * out1 == (b + d * a) % 4
        # Comparator using four Toffolis, XOR target, one clean temporary.
        carry = (1 - a0) & b0
        out = t ^ ((1 - a1) & b1) ^ ((1 - (a1 ^ b1)) & carry)
        carry ^= (1 - a0) & b0
        assert not carry and out == (t ^ int(a < b))
        small_cases += 1
    # Field-shift correlation identity, all a,b for primes through 31.
    corr = 0
    for q in primes(31):
        chi = lambda x: (
            0 if x % q == 0 else (1 if pow(x % q, (q - 1) // 2, q) == 1 else -1)
        )
        sq = lambda x: chi(x) + (x % q == 0)
        for a, b in product(range(q), repeat=2):
            actual = Fraction(sum(sq(a + g) * sq(b + g) for g in range(q)), q)
            expected = 1 if a == b else Fraction(-1 + chi(a - b) + chi(b - a), q)
            assert actual == expected
            corr += 1
    # Counterexample to dimension-free collision bound.
    v = (1, 1, -1, -1)
    w = tuple(Fraction(x, 4) for x in v)
    hashes = list(product((1, -1), repeat=4)) + [v]
    pfull = sum(x * x for x in w)
    pbit = (
        sum(
            sum(w[i] * w[j] for i, j in product(range(4), repeat=2) if h[i] == h[j])
            for h in hashes
        )
        / 17
    )
    assert pfull == Fraction(1, 4) and pbit == Fraction(5, 34)
    report = {
        "canonical_Jacobi_inputs_checked": count,
        "maximum_prime_checked": 1999,
        "max_active_macros_minus_2n": max(
            v - 2 * int(k).bit_length() for k, v in maxsteps.items()
        ),
        "full_binary_permutation_cases": perms,
        "dirty_ladder_cases": ladder_cases,
        "two_bit_arithmetic_cases": small_cases,
        "exact_character_correlations": corr,
        "collision_counterexample": {"p_full": str(pfull), "p_bit": str(pbit)},
        "Jacobi_gate_bound_recommended": "72*n*(2*n+1)",
        "Jacobi_gate_bound_at_127": 72 * 127 * 255,
        "scope": "Exact integer checks of branch algorithms, local permutations, dirty ladders and stated examples; no complete quantum circuit synthesis.",
    }
    return report


if __name__ == "__main__":
    run_check(check, "check_phase.json")
