#!/usr/bin/env python3
"""Certify the literal genus-two polynomial evaluator at the word level.

Words 0--9 hold the two input tuples; words 10--14 are distinct output
accumulators; words 15--22 are initially zero workspace. A trace entry is
(kind, target, sources, sign), with kind M, S, or A denoting multiplication,
squaring, or linear accumulation modulo a public modulus. Sources are preserved.

The checks cover exact operation counts, workspace use, arbitrary output
accumulators, and reversal on deterministic examples. This module does not
construct a quantum gate network. Only the Python standard library is required."""

from collections import Counter
from functools import lru_cache
import math
import random

from artifact_io import run_check


class Expr(tuple):
    """Immutable expression tree for the polynomial word compiler."""

    def __add__(self, other):
        return Expr(("add", self, other))

    def __sub__(self, other):
        return Expr(("sub", self, other))

    def __mul__(self, other):
        return Expr(("mul", self, other))

    def __rmul__(self, scalar):
        return Expr(("scale", scalar, self))

    def __pow__(self, power):
        if power == 2:
            return Expr(("sq", self))
        if power == 3:
            return (self**2) * self
        if power == 4:
            return (self**2) ** 2
        raise ValueError(power)


def var(index):
    """Return an expression referring to the input or cached word at index."""
    return Expr(("var", index))


@lru_cache(None)
def bound(expr, scalar=1):
    """Return (temporary words beyond target, M, S, A)."""
    kind = expr[0]
    if kind == "scale":
        return bound(expr[2], scalar * expr[1])
    if kind == "var":
        return (0, 0, 0, abs(scalar))
    if kind in ("add", "sub"):
        left, right = (bound(child, scalar) for child in expr[1:])
        return (max(left[0], right[0]), *(left[j] + right[j] for j in range(1, 4)))
    if kind == "sq":
        child = expr[1]
        if child[0] == "var":
            return (0, 0, abs(scalar), 0)
        words, mul, sq, add = bound(child)
        return (words + 1, 2 * mul, 2 * sq + abs(scalar), 2 * add)
    if kind == "mul":
        left, right = expr[1:]
        nl, nr = left[0] != "var", right[0] != "var"
        bl = bound(left) if nl else (0, 0, 0, 0)
        br = bound(right) if nr else (0, 0, 0, 0)
        left_first = max(nl + bl[0], nl + nr + br[0])
        right_first = max(nr + br[0], nl + nr + bl[0])
        return (
            min(left_first, right_first),
            2 * (bl[1] + br[1]) + abs(scalar),
            2 * (bl[2] + br[2]),
            2 * (bl[3] + br[3]),
        )
    raise ValueError(kind)


def expressions():
    """Return the five output expressions and terminal numerator/denominator."""
    a, c, s, u, z1, b, d, t, v, z2 = map(var, range(10))
    K = z1 * z2
    K2 = K**2
    du0 = d * z1**2 - c * z2**2
    du1 = b * z1**2 - a * z2**2
    su1 = b * z1**2 + a * z2**2
    dv0 = v * z1**3 - u * z2**3
    dv1 = t * z1**3 - s * z2**3
    C = a * d - c * b
    R = du0**2 - C * du1
    E = dv1 * du0 - dv0 * du1
    L = du0 * dv0 - C * dv1
    N = (
        K2 * L**2
        + 2 * (a * z2**2 * L * E)
        + (a * b - du0) * E**2
        - 2 * (s * z2**3 * R * E)
        + su1 * K2 * R**2
    )
    D = K2 * E**2
    A = 2 * (K2 * L * E) + su1 * E**2 - K**4 * R**2
    T = L * E - K2 * R**2
    B1 = s * z2**3 * R - a * z2**2 * L - (a * b + c * z2**2) * E
    B0 = u * z2**3 * R - c * z2**2 * L - c * b * E
    return (
        [
            A * R**2,
            N * R**2,
            R**2 * (A * T - E**2 * (B1 * E + N)),
            R**2 * (N * T - B0 * E**3),
            K * R * E,
        ],
        N,
        D,
    )


class Compiler:
    """Compile expression accumulation into a literal word-operation trace."""

    def __init__(self):
        self.trace = []
        self.free = list(range(22, 14, -1))
        self.live = 0
        self.peak = 0

    def take(self):
        if not self.free:
            raise AssertionError("eight-word allowance exceeded")
        word = self.free.pop()
        self.live += 1
        self.peak = max(self.peak, self.live)
        return word

    def release(self, word):
        self.live -= 1
        self.free.append(word)

    def emit(self, kind, target, sources, scalar):
        for _ in range(abs(scalar)):
            self.trace.append((kind, target, tuple(sources), 1 if scalar >= 0 else -1))

    def undo(self, trace):
        self.trace.extend((k, t, s, -sign) for k, t, s, sign in reversed(trace))

    def accumulate(self, expr, target, scalar=1):
        kind = expr[0]
        if kind == "scale":
            self.accumulate(expr[2], target, scalar * expr[1])
            return
        if kind == "var":
            self.emit("A", target, [expr[1]], scalar)
            return
        if kind in ("add", "sub"):
            self.accumulate(expr[1], target, scalar)
            self.accumulate(expr[2], target, scalar if kind == "add" else -scalar)
            return
        if kind == "sq":
            child = expr[1]
            if child[0] == "var":
                self.emit("S", target, [child[1]], scalar)
                return
            word = self.take()
            start = len(self.trace)
            self.accumulate(child, word)
            history = self.trace[start:]
            self.emit("S", target, [word], scalar)
            self.undo(history)
            self.release(word)
            return
        if kind == "mul":
            children = expr[1:]
            nonvar = [c[0] != "var" for c in children]
            ranks = [bound(c)[0] if nv else 0 for c, nv in zip(children, nonvar)]
            lr = max(nonvar[0] + ranks[0], sum(nonvar) + ranks[1])
            rl = max(nonvar[1] + ranks[1], sum(nonvar) + ranks[0])
            order = [0, 1] if lr <= rl else [1, 0]
            words = [None, None]
            histories = []
            for i in order:
                if not nonvar[i]:
                    words[i] = children[i][1]
                    continue
                words[i] = self.take()
                start = len(self.trace)
                self.accumulate(children[i], words[i])
                histories.append((words[i], self.trace[start:]))
            self.emit("M", target, words, scalar)
            for word, history in reversed(histories):
                self.undo(history)
                self.release(word)
            return
        raise ValueError(kind)


def reference(inputs, modulus):
    """Evaluate the five output polynomials directly on ten integer inputs."""
    a, c, s, u, z1, b, d, t, v, z2 = inputs
    K = z1 * z2
    du0, du1 = d * z1 * z1 - c * z2 * z2, b * z1 * z1 - a * z2 * z2
    su1 = b * z1 * z1 + a * z2 * z2
    dv0, dv1 = v * z1**3 - u * z2**3, t * z1**3 - s * z2**3
    C = a * d - c * b
    R = du0 * du0 - C * du1
    E = dv1 * du0 - dv0 * du1
    L = du0 * dv0 - C * dv1
    N = (
        K * K * L * L
        + 2 * a * z2 * z2 * L * E
        + (a * b - du0) * E * E
        - 2 * s * z2**3 * R * E
        + su1 * K * K * R * R
    )
    A = 2 * K * K * L * E + su1 * E * E - K**4 * R * R
    T = L * E - K * K * R * R
    B1 = s * z2**3 * R - a * z2 * z2 * L - (a * b + c * z2 * z2) * E
    B0 = u * z2**3 * R - c * z2 * z2 * L - c * b * E
    outputs = [
        A * R * R,
        N * R * R,
        R * R * (A * T - E * E * (B1 * E + N)),
        R * R * (N * T - B0 * E**3),
        K * R * E,
    ]
    return [x % modulus for x in outputs]


def execute(trace, registers, modulus, inverse=False):
    """Apply a word trace in place; reverse order and signs for its inverse."""
    stream = reversed(trace) if inverse else trace
    for kind, target, sources, sign in stream:
        assert target not in sources
        if kind == "M":
            value = registers[sources[0]] * registers[sources[1]]
        elif kind == "S":
            value = registers[sources[0]] ** 2
        else:
            value = registers[sources[0]]
        registers[target] = (
            registers[target] + (-sign if inverse else sign) * value
        ) % modulus


def check():
    """Verify literal trace counts, modular behavior, and reference resource rows."""
    outputs, numerator, denominator = expressions()
    compiler = Compiler()
    rows = []
    for index, expr in enumerate(outputs):
        start = len(compiler.trace)
        compiler.peak = 0
        compiler.accumulate(expr, 10 + index)
        assert compiler.live == 0
        counts = Counter(op[0] for op in compiler.trace[start:])
        expected = bound(expr)
        actual = (compiler.peak, counts["M"], counts["S"], counts["A"])
        assert actual == expected, (index, actual, expected)
        rows.append(
            dict(
                output=["U1", "U0", "V1", "V0", "Z"][index],
                local_words=actual[0],
                M=actual[1],
                S=actual[2],
                A=actual[3],
            )
        )
    counts = Counter(op[0] for op in compiler.trace)
    assert (counts["M"], counts["S"], counts["A"]) == (14921, 19284, 0)
    rng = random.Random(20260915)
    trials = 0
    for modulus in [3, 5, 7, 9, 11, 15, 17, 101]:
        for _ in range(12):
            inputs = [rng.randrange(modulus) for _ in range(10)]
            targets = [rng.randrange(modulus) for _ in range(5)]
            initial = inputs + targets + [0] * 8
            registers = initial.copy()
            execute(compiler.trace, registers, modulus)
            expected = [
                (x + y) % modulus for x, y in zip(targets, reference(inputs, modulus))
            ]
            assert registers[:10] == inputs
            assert registers[10:15] == expected
            assert registers[15:] == [0] * 8
            execute(compiler.trace, registers, modulus, inverse=True)
            assert registers == initial
            trials += 1
    terminal = dict(
        local_words=max(bound(numerator)[0], 1 + bound(denominator)[0]),
        M=bound(numerator)[1] + 2 * bound(denominator)[1],
        S=bound(numerator)[2] + 2 * bound(denominator)[2],
        fixed_constant_multiply_accumulates=1,
    )
    ledgers = []
    for window, leaves, bitlength in [
        (8, 64, 32),
        (16, 32, 28),
        (24, 32, 28),
        (32, 16, 24),
    ]:
        n, nin = 127, 500
        h = leaves.bit_length() - 1
        height = n
        for _ in range(h - 1):
            height = 20 * height + 16
        H = n + 10 + 12 * height
        kmax = math.ceil(2**bitlength / (bitlength * math.log(2) - 1.1))
        lk = (kmax - 1).bit_length()
        tau, afp = lk + 3, 2 * lk + 4
        primitive = 20 * bitlength**2 * (bitlength + 1)
        # Reference ledger with the conservative literal-evaluator constants.
        move = 2 * max(4 * window * 2**window, 35506 * primitive)
        tree = 8 * (h + 1) * leaves * move
        doubling = 40 * (bitlength + 1) + 2
        reconstruction = kmax * (
            2 * tree
            + 40 * bitlength * (bitlength + 1)
            + tau * (2 * doubling + 20 * (afp + 1))
            + 20 * bitlength * (n + 1)
        )
        reconstruction += 40 * (afp + 1) + 20 * (lk + 1) * (n + 1)
        ledgers.append(
            dict(
                window=window,
                leaves=leaves,
                b=bitlength,
                H=H,
                Kmax=kmax,
                afp=afp,
                reconstruction_width=nin
                + n
                + afp
                + (5 * (h + 2) + 11) * bitlength
                + 10,
                update_width=nin + 2 * n + afp + 2 * bitlength + 20,
                character_width=nin + afp + 6 * n + 12,
                twice_reconstruction_toffoli=reconstruction * 2,
                log2_twice_reconstruction_toffoli=math.log2(reconstruction * 2),
            )
        )
    result = dict(
        scope="word-level evaluator certificate; no full quantum-network synthesis",
        inputs=10,
        outputs=5,
        local_words=8,
        per_output=rows,
        total_operations=len(compiler.trace),
        total_M=counts["M"],
        total_S=counts["S"],
        total_A=counts["A"],
        terminal=terminal,
        arbitrary_accumulator_reversal_tests=trials,
        deterministic_seed=20260915,
        finite_ledgers=ledgers,
    )
    return result


def main():
    run_check(check, "local_evaluator_results.json")


if __name__ == "__main__":
    main()
