#!/usr/bin/env python3
"""Construct and check reversible arithmetic gates for an odd modulus.

A gate is a pair (control_mask, target_mask) acting on an integer-encoded basis
state. Zero, one, and two controls represent NOT, CNOT, and Toffoli gates.
Arithmetic interfaces assume b >= 2, 3 <= p < 2**b with p odd, canonical source
and target residues, and b+4 initially zero scratch bits. Distinct source and
target registers are required, except for the documented square interface.

The checks exhaust small moduli and use deterministic samples at larger widths.
They validate local arithmetic circuits, not a compilation of the full sampler.
The filename is retained for compatibility with the accompanying source archive."""

from itertools import product
import random

from artifact_io import run_check


def gate(controls, target):
    """Encode a gate, merging repeated controls and rejecting target aliasing."""
    controls = tuple(dict.fromkeys(controls))
    assert target not in controls and len(controls) <= 2
    return (sum(1 << j for j in controls), 1 << target)


def run(circuit, state):
    """Return the exact basis-state permutation induced by the gate list."""
    for controls, target in circuit:
        if state & controls == controls:
            state ^= target
    return state


def count_t(circuit):
    """Count gates with two controls, using the ordinary Toffoli convention."""
    return sum(c.bit_count() == 2 for c, _ in circuit)


def encode(bits, value):
    """Place the low bits of value on the listed wires in little-endian order."""
    return sum(((value >> j) & 1) << wire for j, wire in enumerate(bits))


def extract(bits, state):
    """Read the listed wires as a little-endian nonnegative integer."""
    return sum(((state >> wire) & 1) << j for j, wire in enumerate(bits))


def ripple(a, z, carry):
    """Modulo 2**d ripple: 2*d-3 Toffolis, 4*d-2 CNOTs, d>=3.

    Ripple MAJ through the lower d-2 positions, write the final carry
    straight into z[d-1], reverse with UMA, then XOR a[d-1].
    This is the Cuccaro MAJ/UMA construction with its terminal pair
    replaced by the one-Toffoli carry identity.
    """
    d = len(a)
    assert d == len(z) and d >= 3
    c = []
    for i in range(d - 2):
        previous = carry if i == 0 else a[i - 1]
        c += [gate([a[i]], z[i]), gate([a[i]], previous), gate([z[i], previous], a[i])]
    i = d - 2
    previous = a[i - 1]
    c += [
        gate([a[i]], z[i]),
        gate([a[i]], previous),
        gate([z[i], previous], z[i + 1]),
        gate([a[i]], z[i + 1]),
        gate([a[i]], previous),
        gate([previous], z[i]),
    ]
    for i in range(d - 3, -1, -1):
        previous = carry if i == 0 else a[i - 1]
        c += [
            gate([z[i], previous], a[i]),
            gate([a[i]], previous),
            gate([previous], z[i]),
        ]
    c.append(gate([a[-1]], z[-1]))
    assert count_t(c) == 2 * d - 3
    return c


def load_constant(operand, constant, control=None):
    """XOR a public constant into operand, optionally under one control."""
    return [
        gate([] if control is None else [control], wire)
        for j, wire in enumerate(operand)
        if (constant >> j) & 1
    ]


def load_source(operand, source, control=None):
    """XOR a source word into operand, optionally under one source-bit control."""
    # If a source bit is also the control, x_j*x_j=x_j is a CNOT.
    return [
        gate([s] if control is None else [s, control], operand[j])
        for j, s in enumerate(source)
    ]


def word_update(operand, extended_target, carry, load, subtract=False):
    """Load an operand, add or subtract it, and restore operand and carry."""
    addition = ripple(operand, extended_target, carry)
    return load + (addition[::-1] if subtract else addition) + load[::-1]


def allocation(b, square=False):
    """Return source, target, and scratch wires; square=True aliases x and y."""
    x = list(range(b))
    y = x if square else list(range(b, 2 * b))
    offset = b if square else 2 * b
    z = list(range(offset, offset + b))
    start = offset + b
    operand = list(range(start, start + b + 1))
    high, flag, carry = range(start + b + 1, start + b + 4)
    return x, y, z, operand, high, flag, carry


def modular_update(p, z, operand, high, flag, carry, controlled_x):
    """Add the loaded canonical residue to z modulo p and clear all scratch."""
    v = z + [high]
    fixed_p = load_constant(operand, p)
    flagged_p = load_constant(operand, p, flag)
    c = word_update(operand, v, carry, controlled_x)
    c += word_update(operand, v, carry, fixed_p, subtract=True)
    c += [gate([high], flag)]
    c += word_update(operand, v, carry, flagged_p)
    c += word_update(operand, v, carry, controlled_x, subtract=True)
    c += [gate([high], flag)]
    c += word_update(operand, v, carry, controlled_x)
    c += [gate([], flag)]
    return c


def modular_add(p, x, z, operand, high, flag, carry, control=None):
    """Return a source-preserving modular addition, optionally controlled."""
    return modular_update(
        p, z, operand, high, flag, carry, load_source(operand, x, control)
    )


def constant_multiply(p, gamma, b):
    """Return the circuit z <- z + gamma*x modulo the public odd modulus p."""
    x, _, z, operand, high, flag, carry = allocation(b, True)
    c = []
    for j in range(b):
        constant = gamma * (1 << j) % p
        c += modular_update(
            p, z, operand, high, flag, carry, load_constant(operand, constant, x[j])
        )
    assert count_t(c) == 10 * b * b - 5 * b
    return c


def modular_double(p, z, operand, high, flag, carry):
    """Double a canonical target modulo odd p; oddness makes this reversible."""
    v = z + [high]
    c = []
    # Cyclically rotate the extended word by one bit to the left.
    for j in range(len(v) - 1, 0, -1):
        a, b = v[j], v[j - 1]
        c += [gate([a], b), gate([b], a), gate([a], b)]
    c += word_update(operand, v, carry, load_constant(operand, p), True)
    c += [gate([high], flag)]
    c += word_update(operand, v, carry, load_constant(operand, p, flag))
    c += [gate([], flag), gate([z[0]], flag)]
    return c


def multiply(p, b, square=False):
    """Return z <- z + x*y modulo p, or z <- z + x*x for the square interface."""
    x, y, z, operand, high, flag, carry = allocation(b, square)
    doubling = modular_double(p, z, operand, high, flag, carry)
    c = doubling[::-1] * (b - 1)
    c += modular_add(p, x, z, operand, high, flag, carry, y[-1])
    for j in range(b - 2, -1, -1):
        c += doubling
        c += modular_add(p, x, z, operand, high, flag, carry, y[j])
    assert count_t(doubling) == 4 * b - 2
    expected = 24 * b * b - 17 * b + 4 - (6 * b if square else 0)
    assert count_t(c) == expected
    return c


def check():
    """Verify arithmetic values, source/scratch restoration, and gate counts."""
    cases = dict(
        ripple=0,
        controlled_add=0,
        square_add=0,
        double=0,
        multiply=0,
        square=0,
        constant_multiply=0,
        variable_add=0,
        inverse=0,
        large_modulus=0,
    )
    for d in range(3, 7):
        a, z, carry = list(range(d)), list(range(d, 2 * d)), 2 * d
        c = ripple(a, z, carry)
        for av, zv in product(range(1 << d), repeat=2):
            state = encode(a, av) | encode(z, zv)
            expected = encode(a, av) | encode(z, (av + zv) % (1 << d))
            assert run(c, state) == expected
            assert run(c[::-1], expected) == state
            cases["ripple"] += 1
    # All odd moduli through 15 include non-prime and padded moduli.
    for p in range(3, 16, 2):
        b = p.bit_length()
        x, y, z, operand, high, flag, carry = allocation(b)
        double = modular_double(p, z, operand, high, flag, carry)
        for zv in range(p):
            state = encode(z, zv)
            expected = encode(z, 2 * zv % p)
            assert run(double, state) == expected
            assert run(double[::-1], expected) == state
            cases["double"] += 1
        control = y[0]
        c = modular_add(p, x, z, operand, high, flag, carry, control)
        assert count_t(c) == 16 * b - 5
        for xv, zv, g in product(range(p), range(p), (0, 1)):
            state = encode(x, xv) | encode(z, zv) | (g << control)
            expected = encode(x, xv) | encode(z, (zv + g * xv) % p) | (g << control)
            assert run(c, state) == expected
            assert run(c[::-1], expected) == state
            cases["controlled_add"] += 1
        c = multiply(p, b)
        for xv, yv, zv in product(range(p), repeat=3):
            state = encode(x, xv) | encode(y, yv) | encode(z, zv)
            expected = encode(x, xv) | encode(y, yv) | encode(z, (zv + xv * yv) % p)
            assert run(c, state) == expected, (p, xv, yv, zv)
            assert run(c[::-1], expected) == state
            cases["multiply"] += 1
            cases["inverse"] += 1
        x, y, z, operand, high, flag, carry = allocation(b, True)
        addition = modular_add(p, x, z, operand, high, flag, carry)
        assert count_t(addition) == 10 * b - 5
        for xv, zv in product(range(p), repeat=2):
            state = encode(x, xv) | encode(z, zv)
            expected = encode(x, xv) | encode(z, (zv + xv) % p)
            assert run(addition, state) == expected
            cases["variable_add"] += 1
        for gamma in range(p):
            constant_circuit = constant_multiply(p, gamma, b)
            for xv, zv in product(range(p), repeat=2):
                state = encode(x, xv) | encode(z, zv)
                expected = encode(x, xv) | encode(z, (zv + gamma * xv) % p)
                assert run(constant_circuit, state) == expected
                assert run(constant_circuit[::-1], expected) == state
                cases["constant_multiply"] += 1
        c = multiply(p, b, True)
        for xv, zv in product(range(p), repeat=2):
            state = encode(x, xv) | encode(z, zv)
            expected = encode(x, xv) | encode(z, (zv + xv * xv) % p)
            assert run(c, state) == expected
            assert run(c[::-1], expected) == state
            cases["square"] += 1
            cases["inverse"] += 1
        for j in range(b):
            c = modular_add(p, x, z, operand, high, flag, carry, x[j])
            assert count_t(c) == 16 * b - 11
            for xv, zv in product(range(p), repeat=2):
                state = encode(x, xv) | encode(z, zv)
                expected = encode(x, xv) | encode(z, (zv + ((xv >> j) & 1) * xv) % p)
                assert run(c, state) == expected
                cases["square_add"] += 1
    rng = random.Random(9212026)
    for b, p in [
        (8, 127),
        (8, 255),
        (12, 997),
        (24, 2**24 - 3),
        (28, 2**28 - 5),
        (32, 2**32 - 5),
        (127, 2**127 - 1),
    ]:
        for square in (False, True):
            x, y, z, *_ = allocation(b, square)
            c = multiply(p, b, square)
            for _ in range(16 if b < 127 else 2):
                xv, yv, zv = [rng.randrange(p) for _ in range(3)]
                if square:
                    yv = xv
                state = encode(x, xv) | encode(y, yv) | encode(z, zv)
                expected = encode(x, xv) | encode(y, yv) | encode(z, (zv + xv * yv) % p)
                assert run(c, state) == expected
                assert run(c[::-1], expected) == state
                cases["large_modulus"] += 1
    report = dict(
        status="passed",
        cases=cases,
        source="Exact NOT/CNOT/Toffoli circuits; standard-library Python",
        clean_scratch="b+4 qubits beyond the source(s) and distinct target",
        controlled_variable_add="16*b-5",
        variable_add="10*b-5",
        fixed_constant_multiply_accumulate="10*b*b-5*b",
        in_place_modular_double="4*b-2",
        multiply_accumulate="24*b*b-17*b+4",
        square_accumulate="24*b*b-23*b+4",
        scope="All tested valid inputs restore every source and scratch bit; "
        "arbitrary canonical targets and inverse circuits checked. "
        "Gate permutations give coherent action by linearity. "
        "This is not compilation of the full genus-two sampler.",
    )
    return report


def main():
    run_check(check, "primitive_improvement.json")


if __name__ == "__main__":
    main()
