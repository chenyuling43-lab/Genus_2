"""Command-line and file handling shared by the manuscript checkers.

Expected results are comparison fixtures. Checkers read only input certificates
and results produced in the active run; they never read the expected directory.
"""

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def require_assertions():
    """Reject optimized Python, which would disable scientific assertions."""
    if sys.flags.optimize:
        raise RuntimeError(
            "Run without -O or PYTHONOPTIMIZE: these checks require assertions."
        )


def result_directory():
    configured = os.environ.get("GENUS2_RESULTS_DIR")
    return Path(configured).expanduser().resolve() if configured else ROOT / "results"


def result_path(filename, output=None):
    return (
        Path(output).expanduser().resolve() if output else result_directory() / filename
    )


def write_result(data, filename, output=None):
    """Atomically save one completed check; leave expected fixtures untouched."""
    require_assertions()
    destination = result_path(filename, output)
    if destination == ROOT / "expected" or ROOT / "expected" in destination.parents:
        raise ValueError(
            "Expected fixtures are read-only inputs to the comparison runner."
        )
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=".result-",
            suffix=".json",
            delete=False,
        ) as stream:
            temporary = Path(stream.name)
            json.dump(data, stream, indent=2, allow_nan=False)
            stream.write("\n")
        temporary.replace(destination)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    print(f"PASS: {destination.name}\nResult: {destination}")
    return destination


def read_result(filename):
    """Load a dependency from this run, never from the frozen expectations."""
    path = result_path(filename).resolve()
    if path == ROOT / "expected" or ROOT / "expected" in path.parents:
        raise ValueError(
            "Dependencies must come from generated results, not expected/."
        )
    if not path.is_file():
        raise FileNotFoundError(
            f"Required result {path} is missing. Run the prerequisite checker first, "
            "or use run_checks.py to resolve dependencies automatically."
        )
    return json.loads(path.read_text(encoding="utf-8"))


def certificate_path(filename):
    """Locate an input certificate independently of the working directory."""
    return ROOT / "certificates" / filename


def run_check(check_function, filename):
    """Run one assertion-based checker with an optional output path."""
    require_assertions()
    parser = argparse.ArgumentParser(description=check_function.__doc__)
    parser.add_argument(
        "--output", type=Path, help="JSON output path (default: results/)"
    )
    options = parser.parse_args()
    write_result(check_function(), filename, options.output)


require_assertions()
