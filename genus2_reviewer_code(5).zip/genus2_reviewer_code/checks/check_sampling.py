"""Verify finite-field sampling data and canonical-encoding collision identities.

Subgroups and Mumford pairs are enumerated exactly. Only the Fourier-transform
comparisons use floating-point arithmetic, with an absolute tolerance of 2e-12.
"""

from collections import Counter
from fractions import Fraction
from itertools import product

import numpy as np

import cantor_reference as reference
from artifact_io import run_check

# (field characteristic, curve coefficients, subgroup generator, subgroup order)
# Polynomial coefficients are stored in ascending degree order.
FIXTURES = (
    (3, [1, 2, 1, 2, 0, 1], ([0, 0, 1], [1, 1]), 11),
    (5, [3, 0, 2, 1, 0, 1], ([3, 1], [1]), 23),
    (7, [6, 5, 0, 4, 0, 1], ([3, 3, 1], [5, 5]), 11),
    (11, [3, 5, 7, 0, 0, 1], ([0, 0, 1], [5, 6]), 73),
)
FFT_TOLERANCE = 2e-12


def check_fixture(q, curve, generator, order):
    """Return one exact data row and its two maximum FFT discrepancies."""
    reference.p = q
    derivative = [i * curve[i] for i in range(1, len(curve))]
    assert len(reference.xgcd(curve, derivative)[0]) == 1

    identity = ([1], [])
    group = [identity]
    current = generator
    while current != identity:
        assert current not in group
        group.append(current)
        current = reference.cantor(current, generator, curve)
    assert len(group) == order

    all_classes = [identity]
    for degree in (1, 2):
        for u_coefficients in product(range(q), repeat=degree):
            u = list(u_coefficients) + [1]
            for v_coefficients in product(range(q), repeat=degree):
                v = reference.tr(v_coefficients)
                if not reference.div(reference.sub(curve, reference.mul(v, v)), u)[1]:
                    all_classes.append((u, v))

    lower_degree_count = sum(len(u) < 3 for u, v in group)
    fiber_counts = [sum(len(u) == 3 and u[0] == a for u, v in group) for a in range(q)]

    def chi(value):
        """Legendre symbol, including chi(0) = 0."""
        if value % q == 0:
            return 0
        return 1 if pow(value % q, (q - 1) // 2, q) == 1 else -1

    def square_sign(value):
        return chi(value) + (value % q == 0)

    signs = np.array(
        [
            [1 if len(u) < 3 else square_sign(u[0] + shift) for u, v in group]
            for shift in range(q)
        ]
    )
    means = [Fraction(int(sum(sign)), order) for sign in signs]
    success = [1 - mean * mean for mean in means]
    average_success = sum(success) / q
    variance_bound = Fraction(q - 1, q) * (
        1
        - Fraction(
            lower_degree_count**2 + sum(count**2 for count in fiber_counts), order**2
        )
    )

    first, second = np.indices((order, order))
    group_indices = (first + 2 * second) % order
    max_fft_discrepancy = 0
    for shift in range(q):
        actual = abs(np.fft.fft2(signs[shift][group_indices]) / order**2) ** 2
        predicted = np.zeros((order, order))
        one_dimensional = abs(np.fft.fft(signs[shift]) / order) ** 2
        for frequency in range(order):
            predicted[frequency, 2 * frequency % order] = one_dimensional[frequency]
        max_fft_discrepancy = max(
            max_fft_discrepancy,
            float(np.max(abs(actual - predicted))),
            float(abs(actual[0, 0] - float(means[shift] ** 2))),
        )

    # Independent point counts over F_q and F_{q^2} determine the Jacobian order.
    n1 = 1 + sum(1 + chi(sum(c * x**i for i, c in enumerate(curve))) for x in range(q))
    nonsquare = next(a for a in range(2, q) if chi(a) == -1)
    extension_elements = list(product(range(q), repeat=2))

    def extension_multiply(a, b):
        return (
            (a[0] * b[0] + nonsquare * a[1] * b[1]) % q,
            (a[0] * b[1] + a[1] * b[0]) % q,
        )

    def extension_evaluate(x):
        result = (0, 0)
        for coefficient in curve[::-1]:
            result = extension_multiply(result, x)
            result = ((result[0] + coefficient) % q, result[1])
        return result

    square_counts = {x: 0 for x in extension_elements}
    for x in extension_elements:
        square_counts[extension_multiply(x, x)] += 1
    n2 = 1 + sum(square_counts[extension_evaluate(x)] for x in extension_elements)
    assert (n1 * n1 + n2) // 2 - q == len(all_classes)

    row = {
        "q": q,
        "subgroup_order": order,
        "J_order": len(all_classes),
        "N1": n1,
        "N2": n2,
        "lower_degree_count": lower_degree_count,
        "fiber_counts": fiber_counts,
        "unshifted_success": str(success[0]),
        "mean_shift_success": str(average_success),
        "V_G": str(variance_bound),
    }

    max_rectangular_discrepancy = 0
    if q in (3, 5, 7):
        field_bits = q.bit_length()
        encoding_bits = 2 + 4 * field_bits

        def encode(divisor):
            u, v = divisor
            degree = len(u) - 1
            words = [
                u[1] if degree == 2 else 0,
                u[0] if degree else 0,
                v[1] if len(v) > 1 else 0,
                v[0] if len(v) > 0 else 0,
            ]
            return degree + sum(
                word << (2 + i * field_bits) for i, word in enumerate(words)
            )

        encodings = list(map(encode, group))
        assert len(set(encodings)) == order
        restrictions = {
            tuple((-1) ** ((seed & value).bit_count() % 2) for value in encodings)
            for seed in range(1 << encoding_bits)
        }
        phases = np.asarray(list(restrictions), dtype=np.int64)
        covariance = phases.T @ phases
        assert np.array_equal(covariance, len(phases) * np.eye(order, dtype=np.int64))

        # Check uniform multiplicity of the linear seed-to-sign map directly.
        multiplicities = Counter(
            tuple((-1) ** ((seed & value).bit_count() % 2) for value in encodings)
            for seed in range(1 << encoding_bits)
        )
        assert len(set(multiplicities.values())) == 1
        first, second = np.indices((8, 4))
        rectangular_indices = (first + 2 * second) % order
        output = (
            abs(np.fft.fft2(phases[:, rectangular_indices], axes=(-2, -1)) / 32) ** 2
        )
        averaged_distribution = output.mean(axis=0)
        full_distribution = sum(
            abs(np.fft.fft2((rectangular_indices == index).astype(float)) / 32) ** 2
            for index in range(order)
        )
        max_rectangular_discrepancy = float(
            np.max(abs(averaged_distribution - full_distribution))
        )
        row["encoding_bits"] = encoding_bits
        row["distinct_canonical_restrictions"] = len(phases)
        row["seed_multiplicity"] = next(iter(multiplicities.values()))
        row["canonical_covariance_exact_identity"] = True
    return row, max_fft_discrepancy, max_rectangular_discrepancy


def check():
    rows = []
    max_fft_discrepancy = 0
    max_rectangular_discrepancy = 0
    for fixture in FIXTURES:
        row, fft_discrepancy, rectangular_discrepancy = check_fixture(*fixture)
        rows.append(row)
        max_fft_discrepancy = max(max_fft_discrepancy, fft_discrepancy)
        max_rectangular_discrepancy = max(
            max_rectangular_discrepancy, rectangular_discrepancy
        )

    assert [row["mean_shift_success"] for row in rows] == [
        "256/363",
        "2192/2645",
        "96/121",
        "55128/58619",
    ]
    assert max_fft_discrepancy < FFT_TOLERANCE
    assert max_rectangular_discrepancy < FFT_TOLERANCE
    return {
        "scope": "Exact Cantor subgroup, point/fiber enumeration, canonical integer covariance; floating-point 2D FFT checks at tolerance2e-12. Not complete quantum circuit synthesis.",
        "all_field_seeds_checked": sum(q for q, _, _, _ in FIXTURES),
        "max_exact_domain_FFT_discrepancy": max_fft_discrepancy,
        "max_rectangular_distribution_discrepancy": max_rectangular_discrepancy,
        "rows": rows,
    }


if __name__ == "__main__":
    run_check(check, "check_sampling.json")
