#!/usr/bin/env python3
"""Verify the displayed subgroup order by a deterministic Pocklington certificate.

Each nonleaf entry gives a complete factorization of n-1. Its recursively
certified product exceeds sqrt(n), as required by Pocklington's theorem.
The leaves use exact trial division. No probable-prime test or factorization
algorithm is used by this verifier.
"""

import json
import math
from pathlib import Path

from artifact_io import certificate_path, run_check


def verify(path=None):
    """Verify the full dependency graph and return its certification summary."""
    source = Path(path) if path else certificate_path("subgroup_prime_certificate.json")
    data = json.loads(source.read_text())
    expected = 2**250 - int("334D69820C75294D2C27FC9F9A154FF47730B4B840C05BD", 16)
    assert int(data["r"]) == expected
    certificates = data["certificates"]
    verified = set()
    active = set()

    def check_prime(n):
        """Check one node, rejecting a cyclic certificate dependency."""
        if n in verified:
            return
        assert n >= 2 and n not in active
        active.add(n)
        certificate = certificates[str(n)]
        if "trial_division_through" in certificate:
            assert certificate["trial_division_through"] == math.isqrt(n)
            assert n < 1000000
            assert all(n % divisor for divisor in range(2, math.isqrt(n) + 1))
        else:
            factors = certificate["factors_n_minus_one"]
            assert factors and all(
                isinstance(prime, int) and 2 <= prime < n for prime in factors
            )
            certified_product = math.prod(factors)
            assert certified_product == n - 1 and certified_product**2 > n
            witnesses = certificate["pocklington_witnesses"]
            assert set(witnesses) == set(map(str, factors))
            for prime in set(factors):
                check_prime(prime)
                witness = witnesses[str(prime)]
                assert isinstance(witness, int) and 1 < witness < n
                assert pow(witness, n - 1, n) == 1
                assert math.gcd(pow(witness, (n - 1) // prime, n) - 1, n) == 1
        active.remove(n)
        verified.add(n)

    check_prime(expected)
    return {
        "subgroup_order": str(expected),
        "subgroup_bits": expected.bit_length(),
        "deterministic_primality_verified": True,
        "method": "Recursive Pocklington certificate with exact trial-division leaves",
        "certified_primes_including_leaves": len(verified),
        "probable_prime_tests_used_by_verifier": False,
    }


if __name__ == "__main__":
    run_check(verify, "subgroup_prime_verification_results.json")
