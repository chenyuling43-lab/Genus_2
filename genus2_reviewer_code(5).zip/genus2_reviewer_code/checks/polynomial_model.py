"""Sparse integer polynomials for the compact genus-two addition map.

The exponent order is (U1_1, U0_1, V1_1, V0_1, Z1,
U1_2, U0_2, V1_2, V0_2, Z2). Coefficients are exact integers.
The single-letter names in the formulas follow the manuscript's local
notation. This module defines the model only; audit_arithmetic.py checks
its degrees, norms, and denominator-clearing identities.
"""

from collections import defaultdict


class Poly(dict):
    """Sparse polynomial: exponent tuples map to nonzero integer coefficients."""

    def __add__(self, other):
        if isinstance(other, int):
            other = Poly({(0,) * 10: other}) if other else Poly()
        o = Poly(self)
        for e, c in other.items():
            o[e] = o.get(e, 0) + c
            if not o[e]:
                del o[e]
        return o

    __radd__ = __add__

    def __neg__(self):
        return Poly({e: -c for e, c in self.items()})

    def __sub__(self, other):
        return self + -other

    def __rsub__(self, other):
        return -self + other

    def __mul__(self, other):
        if isinstance(other, int):
            return Poly({e: c * other for e, c in self.items() if c * other})
        o = defaultdict(int)
        for e, c in self.items():
            for f, d in other.items():
                o[tuple((x + y for x, y in zip(e, f)))] += c * d
        return Poly({e: c for e, c in o.items() if c})

    __rmul__ = __mul__

    def __pow__(self, n):
        o = Poly({(0,) * 10: 1})
        p = self
        while n:
            if n % 2:
                o = o * p
            n //= 2
            if n:
                p = p * p
        return o


VARIABLE_POLYNOMIALS = [
    Poly({tuple((int(i == j) for j in range(10))): 1}) for i in range(10)
]
a, c, s, u, z, b, d, t, v, w = VARIABLE_POLYNOMIALS
K = z * w
Asc = K * K
DU0 = d * z * z - c * w * w
DU1 = b * z * z - a * w * w
DV0 = v * z**3 - u * w**3
DV1 = t * z**3 - s * w**3
SU1 = b * z * z + a * w * w
SU0 = d * z * z + c * w * w
C = a * d - c * b
R = DU0**2 - C * DU1
E = DV1 * DU0 - DV0 * DU1
L = DU0 * DV0 - C * DV1
N = (
    Asc * L**2
    + 2 * a * w * w * L * E
    + (a * b - DU0) * E**2
    - 2 * s * w**3 * R * E
    + SU1 * Asc * R**2
)
D = Asc * E**2
J = Asc * L + SU1 * E
A = 2 * Asc * L * E + SU1 * E**2 - K**4 * R**2
T = L * E - Asc * R**2
B1 = s * w**3 * R - a * w * w * L - (a * b + c * w * w) * E
B0 = u * w**3 * R - c * w * w * L - c * b * E
out = [
    A * R**2,
    N * R**2,
    R**2 * (A * T - E**2 * (B1 * E + N)),
    R**2 * (N * T - B0 * E**3),
    K * R * E,
]

weights = [2, 2, 3, 3, 1] * 2
