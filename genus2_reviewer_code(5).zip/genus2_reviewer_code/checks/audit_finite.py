#!/usr/bin/env python3
"""Compare the compact generic map with independent Cantor arithmetic.

All divisor pairs are checked for q = 5 and 7. For q = 11 and 13, 2000
pairs are sampled. Nonzero weighted input scales use the same seeded stream.
Finite checks supplement, but do not replace, the algebraic proof.
"""

from itertools import product
import random

import cantor_reference as reference
from artifact_io import run_check


def check():
    """Exhaust small fields and sample the larger fixtures in a fixed order."""
    rng = random.Random(23419)
    reports = []
    for p in [5, 7, 11, 13]:
        reference.p = p
        f = [1, 1, 0, 0, 0, 1]
        der = [i * f[i] for i in range(1, 6)]
        while len(reference.xgcd(f, der)[0]) != 1:
            f[0] += 1
        pairs = [([1], [])]
        for degree in [1, 2]:
            for uc in product(range(p), repeat=degree):
                uu = list(uc) + [1]
                for vc in product(range(p), repeat=degree):
                    vv = reference.tr(vc)
                    if not reference.div(reference.sub(f, reference.mul(vv, vv)), uu)[
                        1
                    ]:
                        pairs.append((uu, vv))
        if p < 10:
            cases = product(pairs, repeat=2)
        else:
            cases = [(rng.choice(pairs), rng.choice(pairs)) for _ in range(2000)]
        total = gen = 0
        for xx, yy in cases:
            zz = reference.cantor(xx, yy, f)
            total += 1
            if len(xx[0]) == 3 and len(yy[0]) == 3:
                out = reference.compact(
                    reference.coords(xx, rng.randrange(1, p)),
                    reference.coords(yy, rng.randrange(1, p)),
                )
                if out:
                    gen += 1
                    assert out == zz, (p, xx, yy, out, zz)
        reports.append(
            {
                "prime": p,
                "curve_coefficients_ascending": f,
                "reduced_divisor_count": len(pairs),
                "input_pairs_checked": total,
                "all_pairs_exhausted": p < 10,
                "generic_compact_pairs_compared": gen,
                "failures": 0,
            }
        )
    return {
        "random_seed": 23419,
        "scope": "Independent complete Cantor output validity and compact generic-branch comparison with random nonzero weighted input scales",
        "tests": reports,
    }


if __name__ == "__main__":
    run_check(check, "audit_finite_results.json")
