#!/usr/bin/env python3
"""Exact sparse-polynomial audit of the compact addition map.

This check uses integer coefficients only. It verifies the manuscript's
coefficient-norm bounds and the square factors in denominator clearing.
"""

from artifact_io import run_check
from polynomial_model import (
    Asc,
    a,
    b,
    c,
    s,
    z,
    w,
    DU0,
    DU1,
    DV0,
    DV1,
    SU0,
    SU1,
    K,
    R,
    E,
    L,
    N,
    D,
    out,
    weights,
)


def check():
    """Verify exact coefficient norms, degrees, and cancellation identities."""
    results = {}
    expected_bounds = {"U1": 20480, "U0": 40960, "V1": 6291456, "V0": 6029312, "Z": 64}
    for name, p in [("N", N), ("D", D)] + list(zip(["U1", "U0", "V1", "V0", "Z"], out)):
        deg = max((sum(e) for e in p))
        norm = sum((abs(cc) for cc in p.values()))
        bideg = {
            (
                sum((e[i] * weights[i] for i in range(5))),
                sum((e[i] * weights[i] for i in range(5, 10))),
            )
            for e in p
        }
        results[name] = {
            "monomial_count": len(p),
            "ordinary_total_degree": deg,
            "exact_coefficient_l1_norm": norm,
            "weighted_bidegrees": [list(x) for x in sorted(bideg)],
        }
        if name in expected_bounds:
            results[name]["manuscript_coefficient_norm_upper_bound"] = expected_bounds[
                name
            ]
            results[name]["upper_bound_verified"] = norm <= expected_bounds[name]
            assert norm <= expected_bounds[name]
    # In the legacy interpolation, C3 uses the scalar Asc.
    EE = SU1 * DU1 - Asc * DU0
    GG = SU1 * DU0 + DU1 * SU0
    HH = (SU1 * DU1 - 2 * Asc * DU0) * DU0 - DU1**2 * SU0
    C2 = DV1 * GG - 2 * DV0 * EE
    C3 = 2 * Asc * (DV1 * DU0 - DV0 * DU1)
    WW = K * HH
    lam = WW * z**4
    BB2 = C2 * z**4
    BB3 = C3 * z**4
    BB1 = s * WW * z + C2 * a * z * z - C3 * (a * a - c * z * z)
    a5 = 2 * BB2 * BB3 - lam**2
    a4 = BB2**2 + 2 * BB1 * BB3
    Na = Asc * a5 - BB3**2 * SU1
    Nb = Asc**2 * a4 - Asc * BB3**2 * (SU0 + a * b) - SU1 * Na
    Db = Asc**2 * BB3**2
    identities = {
        "interpolation_determinant_equals_minus_two_A_sc_R": HH == -2 * Asc * R,
        "legacy_N_beta_equals_square_factor_times_N_star": Nb
        == (2 * z**7 * w**3) ** 2 * N,
        "legacy_D_beta_equals_square_factor_times_D_star": Db
        == (2 * z**7 * w**3) ** 2 * D,
    }
    assert all(identities.values())
    assert [
        results[x]["ordinary_total_degree"] for x in ["U1", "U0", "V1", "V0", "Z"]
    ] == [32, 31, 48, 47, 15]
    assert results["N"]["exact_coefficient_l1_norm"] == 232
    assert results["D"]["exact_coefficient_l1_norm"] == 64
    report = {
        "method": "Exact sparse expansion over Z with integer coefficients; no external dependencies",
        "input_variables": [
            "U1_1",
            "U0_1",
            "V1_1",
            "V0_1",
            "Z1",
            "U1_2",
            "U0_2",
            "V1_2",
            "V0_2",
            "Z2",
        ],
        "polynomials": results,
        "polynomial_identities": identities,
        "notes": [
            "Legacy C3 uses the corrected scalar A_sc, not the five-output addition map mathcal A.",
            "The displayed compact-map coefficient-norm constants are verified upper bounds, not exact coefficient norms.",
            "The original factor 2^8 and tree growth factor 20 are retained.",
        ],
    }
    return report


if __name__ == "__main__":
    run_check(check, "audit_arithmetic_results.json")
