# MATLAB reference-example execution

The author supplied a MATLAB diary reporting successful execution of the
packaged reference example and an additional a0-route check. The accompanying
MATLAB_validation_log.txt preserves the commands and outputs; the MATLAB
license number and absolute local directories were redacted for distribution.
The uploaded original diary is not included in this archive.

## Recorded environment

- Diary timestamp: 2026-09-16 18:45:17 (local timezone not recorded).
- MATLAB: 26.1.0.3346908 (R2026a) Update 5.
- Symbolic Math Toolbox: 26.1 (R2026a).
- Operating system: Windows 10, build 19045.

## Observed checks

- `which ... -all` reports one file for each of hec2_projective_add and
  hec2_projective_recover, inside the supplied package's matlab directory.
- `demo_hec2_projective_add` reports `Reference example passed.` Its a4
  projective output is [81,53,65,52,68], and its affine output is [56,94,30,24].
- The a0 route is executed separately. Both assertions (equality to the known
  affine output and equality to the a4 affine output) complete without errors.
- The diary ends with `PASS: a4 and a0 reference-example checks completed.`

## Scope and provenance

This is author-supplied evidence of fixed-example execution in MATLAB, reviewed
against the expected outputs. It is separate from the 20-check Python run in
verification_report.json. MATLAB was not run in the review environment.
The 1000 seeded input-pair tests remain Python transcription tests; this diary
does not establish their execution in MATLAB, exhaustive MATLAB correctness,
or a complete quantum sampler implementation. Octave has not been tested.

The diary records local file resolution but no runtime source hashes. It does
not independently prove byte-for-byte identity of the author's executed files.
The packaged .m files are unchanged from genus2_reviewer_code(3).zip; their
identities remain recorded in artifact_manifest.json and the Python report.
