#!/usr/bin/env python3
"""Run the manuscript checks in a fresh directory and compare their results."""

import argparse
from datetime import datetime, timezone
from importlib import metadata
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
# Explicit registration excludes support modules and fixes the dependency order.
# name, result file, dependencies, quick-suite membership
CHECKS = [
    ("audit_arithmetic", "audit_arithmetic_results.json", (), False),
    ("audit_finite", "audit_finite_results.json", (), False),
    ("check_affine_masks", "affine_masks_results.json", (), True),
    ("check_arithmetic_proofs", "arithmetic_proof_checks.json", (), False),
    ("check_cached_evaluator", "cached_evaluator_results.json", (), False),
    (
        "check_cached_gate_integration",
        "cached_gate_integration_results.json",
        (),
        False,
    ),
    ("check_cached_symbolic", "cached_symbolic_results.json", (), True),
    ("check_gs_parameters", "gs_parameter_results.json", (), False),
    (
        "check_height_certificate_independent",
        "height_certificate_independent_results.json",
        (),
        True,
    ),
    ("check_matlab_algebra", "matlab_algebra_results.json", (), False),
    ("check_normalized_height", "normalized_height_results.json", (), True),
    ("check_phase", "check_phase.json", (), False),
    (
        "check_resource_ledger",
        "check_resource_ledger.json",
        ("check_normalized_height",),
        True,
    ),
    ("check_sampling", "check_sampling.json", (), False),
    ("check_spooky_schedule", "spooky_schedule_results.json", (), True),
    ("check_terminal_trace", "check_terminal_trace.json", (), False),
    ("primitive_improvement", "primitive_improvement.json", (), False),
    ("rectangular_example_check", "rectangular_example_check.json", (), False),
    ("verify_local_evaluator", "local_evaluator_results.json", (), False),
    (
        "verify_subgroup_prime_certificate",
        "subgroup_prime_verification_results.json",
        (),
        True,
    ),
]


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def differences(actual, expected, path="$", limit=8):
    """Compare exact discrete data and tolerate only floating-point roundoff."""
    found = []

    def compare(left, right, location):
        if len(found) >= limit:
            return
        if type(left) is not type(right):
            found.append(
                f"{location}: type {type(left).__name__} != {type(right).__name__}"
            )
        elif isinstance(right, dict):
            if left.keys() != right.keys():
                found.append(f"{location}: JSON object keys differ")
            for key in sorted(left.keys() & right.keys()):
                compare(left[key], right[key], f"{location}.{key}")
        elif isinstance(right, list):
            if len(left) != len(right):
                found.append(f"{location}: length {len(left)} != {len(right)}")
            for index, (value, reference) in enumerate(zip(left, right)):
                compare(value, reference, f"{location}[{index}]")
        elif isinstance(right, float):
            if not (
                math.isfinite(left)
                and math.isfinite(right)
                and math.isclose(left, right, rel_tol=1e-12, abs_tol=1e-12)
            ):
                found.append(f"{location}: {left!r} != {right!r}")
        elif left != right:
            found.append(f"{location}: {left!r} != {right!r}")

    compare(actual, expected, path)
    return found


def selected_checks(suite, requested):
    catalog = {row[0]: row for row in CHECKS}
    selected = (
        set(requested)
        if requested
        else {row[0] for row in CHECKS if suite == "full" or row[3]}
    )
    pending = list(selected)
    while pending:
        for dependency in catalog[pending.pop()][2]:
            if dependency not in selected:
                selected.add(dependency)
                pending.append(dependency)
    return [row for row in CHECKS if row[0] in selected]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite", choices=("quick", "full"), default="quick")
    parser.add_argument(
        "--check",
        action="append",
        choices=[row[0] for row in CHECKS],
        help="Select a checker; repeat to select several. Includes dependencies.",
    )
    parser.add_argument(
        "--list", action="store_true", help="List checks without running them."
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=ROOT / "results",
        help="Parent directory for a new, isolated run directory.",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=900,
        help="Maximum seconds per checker (default: 900).",
    )
    args = parser.parse_args()
    if args.list:
        for name, _, dependencies, quick in CHECKS:
            detail = "quick, full" if quick else "full"
            if dependencies:
                detail += "; requires " + ", ".join(dependencies)
            print(f"{name}: {detail}")
        return 0
    if sys.flags.optimize:
        parser.error("Do not use -O or PYTHONOPTIMIZE; scientific assertions must run.")
    if not math.isfinite(args.timeout) or args.timeout <= 0:
        parser.error("--timeout must be a positive finite number.")
    selected = selected_checks(args.suite, args.check)
    if any(row[0] == "check_sampling" for row in selected):
        try:
            import numpy  # noqa: F401: fail before running the full suite if absent
        except ImportError:
            parser.error(
                "check_sampling requires NumPy. Install requirements.txt first."
            )
    parent = args.output_dir.expanduser().resolve()
    if parent == ROOT / "expected" or ROOT / "expected" in parent.parents:
        parser.error("--output-dir must not be inside expected/.")
    parent.mkdir(parents=True, exist_ok=True)
    started = datetime.now(timezone.utc)
    run_dir = Path(
        tempfile.mkdtemp(prefix=started.strftime("run-%Y%m%dT%H%M%SZ-"), dir=parent)
    )
    logs = run_dir / "logs"
    logs.mkdir()
    environment = os.environ.copy()
    environment["GENUS2_RESULTS_DIR"] = str(run_dir)
    reports = []
    statuses = {}
    timer = time.monotonic()
    print(f"Running {len(selected)} checks. Results: {run_dir}", flush=True)
    for name, filename, dependencies, _ in selected:
        entry = {"check": name, "result": filename, "log": f"logs/{name}.log"}
        reports.append(entry)
        if any(statuses.get(dependency) != "passed" for dependency in dependencies):
            entry.update(
                status="skipped", reason="A prerequisite did not pass.", seconds=0
            )
            statuses[name] = "skipped"
            print(f"SKIP {name}: prerequisite failed", flush=True)
            continue
        print(f"RUN  {name}", flush=True)
        before = time.monotonic()
        script = ROOT / "checks" / f"{name}.py"
        expected_file = ROOT / "expected" / filename
        try:
            entry["source_sha256"] = sha256(script)
            with (logs / f"{name}.log").open("w", encoding="utf-8") as log:
                process = subprocess.run(
                    [sys.executable, "-B", str(script)],
                    cwd=run_dir,
                    env=environment,
                    stdout=log,
                    stderr=subprocess.STDOUT,
                    timeout=args.timeout,
                    check=False,
                )
            entry["exit_code"] = process.returncode
            if process.returncode:
                raise RuntimeError(
                    f"Checker exited with status {process.returncode}; see its log."
                )
            actual_file = run_dir / filename
            actual = json.loads(actual_file.read_text(encoding="utf-8"))
            expected = json.loads(expected_file.read_text(encoding="utf-8"))
            mismatch = differences(actual, expected)
            entry.update(
                result_sha256=sha256(actual_file),
                expected_sha256=sha256(expected_file),
                exact_json_match=(actual == expected),
            )
            if mismatch:
                raise ValueError("; ".join(mismatch))
            entry.update(status="passed", comparison="matched")
        except (OSError, ValueError, RuntimeError, subprocess.TimeoutExpired) as error:
            entry.update(status="failed", reason=str(error))
        entry["seconds"] = round(time.monotonic() - before, 3)
        statuses[name] = entry["status"]
        print(
            f"{entry['status'].upper():6} {name} ({entry['seconds']:.3f}s)", flush=True
        )
        if entry["status"] == "failed":
            print(f"       {entry['reason']}", flush=True)
    try:
        numpy_version = metadata.version("numpy")
    except metadata.PackageNotFoundError:
        numpy_version = None
    report = {
        "started_utc": started.isoformat(),
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "numpy": numpy_version,
        "suite": "selected" if args.check else args.suite,
        "floating_comparison": {
            "relative_tolerance": 1e-12,
            "absolute_tolerance": 1e-12,
        },
        "seconds": round(time.monotonic() - timer, 3),
        "passed": sum(row["status"] == "passed" for row in reports),
        "failed": sum(row["status"] == "failed" for row in reports),
        "skipped": sum(row["status"] == "skipped" for row in reports),
        "checks": reports,
        "scope": "Re-execution and comparison of the registered finite checks; not a universal proof or a complete cryptographic-size circuit execution.",
        "input_hashes": {
            str(path.relative_to(ROOT)): sha256(path)
            for pattern in (
                "run_checks.py",
                "checks/*.py",
                "matlab/*.m",
                "certificates/*.json",
                "expected/*.json",
            )
            for path in sorted(ROOT.glob(pattern))
        },
    }
    destination = run_dir / "verification_report.json"
    destination.write_text(
        json.dumps(report, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    print(
        f"\nPassed: {report['passed']}; failed: {report['failed']}; skipped: {report['skipped']}"
    )
    print(f"Report: {destination}")
    return 0 if not (report["failed"] or report["skipped"]) else 1


if __name__ == "__main__":
    raise SystemExit(main())
