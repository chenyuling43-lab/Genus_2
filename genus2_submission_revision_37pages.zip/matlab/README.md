# MATLAB reference implementation

These three files were exported unchanged from the previous manuscript's
appendix listings:

- `hec2_projective_add.m`: generic weighted-projective genus-two addition.
- `hec2_projective_recover.m`: affine recovery for checking.
- `demo_hec2_projective_add.m`: documented finite-field example.

Keep them in one MATLAB working directory and run:

```matlab
demo_hec2_projective_add
```

Use Symbolic Math Toolbox for the exact symbolic arithmetic in the supplied
demo. Construct large integer inputs from strings using `sym('integer')`,
without first rounding them to double precision. The example uses q=101;
its generic projective result is (81,53,65,52,68), with affine coefficients
(56,94,30,24). The tuple is specific to its chosen projective scale.

The addition function assumes valid degree-two inputs on a common smooth
curve and rejects its stated exceptional branches. It is not a complete
Cantor backend or the optimized masked quantum sampler. Affine recovery
uses an inverse and is for validation. The accompanying Python transcription
was checked; MATLAB itself was not executed in this work.
